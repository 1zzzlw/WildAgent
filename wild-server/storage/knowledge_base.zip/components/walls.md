---
doc_type: component
doc_scope: generation
knowledge_layer: architecture
entity_type: wall
entity_name: wall_family
topic: parameters
wild_version: "1.1"
status: experimental
authority: domain_reference
source: components/walls.md
keywords:
  - 墙体
  - wall
  - thickness
  - height
  - material
---

# 墙体构件分类与规则

> 来源：`docs/建筑类型分类体系_构件清单版1.2.md`。
> 用途：整理 wall 的受力角色、材料、构造方式、饰面风格和模数规格。
> RAG 关键词：wall、墙体、承重墙、剪力墙、幕墙、青砖墙、白墙、玻璃幕墙、墙厚、模数

---
## X. 墙体、门、窗深度分类与组装规则

> **本章定位**：将 WILD 中最常用的三大围护构件（wall / door / window）按**建筑风格**和**构件组合方式**做逐级细分。每种门窗造型 = 一组 WILD 子构件的组装公式。

---

### X.1 墙体分类

墙体在 WILD 中使用 `type: "wall"`，必填 `id`、`from`、`to`、`thickness`；`material` 和 `curve` 可选。当前没有独立 `height` 字段，墙高由 `from[1]` 与 `to[1]` 的差值表达。不同建筑对墙厚的领域需求差异很大，但这些尺寸建议不能覆盖当前 Schema。

#### X.1.1 按受力角色分类

| 类型 | WILD 表达 | 典型厚度 | 适用结构 | 关键约束 |
|:---|:---|:---:|:---|:---|
| **承重墙** | `wall` 直接落地，上方搁楼板/梁 | 240~370mm | 砖混结构、剪力墙 | 不可拆改，开洞需过梁 |
| **非承重·隔墙** | `wall` 厚度<150mm，重量由楼板/梁承担 | 100~120mm | 框架结构内部 | 轻质材料(加气混凝土/石膏板) |
| **非承重·填充墙** | `wall` 嵌于柱间 | 200~240mm | 框架结构外部/内部 | 与柱梁柔性连接 |
| **幕墙** | `wall` 悬挂于外部骨架 | 不计厚度(玻璃+龙骨) | 高层公建、商业 | 承受风荷载，需 pre-glazed |

**WILD JSON 示例**：以下是 `geometry.elements` 片段；墙高由 `from[1]` 与 `to[1]` 的差值表达，直墙省略 `curve`。

```json
[
  {
    "type": "wall",
    "id": "bearing_wall_01",
    "from": [0, 0, 0],
    "to": [8, 4.5, 0],
    "thickness": 0.24,
    "material": "grey_brick"
  },
  {
    "type": "wall",
    "id": "partition_01",
    "from": [3, 0, 0],
    "to": [3, 3.0, 6],
    "thickness": 0.12,
    "material": "aac_block"
  },
  {
    "type": "wall",
    "id": "curtain_wall_01",
    "from": [0, 0, 0],
    "to": [18, 30.0, 0],
    "thickness": 0.02,
    "material": "glass_curtain"
  }
]
```

#### X.1.2 按材料分类

| 材料 | thickness | material 值 | 适用建筑 | 特征 |
|:---|:---:|:---|:---|:---|
| **烧结粘土砖** | 240mm | `red_brick` / `grey_brick` | 住宅、学校、中式别墅 | 双面抹灰后 280mm |
| **加气混凝土砌块** | 100~250mm | `aac_block` | 填充墙、隔墙 | 轻质保温，不可承重 |
| **钢筋混凝土** | 160~500mm | `concrete` / `reinforced_concrete` | 剪力墙、核心筒、地下室 | 可承重，刚度大 |
| **石材** | 300~600mm | `stone_rubble` / `stone_ashlar` | 山区民居、欧式庄园、园林 | 天然质感，自重极大 |
| **木材** | 50~150mm | `wood_plank` / `wood_log` | 木屋、中式古建隔断 | 轻质，需防火处理 |
| **玻璃(幕墙)** | 不计 | `glass_curtain` | 高层办公、商业 | 透光，需龙骨框架 |
| **彩钢板/夹芯板** | 50~100mm | `steel_sandwich` | 厂房、养殖场、仓储 | 轻钢+保温芯材 |
| **夯土** | 400~600mm | `rammed_earth` | 生土建筑、生态民宿 | 天然质感，热惰性好 |

#### X.1.3 按构造方式分类

| 构造 | 描述 | WILD 实现方式 |
|:---|:---|:---|
| **实体墙** | 单一材料不留空隙 | 一条 `wall` 即可 |
| **空斗墙** | 砖砌中留空腔 | `wall` thickness=0.24 + 内部 cavity 标记 |
| **复合墙** | 两种以上材料叠合 | 两条 `wall` 紧贴（如外砖+内保温层） |
| **幕墙** | 骨架+面板悬挂 | `wall` + 外侧 `placement` 排列玻璃单元 |

#### X.1.4 按风格/饰面分类（与建筑类型对照）

```
墙体风格选型一览

┌────────────────────────────────────────────────────────┐
│ 现代风格    │ concrete(白色清水)  │ 现代别墅、办公     │
│ 中式传统    │ grey_brick(青砖/白墙)│ 四合院、中式别墅   │
│ 新中式      │ white_plaster(白墙)  │ 新中式别墅、酒店   │
│ 欧式古典    │ stone_ashlar(方石砌) │ 欧式庄园、博物馆   │
│ 工业风格    │ steel_sandwich(彩钢) │ 厂房、仓库         │
│ 生态风格    │ rammed_earth(夯土)   │ 生态民宿、游客中心 │
│ 高技风格    │ glass_curtain(玻璃)  │ 超高层写字楼、商业 │
└────────────────────────────────────────────────────────┘
```

#### X.1.5 墙体模数规格总表

| 名称 | 图纸标注 | 实际厚度 | 材料 | 每 m² 用砖(标砖) | 适用层数 |
|:---|:---:|:---:|:---|:---:|:---|
| 半砖墙 | 120mm | 115mm | 粘土砖 | 64 块 | 隔墙 |
| 一砖墙 | 240mm | 240mm | 粘土砖 | 128 块 | 承重≤6F |
| 一砖半墙 | 370mm | 365mm | 粘土砖 | 192 块 | 承重≤8F |
| 二砖墙 | 490mm | 490mm | 粘土砖 | 256 块 | 承重高层 |
| RC 承重墙 | 160mm | 160mm | 钢筋混凝土 | — | 剪力墙高层 |
| RC 隔墙 | 50mm | 50mm | 钢筋混凝土 | — | 非承重 |
| 加气砼外墙 | 200~250mm | 200~250mm | 加气混凝土 | — | 填充墙 |
| 加气砼隔墙 | 100~150mm | 100~150mm | 加气混凝土 | — | 内隔墙 |

---
