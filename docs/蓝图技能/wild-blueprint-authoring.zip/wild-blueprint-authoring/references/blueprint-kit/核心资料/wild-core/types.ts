/**
 * 原语语言规范 v1.0 — TypeScript 类型定义
 * 
 * 本文件提供原语蓝图的完整类型定义，供引擎实现和编辑器开发者参考。
 * 语言规范 (SPEC.md) 为唯一权威来源，本文件仅为辅助工具。
 */

import type {
  MaterialEnvironmentResponse,
  SurfaceFamily,
  SurfacePattern,
} from './src/materials/contracts';

// ========== 基础向量与颜色 ==========

/** 三维向量 [x, y, z] */
export type Vec3 = [number, number, number];

/** RGB 颜色值，范围 0.0–1.0 */
export type Color = [number, number, number];

/** 路径曲线类型（用于 wall、beam 等线性构件） */
export type CurveSegment = LineCurve | ArcCurve | EllipseCurve | CatenaryCurve;

export interface LineCurve { type: 'line' }
export interface ArcCurve {
  type: 'arc';
  center: Vec3;
  /** 扫过角度（度），正值逆时针 */
  sweep: number;
  /** 分段数，默认 24 */
  segments?: number;
}
export interface EllipseCurve {
  type: 'ellipse';
  center: Vec3;
  radiusX: number;
  radiusZ: number;
  startAngle?: number;
  sweep?: number;
  segments?: number;
}
export interface CatenaryCurve {
  type: 'catenary';
  /** 拱起高度（米） */
  rise: number;
  segments?: number;
}

/** 所有几何构件的联合类型 */
export type GeometryElement =
  | WallParams
  | FloorParams
  | ColumnParams
  | BeamParams
  | RoofParams
  | OpeningParams
  | StairParams
  | FurnitureParams
  | DenseBrickParams
  | BodyParams
  | PrimitiveParams;

/**
 * 组合构件不是新的渲染原语。它们会在进入 wild-core 前被编译为
 * GeometryElement[]，因此 renderer 不需要为 door/window/railing 注册 builder。
 */
export type ComponentSpec = (
  | DoorComponent
  | WindowComponent
  | RailingComponent
  | CanopyComponent
  | BalconyComponent
  | RampComponent
  | BayWindowComponent
  | CorniceComponent
  | ChimneyComponent
  | LightComponent
  | ElevatorComponent
  | FanComponent
) & {
  /** 编辑器中是否允许通过三轴控件拖动；关闭时只允许属性面板编辑。 */
  draggable?: boolean;
};

/** 门窗静态蓝图中持久化的交互配置；实际动画进度只存在于前端运行时。 */
export interface OpeningInteractionSpec {
  /**
   * swing=绕铰链侧平开；slide=沿墙面水平推拉；lift=整扇向上让开洞口（卷帘/上闸门）。
   * `lift` 与 `hingeSide` 无关，只认 `openDistance`。
   */
  mode: 'swing' | 'slide' | 'lift';
  hingeSide?: 'left' | 'right';
  /** swing 模式的最大开角，单位为度。 */
  openAngle?: number;
  /**
   * slide/lift 模式的位移，单位为米。
   * - `slide`：省略时按宽度 × 0.8 计算。
   * - `lift`：省略时按洞口高度计算，**但始终被钳到"洞口上方到父墙墙顶的净空"**——
   *   门扇是刚体平板、引擎不剪裁也不折卷，不钳就会顶出墙外。净空不足时门只升起一截
   *   （真实卷帘门半开的形态），净空足够时整扇让开洞口。
   */
  openDistance?: number;
  initiallyOpen?: boolean;
}

/** 编译器写入基础元素、Core 透传给 renderer 的内部交互描述。 */
export interface OpeningElementBehavior {
  kind: 'opening';
  /** 同一扇的玻璃/边框或双开门的两扇同步开合，仅在运行时使用。 */
  groupId?: string;
  mode: 'swing' | 'slide' | 'lift';
  pivot: Vec3;
  closedPosition: Vec3;
  closedRotation: Vec3;
  openRotation?: Vec3;
  openOffset?: Vec3;
  initiallyOpen: boolean;
}

/** 编译器生成的电梯部件行为；运动状态不持久化。 */
export interface ElevatorElementBehavior {
  kind: 'elevator';
  groupId: string;
  role: 'cab' | 'cabDoor' | 'landingDoor' | 'hallButton' | 'carButton';
  floor?: number;
  action?: 'call' | 'open' | 'close';
  doorOffset?: Vec3;
  /** 固定在可动轿厢上的照明，仍由局部灯光预算管理。 */
  light?: LightElementBehavior;
  floorHeight: number;
  floorCount: number;
  /** 当前停靠楼层（0 基，0 = 底层）。静态蓝图只保存初始楼层。 */
  initialFloor: number;
}

export interface RotorElementBehavior {
  kind: 'rotor';
  groupId: string;
  role: 'rotor' | 'control';
  pivot: Vec3;
  rpm: number;
  initiallyOn: boolean;
}

export type InteractiveElementBehavior = OpeningElementBehavior | LightElementBehavior | ElevatorElementBehavior | RotorElementBehavior;

/**
 * 电梯组件：井道内的可动轿厢。
 *
 * 编译为开放轿厢、对开门、各层呼梯和轿内选层按钮。入口朝世界 +Z。
 * 井道围合和上层楼板井洞由蓝图表达；landingWalls 可指定各层入口墙以自动开洞。
 */
export interface ElevatorComponent {
  type: 'elevator';
  id: string;
  /** 轿厢中心的世界坐标 [x, 停靠层轿厢地板 Y, z]（Y 取当前停靠层地面标高）。 */
  position: Vec3;
  /** 轿厢外廓 [宽, 高, 深]，宽/深须小于井道净空。 */
  dimensions: { width: number; depth: number; height: number };
  /** 单层行驶距离（米），与建筑层高一致。 */
  floorHeight: number;
  /** 井道跨越的层数（含底层）。 */
  floorCount: number;
  /** 初始停靠楼层（0 基），默认 0（底层）。 */
  initialFloor?: number;
  material?: string;
  /** 门框/导轨金属件材质。 */
  frameMaterial?: string;
  doorMaterial?: string;
  floorMaterial?: string;
  landingWalls?: string[];
}

/** 吊扇：position 为电机中心，控制器位于独立的可达位置。 */
export interface FanComponent {
  type: 'fan';
  id: string;
  position: Vec3;
  radius?: number;
  bladeCount?: number;
  drop?: number;
  rpm?: number;
  initiallyOn?: boolean;
  controlPosition: Vec3;
  material?: string;
  frameMaterial?: string;
}

/**
 * 灯具灯体的一段几何。字段与 `primitive` 原语完全一致 —— 灯体不发明新的
 * 几何语言，只复用引擎已有的四种通用算子（box / sphere / cylinder / profile_sweep）。
 * `position` 为null 时按组件 `position` 处理。
 */
export type LightBodyPart = Omit<PrimitiveParams, 'id' | 'type' | 'position'> & {
  position?: Vec3;
  /** 该段是否承载 `_interaction`：右键点灯的命中体。只有一段应为true。 */
  interactive?: boolean;
};

/** 灯具静态蓝图中持久化的光源参数；右键循环状态只存在于前端运行时。 */
export interface LightComponent {
  type: 'light';
  id: string;
  position: Vec3;
  /**
   * 灯体几何（参数化通路）。给了它就直接展开成这些 primitive，
   * `fixtureType` 退化为不再使用；没给才回落到 `fixtureType` 的预设几何。
   *
   * 为什么开这个口：`fixtureType` 是闭集枚举，每加一种灯型就要改 schema 两副本 +
   * 编译器分支，而灯具形态是开放的（顶装/壁装/吊装/异形，同一种还能有无数尺寸比）。
   * 让形态由数据决定，新增灯型不必碰契约。
   */
  body?: LightBodyPart[];
  /**
   * 预设灯体的快捷写法。**不是唯一出口** —— 新形态优先写 `body`。
   * `bulb` = 球泡 + 下方灯座（吊装，底座在发光体上方之外）；
   * `table_lamp` = 灯座 + 灯杆 + 灯罩 + 灯泡。
   */
  fixtureType?: 'bulb' | 'table_lamp';
  lightType?: 'point' | 'spot';
  color?: Color;
  lowIntensity?: number;
  highIntensity?: number;
  distance?: number;
  /** 聚光灯锥角，单位为度。 */
  angle?: number;
  initiallyOn?: boolean;
  bulbRadius?: number;
  baseHeight?: number;
  height?: number;
  shadeRadius?: number;
  material?: string;
  baseMaterial?: string;
  shadeMaterial?: string;
}

/** 编译器写入灯泡网格、Core 透传给 renderer 的灯光交互描述。 */
export interface LightElementBehavior {
  kind: 'light';
  lightType: 'point' | 'spot';
  color: Color;
  lowIntensity: number;
  highIntensity: number;
  distance: number;
  angle: number;
  initiallyOn: boolean;
  /** 相对于发光网格包围盒中心的局部偏移；聚光灯方向同为局部坐标。 */
  offset?: Vec3;
  direction?: Vec3;
}

/** 自定义几何的真实光源；emissive 仍只控制表面亮度。 */
export interface LightSourceDef {
  lightType?: 'point' | 'spot';
  color?: Color;
  intensity?: number;
  distance?: number;
  angle?: number;
  initiallyOn?: boolean;
  offset?: Vec3;
  direction?: Vec3;
}

export interface TextLabel {
  text: string;
  color?: Color;
  fontFamily?: 'sans-serif' | 'serif';
}

export interface DoorComponent {
  type: 'door';
  id: string;
  parentWall: string;
  /** [沿父墙距离, 底部世界 Y, 墙体法向偏移] */
  from: Vec3;
  width: number;
  height: number;
  frameWidth?: number;
  frameDepth?: number;
  /** 门扇实体厚度，默认不超过 0.04m，并受门框深度约束。 */
  leafDepth?: number;
  frameMaterial?: string;
  leafMaterial?: string;
  /** 省略时默认平开；false 表示固定门。 */
  interaction?: OpeningInteractionSpec | false;
  /** 洞口形状，默认 "rectangular"。设为 "arched" 可生成拱形门洞。 */
  openingStyle?: 'rectangular' | 'arched';
  /** 门扇布局，默认 "single"。"double" 生成双开布局（两个洞口+四段框）。 */
  doorStyle?: 'single' | 'double';
  /**
   * 门扇横向分节行数（1~8）。缺省时按门洞尺寸哈希取 2 或 3。
   * 车库门帘片用 4~6。与 `doorStyle` 正交：后者管单/双扇布局，本字段只改门扇外观分节。
   */
  leafRows?: number;
}

export interface WindowComponent {
  type: 'window';
  id: string;
  parentWall: string;
  /** [沿父墙距离, 底部世界 Y, 墙体法向偏移] */
  from: Vec3;
  width: number;
  height: number;
  frameWidth?: number;
  frameDepth?: number;
  /** 玻璃实体厚度，默认不超过 0.012m，并受窗框深度约束。 */
  glassDepth?: number;
  verticalMullions?: number;
  horizontalMullions?: number;
  /** 棂条宽度独立于外框，默认 min(frameWidth, 0.02m)。 */
  mullionWidth?: number;
  frameMaterial?: string;
  glassMaterial?: string;
  /** 省略时默认双扇平开；false 表示固定窗。 */
  interaction?: OpeningInteractionSpec | false;
}

export interface RailingComponent {
  type: 'railing';
  id: string;
  /** 栏杆基线的世界坐标路径，允许水平或随楼梯升降。 */
  path: Vec3[];
  height: number;
  postSpacing?: number;
  postRadius?: number;
  railRadius?: number;
  /** 横杆相对栏杆高度的比例，范围 (0, 1]，默认只有顶部扶手。 */
  railLevels?: number[];
  /** 栏板类型：`glass`（玻璃）/ `panel`（实心板）；缺省不生成栏板。 */
  infillType?: 'glass' | 'panel';
  /** 栏板厚度（米），默认 glass 0.02 / panel 0.05。 */
  infillThickness?: number;
  /** 栏板顶相对栏杆高度的比例，范围 (0, 1]，默认 0.92（留在顶部扶手下方）。 */
  infillTopRatio?: number;
  /** 栏板材质，默认与栏杆 `material` 相同。 */
  infillMaterial?: string;
  material?: string;
  /** 指定后，path 使用父楼板左下角和顶面作为局部原点。 */
  parentFloor?: string;
}

export interface CanopyComponent {
  type: 'canopy';
  id: string;
  parentWall: string;
  /** [沿父墙距离, 安装高度, 墙体法向偏移] */
  from: Vec3;
  width: number;
  depth: number;
  thickness: number;
  supportCount?: number;
  supportSize?: number;
  material?: string;
  supportMaterial?: string;
}

export interface BalconyComponent {
  type: 'balcony';
  id: string;
  parentWall: string;
  /** [沿父墙距离, 楼板顶面高度, 墙体法向偏移] */
  from: Vec3;
  width: number;
  depth: number;
  slabThickness: number;
  /** 独立栏杆实例接管时关闭内置栏杆。 */
  railingEnabled?: boolean;
  railingHeight?: number;
  postSpacing?: number;
  material?: string;
  railingMaterial?: string;
}

export interface RampComponent {
  type: 'ramp';
  id: string;
  from: Vec3;
  to: Vec3;
  width: number;
  thickness: number;
  railingSides?: 'none' | 'left' | 'right' | 'both';
  railingHeight?: number;
  postSpacing?: number;
  material?: string;
  railingMaterial?: string;
  /** 指定后，from/to 使用父楼板左下角和顶面作为局部原点。 */
  parentFloor?: string;
}

export interface BayWindowComponent {
  type: 'bay_window';
  id: string;
  parentWall: string;
  /** [沿父墙距离, 窗洞底部高度, 墙体法向偏移] */
  from: Vec3;
  width: number;
  height: number;
  projectionDepth: number;
  frameWidth?: number;
  frameDepth?: number;
  frameMaterial?: string;
  glassMaterial?: string;
  /** 正面窗扇默认双轨推拉，侧玻璃固定；false 关闭交互。 */
  interaction?: OpeningInteractionSpec | false;
}

export interface CorniceComponent {
  type: 'cornice';
  id: string;
  path: Vec3[];
  profile: Array<[number, number]>;
  closedProfile?: boolean;
  material?: string;
  /** 指定后，path 使用屋顶中心和计算后的屋面高度作为局部坐标。 */
  parentRoof?: string;
}

export interface ChimneyComponent {
  type: 'chimney';
  id: string;
  position: Vec3;
  width: number;
  depth: number;
  height: number;
  wallThickness?: number;
  capHeight?: number;
  material?: string;
  capMaterial?: string;
  /** 指定后，position 使用屋顶中心和计算后的屋面高度作为局部坐标。 */
  parentRoof?: string;
}

// ========== 几何构件 ==========
export interface WallParams {
  type: 'wall';
  id: string;
  from: Vec3;
  to: Vec3;
  thickness: number;
  material?: string;
  /** 路径曲线。不指定为直线。单段对象或多段数组 */
  curve?: CurveSegment | CurveSegment[];
  /** 内部使用：开孔信息（由resolver填充） */
  _cutouts?: Array<{
    style?: OpeningParams['style'];
    localX: number;
    localY: number;
    localW: number;
    localH: number;
  }>;
  /** 内部使用：直角墙角为消除厚墙接缝而增加的渲染长度，不改变蓝图中心线。 */
  _jointExtensions?: { start: number; end: number };
}

export interface FloorParams {
  type: 'floor';
  id: string;
  from: Vec3;
  to?: Vec3;
  thickness: number;
  material?: string;
  /** rect（默认）、circle 或 polygon。from 始终为板底标高。 */
  shape?: 'rect' | 'circle' | 'polygon';
  /** polygon: 相对 from 的局部 [x,z] 外轮廓，至少三个点。 */
  polygon?: Array<[number, number]>;
  /** polygon: 不相交且完全位于外轮廓内的孔洞。 */
  holes?: Array<Array<[number, number]>>;
  /** 圆形半径，shape="circle" 时必需 */
  radius?: number;
  /** 圆形分段数，默认 32 */
  segments?: number;
}

export interface ColumnParams {
  type: 'column';
  id: string;
  base: Vec3;
  height: number;
  bottomRadius: number;
  topRadius: number;
  style: 'doric' | 'ionic' | 'corinthian' | 'modern' | 'chinese_wooden';
  flutes?: number;
  entasis?: number;
  inclination?: number;
  material?: string;
}

export interface BeamParams {
  type: 'beam';
  id: string;
  from: Vec3;
  to: Vec3;
  crossSection: 'rect' | 'circular' | 'i-beam';
  width: number;
  height: number;
  material?: string;
  /** 路径曲线。不指定为直线 */
  curve?: CurveSegment | CurveSegment[];
}

export interface RoofParams {
  type: 'roof';
  id: string;
  roofType: 'gable' | 'hip' | 'dome' | 'flat' | 'chinese_curved' | 'chinese_pagoda';
  /** 双坡屋脊轴；省略时保留历史 Z 轴。 */
  ridgeAxis?: 'x' | 'z';
  span: number;
  depth: number;
  height: number;
  thickness: number;
  eaveCurveHeight?: number;
  curveProfile?: string;
  /** 重檐层数（chinese_pagoda），默认 3 */
  tiers?: number;
  /** 每层垂直高度，默认 height/tiers */
  tierHeight?: number;
  /** 每层出檐外挑量（米），默认 0.5 */
  eaveOutset?: number;
  /** 每层缩比 0-1，默认 0.7 */
  shrinkFactor?: number;
  position?: Vec3;
  material?: string;
}

// 墙体开口与覆盖面；门窗开合由组合组件的 interaction 编译为运行时行为。
export interface OpeningParams {
  type: 'opening';
  id: string;
  parentWall: string;
  from: Vec3;
  width: number;
  height: number;
  /** 覆盖面实体厚度；组合门窗会分别传入门扇或玻璃厚度。 */
  depth?: number;
  style: 'rectangular' | 'arched' | 'gothic' | 'circular';
  material?: string;
  /** 仅供组合编译器和 renderer 使用，不属于可手写的 WILD opening 字段。 */
  _interaction?: InteractiveElementBehavior;
  _leafInset?: number;
  _cutoutOnly?: boolean;
  _skipWallCutout?: boolean;
  _leafInteractions?: OpeningElementBehavior[];
  /** 仅供 door 编译器使用；把门板细节合并进同一可交互网格。 */
  _doorLeafDetail?: {
    rows: number;
    columns: 1 | 2;
    hingeSide: 'left' | 'right';
    doubleDoor: boolean;
  };
}

// 楼梯参数
export interface StairParams {
  type: 'stair';
  id: string;
  from: Vec3;
  to: Vec3;
  stepCount?: number;
  stepDepth?: number;
  stepHeight?: number;
  width: number;
  material?: string;
}

// 家具参数
export interface FurnitureParams {
  type: 'furniture';
  id: string;
  subtype: 'table' | 'chair' | 'sofa' | 'bookshelf' | 'bed' | 'wardrobe' | 'nightstand' | 'tv_cabinet' | 'lamp' | 'tile';
  /** 底面锚点：position[1] 是家具底部世界 Y，不是几何中心。 */
  position: Vec3;
  /**
   * 绕原点欧拉角（弧度，XYZ 序），与 primitive.rotation 同一语义。
   *
   * 缺省 [0,0,0]。家具没有宿主构件，朝向是它唯一的姿态自由度：椅子/沙发
   * 只有转了向才能围桌、靠墙、面向视线。与 position 一样是**蓝图契约字段**，
   * 不是渲染期偏移。
   */
  rotation?: Vec3;
  style?: string;
  dimensions: { width: number; depth: number; height: number };
  material?: string;
}

// 致密砖的参数
export interface DenseBrickParams {
  type: 'dense_brick';
  id: string;
  /** [x体素数, y体素数, z体素数]，各维 ≥ 8，必须为整数 */
  resolution: [number, number, number];
  origin: Vec3;
  data: string;
  material?: string;
  method?: 'marching_cubes' | 'dual_contouring';
  attachment?: { parent: string; mapping: 'planar' | 'cylindrical' | 'spherical' };
}

// 肢体参数
export interface BodyParams {
  type: 'body';
  id: string;
  height: number;
  build: 'lean' | 'athletic' | 'stout';
  headShape: 'round' | 'oval' | 'angular';
  armLength: number;
  legLength: number;
  cloakLength: number;
  hoodUp: boolean;
  position?: Vec3;
  material?: string;
}

/**
 * 通用参数化形体（WILD v1.1）。
 *
 * 用少量可组合的数学形体表达篮球、檐口线脚等对象，避免为每个现实
 * 名词增加一个专用 element type。
 */
export interface PrimitiveParams {
  type: 'primitive';
  id: string;
  shape: 'box' | 'sphere' | 'cylinder' | 'profile_sweep';
  position?: Vec3;
  rotation?: Vec3;
  scale?: Vec3;
  material?: string;
  /** 招牌印字，贴在 box 的局部 +Z 面；随构件移动、旋转。 */
  label?: TextLabel;
  /** 给任意 primitive 外形绑定真实光源，无需使用预设灯具。 */
  lightSource?: LightSourceDef;

  /** box: [宽, 高, 深] */
  dimensions?: Vec3;

  /** sphere / cylinder / profile_sweep 默认截面半径 */
  radius?: number;
  radiusTop?: number;
  radiusBottom?: number;
  height?: number;
  segments?: number;
  heightSegments?: number;

  /** profile_sweep: 二维截面点 [u, v] 与三维路径点 */
  profile?: Array<[number, number]>;
  path?: Vec3[];
  closedProfile?: boolean;
  /** 闭合截面扫掠的首尾端盖。默认 false，兼容既有开放扫掠。 */
  caps?: boolean;
  /** 仅供组合编译器和 renderer 使用。 */
  _interaction?: InteractiveElementBehavior;
}

// ========== 材质系统 ==========
export interface WeatheringEffect {
  type: 'weathering';
  dustColor: Color;
  dustOpacity: number;
  crackIntensity: number;
  colorFade: number;
}

export interface MossEffect {
  type: 'moss';
  mossColor: Color;
  coverage: number;
  pattern: 'base_up' | 'patchy' | 'edge';
}

export interface EdgeWearEffect {
  type: 'edgeWear';
  wearColor: Color;
  intensity: number;
}

export interface GrainEffect {
  type: 'grain';
  intensity: number;
  scale: number;
}

export type EffectLayer = WeatheringEffect | MossEffect | EdgeWearEffect | GrainEffect;

/** 无图片红砖程序化材质；所有尺寸均使用墙面语义 UV 对应的米制单位。 */
export interface ProceduralBrickMaterial {
  type: 'brick';
  seed?: number;
  brickSize?: [number, number];
  mortarWidth?: number;
  mortarDepth?: number;
  bond?: 'running' | 'stack';
  secondaryColor?: Color;
  colorVariation?: number;
  roughnessVariation?: number;
  edgeWear?: number;
  weathering?: {
    amount?: number;
    scale?: number;
    efflorescence?: number;
    verticalStreaks?: number;
    baseDampness?: number;
  };
}

/** 判别联合只包含已实现的材质族，禁止 Blueprint 携带 Shader 源码。 */
export type ProceduralMaterial = ProceduralBrickMaterial;

export interface EmbeddedImageData {
  encoding: 'base64';
  mimeType: string;
  data: string;
}

export interface ReferencedImageData {
  encoding: 'url';
  uri: string;
  mimeType: 'image/png' | 'image/jpeg' | 'image/webp' | 'image/ktx2';
  sha256: string;
  byteSize?: number;
  colorSpace: 'srgb' | 'linear';
}

export type TextureImageData = EmbeddedImageData | ReferencedImageData;

export interface PBRTextureSetAsset {
  schemaVersion: '1.0';
  assetId: string;
  kind: 'pbr_texture_set';
  name: string;
  contentHash: string;
  source: { type: string; uri?: string };
  license: string;
  maps: {
    baseColor: ReferencedImageData;
    normal?: ReferencedImageData;
    roughness?: ReferencedImageData;
    metalness?: ReferencedImageData;
    ambientOcclusion?: ReferencedImageData;
  };
  classification?: {
    materialClass?: string;
    tags?: string[];
    recommendedRoles?: string[];
  };
  realWorldSizeMeters?: [number, number];
  defaults?: {
    baseColorTint?: Color;
    roughness?: number;
    metallic?: number;
    normalScale?: number;
    uvScale?: [number, number];
  };
  createdAt: string;
}

export interface MaterialDef {
  baseColor: Color;
  roughness: number;
  metallic: number;
  albedo: number;
  emissive?: Color;
  opacity?: number;
  lightingCondition: 'D65_noon';
  effects?: EffectLayer[];
  embeddedImage?: EmbeddedImageData;
  /** WILD v1.1：可选的内嵌或 URL PBR 纹理通道 */
  textures?: {
    baseColor?: TextureImageData;
    normal?: TextureImageData;
    roughness?: TextureImageData;
    metalness?: TextureImageData;
    ambientOcclusion?: TextureImageData;
  };
  textureSet?: string;
  normalScale?: number;
  uvScale?: [number, number];
  materialClass?: 'standard' | 'glass' | 'clearcoat' | 'fabric';
  side?: 'front' | 'double';
  transmission?: number;
  ior?: number;
  thickness?: number;
  attenuationColor?: Color;
  attenuationDistance?: number;
  clearcoat?: number;
  clearcoatRoughness?: number;
  anisotropy?: number;
  anisotropyRotation?: number;
  sheen?: number;
  sheenColor?: Color;
  emissiveIntensity?: number;
  procedural?: ProceduralMaterial;
  /** renderer 无关的表面语义；未填写时由 core 按通用规则推断。 */
  surfaceFamily?: SurfaceFamily;
  surfacePattern?: SurfacePattern;
  /** 材质对世界天气的物理响应参数，不包含 Shader 源码。 */
  environmentResponse?: MaterialEnvironmentResponse;
  requiredFeatures?: string[];
}

// ========== 动态系统 ==========
export interface PhysicsData {
  mass: number;
  collisionShape: 'box' | 'sphere' | 'capsule' | 'mesh';
  constraints?: ConstraintData[];
}

export type ConstraintData = HingeConstraint | SliderConstraint;

export interface HingeConstraint {
  type: 'hinge';
  target: string;
  axis: 'x' | 'y' | 'z';
  limit?: [number, number];
}

export interface SliderConstraint {
  type: 'slider';
  target: string;
  axis: 'x' | 'y' | 'z';
  limit?: [number, number];
}

export interface AnimationParams {
  walkStyle?: number;
  posture?: number;
  clothStiffness?: number;
  clothDamping?: number;
  windResponse?: number;
}

export interface ScriptData {
  on_click?: ScriptCondition;
  on_enter?: ScriptCondition;
  on_leave?: ScriptCondition;
}

export interface ScriptCondition {
  condition?: string;
  actions: ActionData[];
}

export interface ActionData {
  type: 'toggle_hinge' | 'play_sound' | 'set_material' | 'show_text' | 'teleport';
  target?: string;
  sound?: string;
  material?: string;
  text?: string;
  destination?: Vec3;
}

// ========== 元数据 ==========
export interface Meta {
  version: string;           // "1.0"
  // 场景类型："building"（建筑）或 "avatar"（虚拟角色）
  type: 'building' | 'avatar' | 'asset' | 'scene';
  // 	场景名称，如 "中式凉亭"
  name: string;
  // 作者名（可选）
  author?: string;
  // 创建时间戳（可选）
  createdAt?: number;
  // 	风格标签，如 "chinese_classical"（可选）
  style?: string;
  // 随机种子，用于程序化生成的可复现性
  seed?: number;
}

// ========== 蓝图顶层结构 ==========
export interface Blueprint {
  // 元数据
  meta: Meta;
  // 几何定义
  geometry: {
    // 直接构件数组。存放场景中每个独立物体（墙、柱、地板、房顶、家具等），每个元素是一个 GeometryElement 联合类型，必须带唯一的 id。这是一般场景最主要的填充内容
    elements?: GeometryElement[];
    // 高级组合构件。渲染前由同包的 compiler 展开为现有 GeometryElement。
    components?: ComponentSpec[];
    // 构件模板字典。key → GeometryElement 的映射。模板本身不直接渲染，它定义了一个"原型构件"。与 instances 组合使用：同一模板可被多个实例引用，类似于"定义了一个柱子原型，然后在地图上放置 20 个"。避免重复定义相同的构件参数
    templates?: Record<string, GeometryElement>;
    // 模板实例数组。每个 InstanceRef 通过 ref 指向 templates 中的某个模板，并指定自己的 position/rotation/scale 和可选的 materialOverride（对模板中的某些材质做替换）。由 expander 展开为实际构件后交给几何构建器
    instances?: InstanceRef[];
    // 批量放置规则。定义如何在某个父构件的表面上按网格（grid）自动排布模板实例。例如："在这面墙（parent）的正面（face）上用 3 列 × 4 行的网格放置窗户模板"。比手动写 instances 更高效，也是由 expander 展开
    placements?: Placement[];
  };
  // 材质定义
  materials?: Record<string, MaterialDef>;
  assets?: Record<string, PBRTextureSetAsset>;
  /** 全局材质库引用；Blueprint 不复制全局资产。 */
  materialLibraries?: string[];
  /** 世界光影配置引用；未填写时使用 builtin:default。 */
  renderProfile?: string;
  // 动态行为，定义场景的物理、脚本和动画行为，不属于几何本身，但附加在场景上：
  behaviors?: {
    // 物理属性
    physics?: PhysicsData;
    // 交互脚本数组
    scripts?: ScriptData[];
    // 动画参数
    animation?: AnimationParams;
  };
}

export interface InstanceRef {
  id?: string;
  ref: string;
  position: Vec3;
  rotation?: Vec3;
  scale?: Vec3;
  materialOverride?: Record<string, string>;
}

/** 布局放置 — 用数学规则在父构件表面批量生成实例 */
export interface Placement {
  id: string;
  template: string;
  onSurface: {
    parent: string;
    face: string | string[];
  };
  layout: {
    type: 'grid';
    columns: number;
    rows: number;
    rowSpacing: number;
    colSpacing: number;
    overlap?: number;
    gapWidth?: number;
    /** 按格子覆盖材质。键为 "{行}_{列}"，值为材质名 */
    cellMaterials?: Record<string, string>;
  };
}
