"""从同一份设计事实检查引用，并推导标高、梯级、梯井和楼板分片。"""
from math import ceil, hypot

from .facts import DesignFacts

EPS = 1e-6


def _inside(rect, outer):
    return (outer[0]-EPS <= rect[0] < rect[1] <= outer[1]+EPS
            and outer[2]-EPS <= rect[2] < rect[3] <= outer[3]+EPS)


def _slab_rectangles(regions, cuts):
    """网格分片后合并同行，重叠体量不重复生成楼板。"""
    if not regions:
        return []
    xs = sorted({x for r in regions+cuts for x in r[:2]})
    zs = sorted({z for r in regions+cuts for z in r[2:]})
    result = []
    for z0, z1 in zip(zs, zs[1:]):
        row = []
        for x0, x1 in zip(xs, xs[1:]):
            cell = (x0, x1, z0, z1)
            if not any(_inside(cell, r) for r in regions) or any(_inside(cell, r) for r in cuts):
                continue
            if row and abs(row[-1][1]-x0) < EPS:
                row[-1][1] = x1
            else:
                row.append(list(cell))
        result.extend(row)
    return result


def resolve_facts(value: DesignFacts | dict) -> dict:
    """校验失败给出字段路径；成功返回派生结果，始终不改写设计输入。"""
    d = value if isinstance(value, DesignFacts) else DesignFacts.model_validate(value)
    errors = []

    def check(condition, path, message):
        if not condition:
            errors.append(f"/{path}：{message}")

    ordered = sorted(d.levels, key=d.levels.get)
    check(len(ordered) >= 2, "levels", "至少声明起始楼面与顶部板面")
    check(len(set(d.levels.values())) == len(ordered), "levels", "不同楼层不能重复标高")
    next_level = dict(zip(ordered, ordered[1:]))
    for low, high in zip(ordered, ordered[1:]):
        check(d.levels[high]-d.levels[low] > d.slab_thickness, "levels", "相邻标高差必须大于板厚")
    ids = set()
    for name in ("volumes", "room_zones", "voids", "walls", "openings", "stairs", "roofs", "components", "routes"):
        for i, row in enumerate(getattr(d, name)):
            path = f"{name}/{i}"
            check(row.id not in ids, path+"/id", "实体 ID 必须全局唯一")
            ids.add(row.id)
            for field in ("level", "bottom", "top", "from_level", "to_level"):
                ref = getattr(row, field, None)
                if ref is not None:
                    check(ref in d.levels, path+"/"+field, f"楼层引用 {ref!r} 不存在")
            roles = list(row.material_roles.values()) if name == "components" else []
            if name in {"volumes", "walls", "stairs"} or name == "roofs" and row.type != "none":
                roles.append(row.material_role)
            if name == "openings":
                roles.extend(r for r in (row.frame_role, row.panel_role) if r is not None)
            for role in roles:
                check(role in d.material_roles, path, f"材质角色 {role!r} 不存在")
    if errors:
        raise ValueError("；".join(errors))

    volumes = {v.id: v for v in d.volumes}
    roofs = {r.volume: r for r in d.roofs}
    for i, roof in enumerate(d.roofs):
        check(roof.volume in volumes, f"roofs/{i}/volume", "体量不存在")
        check(sum(r.volume == roof.volume for r in d.roofs) == 1, f"roofs/{i}", "一个体量只选择一份屋面")
        check((roof.type in {"flat", "none"} and roof.rise == 0)
              or (roof.type not in {"flat", "none"} and roof.rise > 0), f"roofs/{i}/rise", "坡屋面需要正起拱高度，flat/none 为 0")
        check(not roof.walkable or roof.type == "flat", f"roofs/{i}/walkable", "本版仅支持平屋面作为可使用露台")
    for i, v in enumerate(d.volumes):
        check(d.levels[v.top] > d.levels[v.bottom], f"volumes/{i}", "顶部必须高于起始楼面")
        check(v.id in roofs, f"volumes/{i}", "明确声明屋面；敞开时 roofs.type=none")
        check(d.site is None or _inside(v.rect, d.site), f"volumes/{i}/rect", "体量超出场地")
    for name in ("room_zones", "voids", "stairs"):
        for i, row in enumerate(getattr(d, name)):
            v = volumes.get(row.volume)
            check(v is not None, f"{name}/{i}/volume", "体量不存在")
            if v is None:
                continue
            check(_inside(row.rect, v.rect), f"{name}/{i}/rect", "占地超出引用体量")
            refs = (row.from_level, row.to_level) if name == "stairs" else (row.level,)
            for level in refs:
                check(d.levels[v.bottom] <= d.levels[level] <= d.levels[v.top], f"{name}/{i}", "楼层超出引用体量")
            if name == "room_zones" and row.level == v.top:
                check(v.id in roofs and roofs[v.id].walkable, f"{name}/{i}/level", "顶部房间需有可使用的平屋面")

    wall_frames = {}
    for i, w in enumerate(d.walls):
        top = w.top or next_level.get(w.level)
        check(w.start != w.end, f"walls/{i}", "内墙起终点不能相同")
        check(top is not None and d.levels[top]-d.slab_thickness > d.levels[w.level], f"walls/{i}/top", "墙顶必须高于墙底")
        if top:
            wall_frames[w.id] = {"start": w.start, "end": w.end,
                                 "bottom": d.levels[w.level], "top": d.levels[top]-d.slab_thickness}

    opening_frames = []
    for i, o in enumerate(d.openings):
        path = f"openings/{i}"
        frame = wall_frames.get(o.host)
        if o.host in volumes:
            v = volumes[o.host]
            check(o.face is not None, path+"/face", "体量宿主需要明确墙面")
            if o.face is None:
                continue
            x0, x1, z0, z1 = v.rect
            a, b = {"front": ((x0, z0), (x1, z0)), "back": ((x1, z1), (x0, z1)),
                    "left": ((x0, z1), (x0, z0)), "right": ((x1, z0), (x1, z1))}[o.face]
            frame = {"start": a, "end": b, "bottom": d.levels[v.bottom], "top": d.levels[v.top]-d.slab_thickness}
        else:
            check(o.face is None, path+"/face", "独立内墙沿 start→end 定位，不再填写 face")
        check(frame is not None, path+"/host", "宿主必须是已声明体量或独立内墙")
        check(o.type == "opening" or o.frame_role is not None and o.panel_role is not None, path, "门窗需要明确框和扇的材质角色")
        check((o.type == "opening") == (o.style == "open"), path+"/style", "通行洞口用 open，门窗选择固定、平开或推拉")
        if frame is None:
            continue
        a, b = frame["start"], frame["end"]
        length = hypot(b[0]-a[0], b[1]-a[1])
        bottom = d.levels[o.level]+o.sill
        check(o.offset+o.width <= length+EPS, path+"/offset", "开口超出宿主长度")
        check(frame["bottom"]-EPS <= bottom and bottom+o.height <= frame["top"]+EPS, path+"/height", "开口超出宿主墙高")
        if length > 0:
            center = o.offset+o.width/2
            opening_frames.append({"id": o.id, "bottom": bottom,
                "center_xz": [a[0]+(b[0]-a[0])*center/length, a[1]+(b[1]-a[1])*center/length]})

    stairs, voids = [], [v.model_dump(mode="json") for v in d.voids]
    for i, s in enumerate(d.stairs):
        path = f"stairs/{i}"
        rise = d.levels[s.to_level]-d.levels[s.from_level]
        check(rise > 0, path, "到达楼面必须高于起始楼面")
        if rise <= 0:
            continue
        flights = 1 if s.shape == "straight" else 2
        count = s.steps_each or ceil(rise/(flights*s.max_riser_height))
        riser = rise/(flights*count)
        check(riser <= s.max_riser_height+EPS, path+"/steps_each", "明确级数造成步高超过设计上限，不能擅自改级数")
        width, depth = s.rect[1]-s.rect[0], s.rect[3]-s.rect[2]
        along, across = (width, depth) if s.direction.endswith("x") else (depth, width)
        run = count*s.tread_depth
        check(flights == 1 or s.landing_depth >= s.flight_width, path+"/landing_depth", "转折平台深度不得小于本次选择的单跑宽度")
        required_along = run+s.landing_depth
        required_across = 2*s.flight_width if s.shape == "U" else required_along if s.shape == "L" else s.flight_width
        check(along+EPS >= required_along and across+EPS >= required_across, path+"/rect", "踏步、梯宽和平台无法放入声明占地")
        stairs.append({"id": s.id, "rise": rise, "flights": flights, "steps_each": count,
                       "riser_height": riser, "flight_run": run,
                       "landing_elevation": None if flights == 1 else (d.levels[s.from_level]+d.levels[s.to_level])/2})
        voids.extend({"id": f"stair:{s.id}:{level}", "rect": list(s.rect), "level": level, "volume": s.volume}
                     for level in ordered if d.levels[s.from_level] < d.levels[level] <= d.levels[s.to_level])
    for i, route in enumerate(d.routes):
        check(all(a != b for a, b in zip(route.points, route.points[1:])), f"routes/{i}/points", "相邻路径点不能相同")
        check(route.width >= d.use_clearances.main_routes_width, f"routes/{i}/width", "净宽低于图纸自己的最小通路宽度")
        check(route.height >= d.use_clearances.route_headroom, f"routes/{i}/height", "净高低于图纸自己的通路净高")
    for i, component in enumerate(d.components):
        check(component.repeat is None or component.repeat.count == 1 or component.repeat.step != (0, 0),
              f"components/{i}/repeat", "多件阵列不能原地重叠")
    if errors:
        raise ValueError("；".join(errors))

    slabs = {}
    for level in ordered:
        regions = [v.rect for v in d.volumes if d.levels[v.bottom] <= d.levels[level] <= d.levels[v.top]
                   and not (level == v.top and roofs[v.id].type == "none")]
        cuts = [v["rect"] for v in voids if v["level"] == level]
        slabs[level] = {"top": d.levels[level], "bottom": d.levels[level]-d.slab_thickness,
                        "rectangles": _slab_rectangles(regions, cuts)}
    components = []
    for c in d.components:
        count, step = (c.repeat.count, c.repeat.step) if c.repeat else (1, (0, 0))
        for i in range(count):
            dx, dz = step[0]*i, step[1]*i
            components.append({"id": c.id if count == 1 else f"component:{c.id}:{i}", "recipe": c.recipe,
                "bottom": d.levels[c.level]+c.elevation_offset-(c.height if c.anchor == "top" else 0),
                "rect": [c.rect[0]+dx, c.rect[1]+dx, c.rect[2]+dz, c.rect[3]+dz] if c.rect else None,
                "path": [[x+dx, z+dz] for x, z in c.path], "height": c.height, "rotation": c.rotation,
                "material_roles": dict(c.material_roles), "parameters": dict(c.parameters)})
    roof_frames = []
    for r in d.roofs:
        if r.type == "none":
            continue
        v = volumes[r.volume]
        x0, x1, z0, z1 = v.rect
        west, east, south, north = r.overhang
        roof_frames.append({"id": r.id, "rect": [x0-west, x1+east, z0-south, z1+north],
                            "support": d.levels[v.top]-d.slab_thickness, "slab_top": d.levels[v.top]})
    return {"stairs": stairs, "voids": voids, "slabs": slabs, "walls": wall_frames,
            "components": components, "roofs": roof_frames,
            "openings": opening_frames,
            "scope": "设计参数与引用复核；不等于配方已实现、整栋通行或 WILD 渲染验收"}
