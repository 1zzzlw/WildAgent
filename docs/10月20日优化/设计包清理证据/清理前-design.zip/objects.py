"""物件图纸：做什么、做几个、多大、怎么摆；不包含建筑体量。"""
from __future__ import annotations

from typing import Any, Literal

from pydantic import Field

from .base import ContractModel
from .materials import MaterialIntent


class ObjectDecisions(ContractModel):
    """物件设计总表；kind 区分建筑和物件两类图纸。"""

    kind: Literal["object"] = "object"
    concept: str = Field(default="", max_length=240)
    objects: list[ComponentObject] = Field(default_factory=list, max_length=24)
    #: 点名了、但本次表达不出可生成几何的物件。
    #: 它进交付清单作为**非阻断**提示。
    unsupported_objects: list[str] = Field(default_factory=list, max_length=24)
    materials: MaterialIntent = Field(default_factory=MaterialIntent)
    design_rationale: list[str] = Field(default_factory=list, max_length=12)


class ComponentObject(ContractModel):
    """一个物件或物件组合；furniture 用预设，primitive 用局部零件，body 用人物参数。"""

    kind: str = Field(min_length=1, max_length=60)
    subtype: str = Field(default="", max_length=60)
    #: 用户点名的原始名词（"桌子"/"小人"/"花瓶"）。预设通道可为空。
    name: str = Field(default="", max_length=60)
    count: int = Field(default=1, ge=1, le=64)
    width: float = Field(gt=0, le=50)
    depth: float = Field(gt=0, le=50)
    height: float = Field(gt=0, le=50)
    #: `kind=primitive` 的零件表。每项是一份 WILD `primitive` 参数（shape + 几何参数 +
    #: 局部 position/rotation），**不做业务语义解释**——它就是要交付的几何。
    parts: list[dict[str, Any]] = Field(default_factory=list, max_length=64)
    #: `kind` 专属参数（目前只有 `body` 用：build / headShape / armLength / legLength /
    #: cloakLength / hoodUp）。用开放 dict 而不是逐字段建模，是因为新增一条通道时
    #: 不该再改一次契约——但**白名单仍在**：生成节点的 schema 校验会逐字段把关。
    params: dict[str, Any] = Field(default_factory=dict)
    #: 摆位说明（自然语言约束，例如"四把围在长边两侧、面向桌面"）。
    #: 坐标最终由构件生成节点按行走面标高算出，方案层不写死世界坐标。
    placement: str = Field(default="", max_length=300)
    material: str = Field(default="", max_length=80)
    rationale: str = Field(default="", max_length=300)


ObjectDecisions.model_rebuild()
