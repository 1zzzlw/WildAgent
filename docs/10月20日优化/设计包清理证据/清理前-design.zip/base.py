"""设计契约共用的基础类型与时间格式。"""
from datetime import datetime, timezone

from pydantic import BaseModel, ConfigDict


class ContractModel(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_assignment=True)


class ExtensibleModel(ContractModel):
    """允许保留已有扩展字段，数值字段拒绝 NaN 和 Infinity。"""

    model_config = ConfigDict(extra="allow", allow_inf_nan=False)


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
