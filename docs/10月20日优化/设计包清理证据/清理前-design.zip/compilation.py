"""设计投影与已明确原生参数的转换；保留离线视觉修订使用的编译适配器。"""
from __future__ import annotations

from collections import Counter
from copy import deepcopy

from .contracts import DesignDocument, ResolvedDesign, ResolvedLevel
from .facades import effective_facade

RESOLVER_VERSION = "drawing-projection/1"


def compile_document(document: DesignDocument):
    # Lazy boundary: the compiler consumes plan data and never imports this adapter.
    from app.agent.compiler import compile_design
    from .resolver import architecture_plan_from_document

    materials = document.decisions.materials.resolved_plan
    return compile_design(
        architecture_plan_from_document(document),
        user_message=document.requirements.source_request,
        material_plan=materials.model_dump(mode="json") if materials else None,
        normalized_input=True,
    )


def compile_native_marker(marker, blueprint, material_roles, schema):
    """直接转换已明确的原生参数；缺少设计或自定义形态仍交给既有模型实现。"""
    from app.design.relations import opening_host, opening_target, place_opening_group
    from app.agent.generation.material.plan import material_region_field
    from app.agent.generation.capability import capability_surface
    from app.agent.generation.component.registry import COMPONENT_REGISTRY
    from jsonschema import Draft202012Validator

    kind = marker['type']
    definition = next((value for value in schema['$defs'].values()
                       if value.get('properties', {}).get('type', {}).get('const') == kind), None)
    if definition is None:
        return None
    design = marker['design']
    if any(design.get(key) for key in ('geometry', 'path', 'profile', 'relation')):
        return None
    form = design.get('form') or {}
    properties = definition.get('properties', {})
    if not isinstance(form, dict) or set(form) - properties.keys():
        return None  # 开放的设计描述不能静默丢掉，尤其不能把自定义构造降为默认形态。
    entity = deepcopy(form)
    if entity.get('type', kind) != kind:
        return None
    entity.update(type=kind)
    entity.setdefault('id', marker['id'])
    size = design.get('size') or {}
    if not isinstance(size, dict) or set(size) - {'width', 'height', 'depth'}:
        return None
    position = (design.get('placement') or {}).get('position')
    parameters = {}
    if kind in {'door', 'window'}:
        if not all(type(size.get(k)) in (int, float) and size[k] > 0 for k in ('width', 'height')):
            return None
        wall = opening_host(blueprint, marker)
        if not wall or wall.get('curve') or any(k in form for k in ('parentWall', 'from')):
            return None
        if any(k in form and form[k] != size[k] for k in ('width', 'height')):
            raise ValueError('图纸 size 与原生 form 的门窗尺寸冲突，需显式修订图纸')
        diagram = marker.get('diagram_host') or wall
        target = opening_target(marker, diagram, size['width'], size['height'])
        if target is None:
            return None
        parameters.update(parentWall=diagram['id'], **{'from': target}, width=size['width'], height=size['height'])
        if 'depth' in size:
            parameters['frameDepth'] = size['depth']
        bindings = {'frameMaterial': 'frame', 'glassMaterial' if kind == 'window' else 'leafMaterial':
                    'glass' if kind == 'window' else 'door'}
        for field, role in bindings.items():
            if field not in entity:
                if material_roles.get(role) not in blueprint['materials']:
                    return None
                entity[field] = material_roles[role]
    elif kind == 'floor' and position and form.get('shape', 'rect') == 'rect':
        thickness = size.get('height', form.get('thickness'))
        if not all(type(v) in (int, float) and v > 0 for v in (size.get('width'), size.get('depth'), thickness)):
            return None
        x, y, z = position
        parameters.update({'from': [x-size['width']/2, y-thickness/2, z-size['depth']/2],
                           'to': [x+size['width']/2, y-thickness/2, z+size['depth']/2], 'thickness': thickness})
    elif kind == 'primitive' and entity.get('shape') == 'box' and position:
        if not all(k in size for k in ('width', 'height', 'depth')) and 'dimensions' not in entity:
            return None
        parameters['position'] = list(position)
        if size:
            if set(size) != {'width', 'height', 'depth'}:
                return None
            parameters['dimensions'] = [size[k] for k in ('width', 'height', 'depth')]
    elif size:
        return None  # 未声明尺寸到该原生形态的映射，不能静默忽略图纸尺寸。
    elif position and 'position' in properties:
        parameters['position'] = list(position)
    for key, value in parameters.items():
        if key in entity and entity[key] != value:
            raise ValueError(f'图纸定位/尺寸与原生 form.{key} 冲突，需显式修订图纸')
        entity[key] = value
    if kind == 'roof':
        roof_type = design.get('roof_type', design.get('type'))
        if roof_type not in {None, 'roof', *properties['roofType']['enum']}:
            return None
        if 'position' not in entity and not design.get('placement'):
            entity['position'] = (marker.get('entity') or {}).get('position')
    if 'position' in properties and entity.get('position') is None:
        return None
    if kind == 'light' and not any(k in entity for k in ('body', 'fixtureType')):
        return None
    # 其余原生类型只有在 form 已给齐引擎必需字段时才能直接采用，不猜板厚、坡高或踏步。
    required = set(definition.get('required', []))
    config = COMPONENT_REGISTRY.get(kind)
    if config:
        required.update(config.required_fields)
    if required - entity.keys():
        return None
    role = design.get('material_role')
    material_id = marker.get('material_id') or material_roles.get(role)
    if role and material_id in blueprint['materials']:
        field = material_region_field(role, kind)
        if field:
            entity.setdefault(field, material_id)
    errors = list(Draft202012Validator({**definition, '$defs': schema['$defs']}).iter_errors(entity))
    if errors:
        raise ValueError('原生参数不合法：' + '；'.join(f"/{'/'.join(map(str, e.path))}: {e.message}" for e in errors))
    bucket = capability_surface()[kind]['target']
    row = {'id': marker['id'], 'geometry': {'elements': [], 'components': []}, 'materials': {}, 'assets': {},
           'explanation': '按已批准原生参数直接转换，未调用模型'}
    row['geometry'][bucket] = [entity]
    if kind in {'door', 'window'}:
        row, changes = place_opening_group(blueprint, row, marker)
        row['assembly_changes'] = changes
    return row


def project_drawing(document: DesignDocument) -> ResolvedDesign:
    """从设计尺寸绘制示意，不运行 WILD 编译器。"""
    from .resolver import _stable_hash
    from .markers import component_markers
    from .coordinates import (representative_floor_indices, floor_elevations, design_geometry_context, floor_layout_conflicts,
                              design_relation_checks, opening_coordinate_errors, DesignCoordinateConflict)
    from .relations import opening_target
    from .openings import is_open_side
    from app.agent.knowledge.component_names import resolve_component_name

    d = document.decisions
    indices = representative_floor_indices(d.massing)
    elevations = floor_elevations(d.model_dump(mode="json"))
    layout_issues = floor_layout_conflicts(d.model_dump(mode="json"))
    if layout_issues:
        raise ValueError("；".join(layout_issues))
    geometry = design_geometry_context(d.model_dump(mode="json"))
    levels = [ResolvedLevel(**{key: level[key] for key in ("index", "base_y", "top_y")})
              for level in geometry["levels"]]
    walls, frames = [], {}
    for volume_index, v in enumerate(d.volumes):
        corners = {"front": ([v.x, v.z], [v.x+v.width, v.z]),
                   "right": ([v.x+v.width, v.z], [v.x+v.width, v.z+v.depth]),
                   "back": ([v.x+v.width, v.z+v.depth], [v.x, v.z+v.depth]),
                   "left": ([v.x, v.z+v.depth], [v.x, v.z])}
        for floor in range(v.start_floor, v.end_floor+1):
            for face, (a, b) in corners.items():
                facade = effective_facade(d.facades, v, face)
                frame = {"id": f"wall_{v.id}_{face}_L{floor}", "type": "wall",
                         "from": [a[0], elevations[indices[floor-1]], a[1]],
                         "to": [b[0], elevations[indices[floor-1]+1], b[1]], "facing": face,
                         "design_path": f"/decisions/volumes/{volume_index}"}
                if is_open_side(facade.ground_pattern if floor == 1 else facade.upper_pattern):
                    frame["open"] = True
                else:
                    walls.append(frame)
                frames[frame["id"]] = frame
    # 平面内墙也是主体的设计宿主；与外墙共用世界坐标和门窗定位协议。
    # 端点、厚度和 id 形状由 FloorWallDecision 保证；这里只查跨墙的语义冲突。
    for index, layout in enumerate(d.model_dump(mode="json").get("floor_layouts") or []):
        floor = layout.get("floor")
        if floor not in elevations or floor > d.massing.floors:
            continue
        for j, wall in enumerate(layout.get("walls") or []):
            path = f"/decisions/floor_layouts/{index}/walls/{j}"
            if wall["id"] in frames or wall["from"] == wall["to"]:
                raise ValueError(f"{path}：内墙 id 必须全局唯一，from/to 不能是同一端点")
            frame = {"id": wall["id"], "type": "wall", "thickness": wall["thickness"],
                     "from": [wall["from"][0], elevations[floor], wall["from"][1]],
                     "to": [wall["to"][0], elevations[floor+1], wall["to"][1]], "design_path": path}
            frames[frame["id"]] = frame
            walls.append(frame)
    markers = component_markers(document)
    material_ids = {role.role: role.materialId for role in d.materials.resolved_plan.roles} if d.materials.resolved_plan else {}
    for marker in markers:
        role = marker["design"].get("material_role")
        if role in material_ids:
            marker["material_id"] = material_ids[role]
    for marker in markers:
        if marker["host"] in frames:
            marker["diagram_host"] = frames[marker["host"]]
            size = marker["design"].get("size") or {}
            if (resolve_component_name(marker["type"])["entity_type"] in {"door", "window"}
                    and marker["entity"].get("position") and size.get("width") and size.get("height")):
                marker["entity"]["from"] = opening_target(marker, marker["diagram_host"], size["width"], size["height"])
    relation_errors, relation_reviews = design_relation_checks(d.model_dump(mode="json"), markers, frames)
    relation_errors.extend({"code": "design_opening_conflict", "path": message.partition("：")[0],
                            "reason": message.partition("：")[2]}
                           for message in opening_coordinate_errors(markers))
    from .spatial_review import review_design_paths
    path_review = review_design_paths(d.model_dump(mode="json"), markers, frames)
    relation_errors.extend({'code': 'design_circulation_conflict', 'path': issue['design_path'],
                            'reason': issue['message']} for issue in path_review['errors'])
    if relation_errors:
        raise DesignCoordinateConflict(relation_errors)
    warnings = ["图纸为设计示意；构件形态由 plan 尝试实现，未定位标记列于图纸清单。"]
    for layout in d.model_dump(mode="json").get("floor_layouts") or []:
        rooms, partitions = layout.get("rooms") or [], layout.get("walls") or []
        if len(rooms) > 1 and not partitions:
            warnings.append(f"第 {layout.get('floor', '?')} 层有多个房间标签但没有内墙；请确认是否为开放式布局。")
        if partitions and not any(c.host in {w.get("id") for w in partitions}
                                  and (c.type == "opening" or resolve_component_name(c.type)["entity_type"] == "door")
                                  for c in d.components):
            warnings.append(f"第 {layout.get('floor', '?')} 层有内墙但没有附着其上的通行开口；请核对实际动线。")
    return ResolvedDesign(
        design_id=document.design_id, design_revision=document.revision,
        design_hash=_stable_hash(document), resolver_version=RESOLVER_VERSION,
        bounds={"width": max(v.x+v.width for v in d.volumes)-min(v.x for v in d.volumes),
                "depth": max(v.z+v.depth for v in d.volumes)-min(v.z for v in d.volumes),
                "height": elevations[d.massing.floors+1]-elevations[1]},
        levels=levels, volumes=d.volumes, facade_slots=[], projection_elements=walls,
        design_gaps=[{"id": "relation." + str(i), "constraint_id": "design.relationship",
                      "status": "needs_review", "design_hash": _stable_hash(document),
                      "target": review["marker_id"], "expected": review.get("expected", review["path"]),
                      "actual": review.get("actual"), "evidence": review["reason"]}
                     for i, review in enumerate(relation_reviews)],
        component_markers=markers, component_quantities=dict(Counter(m["type"] for m in markers)),
        warnings=warnings,
    )
