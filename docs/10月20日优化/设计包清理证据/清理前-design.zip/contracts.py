"""设计文档的管理外壳、修改协议和解析结果；保留既有导入入口。

新建筑图纸见 facts.DesignFacts；本模块暂为未迁移的生成链提供旧契约。
后续节点迁移后，再删除对应的旧类型及其消费者。
"""
from __future__ import annotations

from typing import Any, Annotated, Literal

from pydantic import Field, model_validator

from .base import ContractModel, utc_now_iso
from .legacy_architecture import (
    ComplexityDecision,
    MassingTierDecision,
    MassingDecision,
    VolumeDecision,
    StructuralGridDecision,
    OpeningToken,
    FacadeDecision,
    RoofVolumeOverride,
    RoofDecision,
    CurtainWallDecision,
    EnvelopeDecision,
    CirculationPath,
    CirculationDecision,
    SupportRelation,
    ComponentPlacement,
    FloorConnection,
    StairStepDesign,
    ComponentInstance,
    ArchitectureIntent,
    Coordinate,
    FloorBounds,
    FloorRoomDecision,
    FloorWallDecision,
    FloorLayoutDecision,
    ArchitectureDecisions,
)
from .materials import (
    ARCHITECTURE_MATERIAL_ROLES, OBJECT_MATERIAL_ROLES, MATERIAL_ROLES,
    ArchitectureMaterialRoleName, ObjectMaterialRoleName, MaterialRoleName,
    ResolvedMaterialRole, ResolvedMaterialPlan, MaterialRegion, MaterialIntent,
)
from .objects import ComponentObject, ObjectDecisions


# 用户需求、约束及规则采用记录。
class DesignRequirements(ContractModel):
    source_request: str = Field(min_length=1, max_length=8000)
    building_type: str = Field(default="building", min_length=1, max_length=80)
    profile: str = Field(default="custom", min_length=1, max_length=80)
    style_intent: list[str] = Field(default_factory=list, max_length=12)


class DesignConstraint(ContractModel):
    id: str = Field(min_length=1, max_length=120)
    kind: Literal[
        "user_hard", "engine_hard", "system_required", "preference", "reference"
    ]
    target: str = Field(min_length=1, max_length=240)
    expression: str = Field(min_length=1, max_length=1000)
    source: str = Field(default="", max_length=500)
    expected: Any = None
    check: Literal["equals", "contains", "minimum", "absent", "manual"] = "manual"
    adoption: Literal["adopted", "proposed", "superseded"] = "adopted"
    source_quote: str = Field(default="", max_length=1000)
    supersedes: str | None = None


class RuleTrace(ContractModel):
    rule_id: str = Field(min_length=1, max_length=160)
    classification: Literal[
        "engine_hard", "conditional", "preference", "reference", "unsupported"
    ]
    applies_when: str = Field(default="", max_length=500)
    schema_targets: list[str] = Field(default_factory=list, max_length=20)
    enforcement: list[
        Literal["schema", "planner", "resolver", "compiler", "validator", "none"]
    ]
    source: str = Field(default="", max_length=500)
    # Field-level diagnostic evidence, never input for compilation.
    changes: list[dict[str, Any]] = Field(default_factory=list)
    design_revision: int | None = None


DesignDecisions = Annotated[ArchitectureDecisions | ObjectDecisions, Field(discriminator="kind")]


class DesignDocument(ContractModel):
    schema_version: Literal["design/1.0"] = "design/1.0"  # 文档格式版本
    design_id: str = Field(min_length=1, max_length=120)  # 图纸 ID
    session_id: str = Field(min_length=1, max_length=160)  # 所属会话
    revision: int = Field(ge=1)  # 修订号
    status: Literal["draft", "approved", "compiled"] = "draft"  # 草稿、已批准或已编译
    created_at: str = Field(default_factory=utc_now_iso)  # 创建时间
    updated_at: str = Field(default_factory=utc_now_iso)  # 更新时间
    approved_at: str | None = None  # 批准时间
    requirements: DesignRequirements  # 用户需求
    decisions: DesignDecisions  # 建筑或物件的设计主体
    constraints: list[DesignConstraint] = Field(default_factory=list, max_length=100)  # 本次需要满足的条件
    locks: list[str] = Field(default_factory=list, max_length=100)  # 锁定字段路径
    rule_trace: list[RuleTrace] = Field(default_factory=list, max_length=200)  # 规则采用与字段变更记录

    @model_validator(mode="before")
    @classmethod
    def _default_decisions_kind(cls, data: Any) -> Any:
        """兼容历史 schema_version 与缺失的建筑 kind；不猜测物件类型。"""

        if not isinstance(data, dict):
            return data
        if data.get("schema_version") in {"design/1.1", "design/1.2", "design/1.3"}:
            data = {**data, "schema_version": "design/1.0"}
        decisions = data.get("decisions")
        if isinstance(decisions, dict) and not decisions.get("kind"):
            return {**data, "decisions": {**decisions, "kind": "architecture"}}
        return data

    @model_validator(mode="after")
    def design_semantics_are_valid(self):
        if isinstance(self.decisions, ObjectDecisions):
            return self._object_semantics_are_valid()
        return self._architecture_semantics_are_valid()

    def _object_semantics_are_valid(self):
        """物件场景的不变量：无体量、无立面，只有物件与材质。"""

        decisions = self.decisions
        assert isinstance(decisions, ObjectDecisions)
        if not decisions.objects and not decisions.unsupported_objects:
            raise ValueError(
                "物件方案必须至少给出一条 objects，或用 unsupported_objects 如实说明"
                "哪些物件本次表达不出来；两者同时为空等于没有方案"
            )
        seen: set[tuple[str, str, str]] = set()
        for item in decisions.objects:
            # 去重键含 name：通用几何与人物通道的 subtype 是空串，
            # 只用 (kind, subtype) 会把"花瓶"和"路灯"折成同一条。
            key = (item.kind, item.subtype, item.name)
            if key in seen:
                raise ValueError(
                    f"重复的物件条目 {item.kind}/{item.subtype or item.name or '-'}；"
                    "同类物件请用 count 表达数量，不要重复列出"
                )
            seen.add(key)
        return self

    def _architecture_semantics_are_valid(self):
        decisions = self.decisions
        assert isinstance(decisions, ArchitectureDecisions)
        massing = decisions.massing
        if (
            massing.representation_mode == "full"
            and massing.modeled_floors != massing.floors
        ):
            raise ValueError("full 模式必须让 modeled_floors 等于 floors")
        seen: set[str] = set()
        for volume in decisions.volumes:
            if volume.id in seen:
                raise ValueError(f"重复 volume id: {volume.id}")
            seen.add(volume.id)
            if volume.end_floor > massing.modeled_floors:
                raise ValueError(f"volume {volume.id} 超出 modeled_floors")
        from .coordinates import (
            DesignCoordinateConflict,
            volume_conflicts,
            floor_elevations,
        )

        floor_elevations(decisions.model_dump())
        conflicts = volume_conflicts(
            [v.model_dump(mode="json") for v in decisions.volumes],
            massing.model_dump(mode="json"),
        )
        if conflicts:
            raise DesignCoordinateConflict(conflicts)
        for floor in range(1, massing.modeled_floors + 1):
            if not any(
                volume.start_floor <= floor <= volume.end_floor
                for volume in decisions.volumes
            ):
                raise ValueError(f"第 {floor} 建模层没有任何 volume 覆盖")
        required_faces = {"front", "back", "left", "right"}
        if set(decisions.facades) != required_faces:
            raise ValueError("facades 必须完整包含 front/back/left/right")
        instance_ids = [c.id for c in decisions.components if c.id]
        if len(instance_ids) != len(set(instance_ids)):
            raise ValueError("构件实例 id 必须唯一，不能把同一实体用于多条关系")
        return self


# 修改协议；不属于模型需要设计的建筑字段。
class DesignPatchOperation(ContractModel):
    op: Literal["add", "replace", "remove"]
    path: str = Field(min_length=1, max_length=500, pattern=r"^/")
    value: Any = None


class DesignPatch(ContractModel):
    type: Literal["design_patch"] = "design_patch"
    patch_id: str = Field(min_length=1, max_length=160)
    base_revision: int = Field(ge=1)
    source: Literal["user", "agent", "system"] = "user"
    operations: list[DesignPatchOperation] = Field(min_length=1, max_length=100)
    summary: str = Field(default="", max_length=500)


# 程序解析结果；不要求 architecture 模型重复填写这些数据。
class ResolvedLevel(ContractModel):
    index: int = Field(ge=1)
    base_y: float
    top_y: float


class DesignGap(ContractModel):
    id: str
    constraint_id: str
    layer: Literal["design", "implementation", "execution"] = "design"
    status: Literal["satisfied", "open", "needs_review", "unsupported"]
    design_hash: str
    target: str
    expected: Any = None
    actual: Any = None
    evidence: str


class ResolvedFacadeSlot(ContractModel):
    id: str
    facing: Literal["front", "back", "left", "right"]
    floor: int = Field(ge=1)
    bay: int = Field(ge=1)
    type: Literal["door", "window", "bay_window"]
    parent_wall: str = ""
    local_from: list[float] = Field(default_factory=list)
    world_from: list[float] = Field(default_factory=list)
    world_to: list[float] = Field(default_factory=list)
    offset: float
    width: float = Field(gt=0)
    bottom: float = Field(ge=0)
    height: float = Field(gt=0)


class ResolvedDesign(ContractModel):
    schema_version: Literal["resolved-design/1.0"] = "resolved-design/1.0"
    design_id: str
    design_revision: int = Field(ge=1)
    design_hash: str = Field(pattern=r"^sha256:[0-9a-f]{64}$")
    resolver_version: str = "legacy"
    component_markers: list[dict[str, Any]] = Field(default_factory=list)
    projection_elements: list[dict[str, Any]] = Field(
        default_factory=list, exclude=True
    )
    design_gaps: list[DesignGap] = Field(default_factory=list)
    compile_blockers: list[dict[str, Any]] = Field(default_factory=list)
    bounds: dict[Literal["width", "depth", "height"], float]
    levels: list[ResolvedLevel]
    volumes: list[VolumeDecision]
    facade_slots: list[ResolvedFacadeSlot]
    component_quantities: dict[str, int]
    warnings: list[str] = Field(default_factory=list)
