"""建筑设计事实：米；X 向东、Y 向上、Z 向北；rect=[西,东,南,北]。

这里只记录设计输入。审核、版本、配额、WILD 参数和计算结果不属于图纸。
"""
from __future__ import annotations

from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, AfterValidator, model_validator


Number = Annotated[float, Field(allow_inf_nan=False)]
Positive = Annotated[Number, Field(gt=0)]
Nonnegative = Annotated[Number, Field(ge=0)]
Point = tuple[Number, Number]
Id = Annotated[str, Field(min_length=1, pattern=r"^[A-Za-z][A-Za-z0-9_-]*$")]


def _ordered_rectangle(value):
    if value[0] >= value[1] or value[2] >= value[3]:
        raise ValueError("rect 必须满足 西<东、南<北")
    return value


Rect = Annotated[tuple[Number, Number, Number, Number], AfterValidator(_ordered_rectangle)]


class Fact(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)


class DesignFacts(Fact):
    """图纸字段总表；数值是设计选择，重复引用通过楼层和实体 ID 表达。"""

    name: str = Field(min_length=1)  # 建筑名称
    units: Literal["m"] = "m"  # 固定单位，由程序补齐
    levels: dict[Id, Number]  # 楼面顶、顶部板面的世界标高；程序按高度排序
    slab_thickness: Positive  # 楼板厚度；墙顶=对应上层板顶-板厚
    site: Rect | None = None  # 场地范围，可省略
    volumes: list[Volume] = Field(min_length=1)  # 体量平面边界与起终楼面
    room_zones: list[RoomZone] = Field(default_factory=list)  # 房间用途与占地
    voids: list[Void] = Field(default_factory=list)  # 非楼梯挑空；梯井由程序生成
    walls: list[Wall] = Field(default_factory=list)  # 独立内墙；外围护由体量推导
    openings: list[Opening] = Field(default_factory=list)  # 门窗、通行洞口
    stairs: list[Stair] = Field(default_factory=list)  # 连接、方向、占地和踏步设计依据
    roofs: list[Roof] = Field(default_factory=list)  # 每个体量明确选择屋面或敞开
    components: list[Component] = Field(default_factory=list)  # 家具、栏杆、廊架及场地构件
    routes: list[Route] = Field(default_factory=list)  # 指定楼层的平面通路
    material_roles: dict[Id, Annotated[str, Field(min_length=1)]] = Field(default_factory=dict)  # 材质角色→材料描述
    use_clearances: Clearances = Field(default_factory=lambda: Clearances())  # 本次选择的净距
    features_to_verify: list[str] = Field(default_factory=list)  # 人工复核清单，不是已通过证明
    scope_limits: list[str] = Field(default_factory=list)  # 本次表达与验证边界


class Volume(Fact):
    id: Id
    rect: Rect
    bottom: Id  # 起始楼面引用
    top: Id  # 顶部板面引用，不重复填写墙顶高度
    wall_thickness: Positive = 0.24
    material_role: Id = "body"


class RoomZone(Fact):
    id: Id
    name: str = Field(min_length=1)
    rect: Rect
    level: Id
    volume: Id


class Void(Fact):
    id: Id
    rect: Rect
    level: Id  # 从这层楼板扣除
    volume: Id


class Wall(Fact):
    id: Id
    start: Point  # 世界 X/Z 起点
    end: Point  # 世界 X/Z 终点
    level: Id
    top: Id | None = None  # 省略时采用相邻上层，墙顶仍扣板厚
    thickness: Positive = 0.18
    material_role: Id = "body"


class Opening(Fact):
    id: Id
    type: Literal["door", "window", "opening"]
    host: Id  # 体量或独立内墙 ID
    face: Literal["front", "back", "left", "right"] | None = None  # 体量宿主必填
    level: Id
    offset: Nonnegative  # 沿宿主起点的距离，不是世界 X
    sill: Nonnegative = 0  # 相对楼面的底部高度
    width: Positive
    height: Positive
    style: Literal["fixed", "swing", "slide", "open"]
    frame_role: Id | None = None
    panel_role: Id | None = None
    divisions: tuple[Annotated[int, Field(ge=0)], Annotated[int, Field(ge=0)]] = (0, 0)


class Stair(Fact):
    id: Id
    volume: Id
    rect: Rect  # 整组可用占地，含平台
    from_level: Id
    to_level: Id
    shape: Literal["straight", "U", "L"]
    direction: Literal["+x", "-x", "+z", "-z"]  # 第一跑上行方向
    flight_width: Positive
    landing_depth: Nonnegative = 0
    tread_depth: Positive
    max_riser_height: Positive  # 本次设计选择，不是规范引用
    steps_each: Annotated[int, Field(ge=1)] | None = None  # 有明确级数要求时填写
    material_role: Id = "timber"


class Roof(Fact):
    id: Id
    volume: Id
    type: Literal["flat", "gable", "hip", "shed", "none"]
    overhang: tuple[Nonnegative, Nonnegative, Nonnegative, Nonnegative] = (0, 0, 0, 0)  # 西、东、南、北挑出
    rise: Nonnegative = 0  # 坡屋面起拱高度；平屋面不重复填写板厚
    ridge_axis: Literal["x", "z"] = "x"
    walkable: bool = False
    parapet_height: Nonnegative = 0
    material_role: Id = "roof"


class Component(Fact):
    """按配方实现的局部构件；位置、尺寸、材料及配方参数全部留在图纸中。"""

    id: Id
    recipe: Id  # 家具/栏杆/廊架等配方名称；下一阶段由编译器核对配方是否实现
    level: Id
    rect: Rect | None = None  # 未旋转时的占地，围绕中心旋转
    path: list[Point] = Field(default_factory=list)  # 线状构件的水平路径
    height: Positive
    anchor: Literal["bottom", "top"] = "bottom"  # 板类可用顶面对齐楼面，程序计算底面
    elevation_offset: Number = 0  # anchor 相对楼面的高度；家具默认底面落地
    rotation: Number = 0  # 绕 Y 轴角度，单位度
    material_roles: dict[str, Id] = Field(default_factory=dict)  # 配方部位→全局材质角色
    parameters: dict[str, str | Number | bool] = Field(default_factory=dict)  # 配方的明确参数
    repeat: Repeat | None = None  # 相同构件平移阵列，逐件位置由程序展开

    @model_validator(mode="after")
    def one_footprint(self):
        if (self.rect is None) == (not self.path):
            raise ValueError("构件必须且只能选择 rect 或 path")
        if self.path and (len(self.path) < 2 or any(a == b for a, b in zip(self.path, self.path[1:]))):
            raise ValueError("path 至少两个点，相邻点不能相同")
        return self


class Repeat(Fact):
    count: Annotated[int, Field(ge=1)]
    step: Point  # 每次平移的世界 X/Z 距离


class Route(Fact):
    id: Id
    level: Id
    points: list[Point] = Field(min_length=2)
    width: Positive
    height: Positive


class Clearances(Fact):
    main_routes_width: Positive = 0.9
    route_headroom: Positive = 2.05
    upper_stair_exit_width: Positive = 1.2
    bedside_minimum: Nonnegative = 0.6


DesignFacts.model_rebuild()
