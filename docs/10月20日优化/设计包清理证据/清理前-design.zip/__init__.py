"""建筑设计事实；旧生成链的契约入口在迁移期间保留。"""

from .facts import DesignFacts
from .resolve_facts import resolve_facts

from .contracts import DesignDocument, DesignPatch, ResolvedDesign
from .repository import design_repository
from .resolver import (
    architecture_plan_from_document,
    build_design_document,
    resolve_design,
    render_design_svg,
)

__all__ = [
    "DesignFacts",
    "resolve_facts",
    "DesignDocument",
    "DesignPatch",
    "ResolvedDesign",
    "architecture_plan_from_document",
    "build_design_document",
    "design_repository",
    "resolve_design",
    "render_design_svg",
]
