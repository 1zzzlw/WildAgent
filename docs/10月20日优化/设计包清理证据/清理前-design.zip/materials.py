"""建筑和物件共用的材质意图、角色及解析结果。"""
from typing import Any, Literal

from pydantic import Field, model_validator

from .base import ContractModel, ExtensibleModel


#: 材质角色名的唯一来源。`material/plan.py` 的 ROLE_SPECS 必须与它同键。
ARCHITECTURE_MATERIAL_ROLES = (
    "facade_primary",
    "structure",
    "floor",
    "frame",
    "door",
    "glass",
    "roof",
    "ground",
    "accent",
)
ArchitectureMaterialRoleName = Literal[*ARCHITECTURE_MATERIAL_ROLES]

#: 物件侧角色按材质本身命名；物件没有承重墙、楼板、龙骨这类建筑语义。
#: 注意物件侧用 `metal`，建筑侧用 `frame`（见 material/plan.py 的 _METALLIC_ROLES）。
OBJECT_MATERIAL_ROLES = ("wood", "metal", "glass", "stone", "fabric", "accent")
ObjectMaterialRoleName = Literal[*OBJECT_MATERIAL_ROLES]

#: 两者并集。ResolvedMaterialPlan 被建筑与物件共用，角色名必须覆盖两张表。
#: 去重后只保留一份 Literal，避免再手抄第三份角色清单。
MATERIAL_ROLES = tuple(dict.fromkeys((*ARCHITECTURE_MATERIAL_ROLES, *OBJECT_MATERIAL_ROLES)))
MaterialRoleName = Literal[*MATERIAL_ROLES]


class ResolvedMaterialRole(ContractModel):
    role: MaterialRoleName
    materialId: str = Field(min_length=1, max_length=80)
    assetId: str | None = Field(default=None, max_length=200)
    proceduralPresetId: str | None = Field(default=None, max_length=120)
    material: dict[str, Any]


class ResolvedMaterialPlan(ContractModel):
    concept: str = Field(default="", max_length=160)
    palette: list[str] = Field(default_factory=list, max_length=5)
    roles: list[ResolvedMaterialRole] = Field(default_factory=list, max_length=20)
    resolvedAssets: dict[str, dict[str, Any]] = Field(default_factory=dict)
    rejectedAssetIds: list[str] = Field(default_factory=list)
    rejectedProceduralPresetIds: list[str] = Field(default_factory=list)
    curtainWall: bool = False

    @model_validator(mode="after")
    def material_roles_are_unique(self):
        roles = [item.role for item in self.roles]
        material_ids = [item.materialId for item in self.roles]
        if len(roles) != len(set(roles)):
            raise ValueError("材质方案 role 不能重复")
        if len(material_ids) != len(set(material_ids)):
            raise ValueError("材质方案 materialId 不能重复")
        return self


class MaterialRegion(ContractModel):
    """按实体类型绑定材质角色；实际材质参数由材质方案提供。"""

    role: str = Field(min_length=1, max_length=60)
    type: str = Field(min_length=1, max_length=60)
    note: str = Field(default="", max_length=200)


class MaterialIntent(ExtensibleModel):
    keywords: list[str] = Field(default_factory=list)
    resolved_plan: ResolvedMaterialPlan | None = None
    #: 区域/构件材质绑定（P5-C）。空列表 ⇒ 全部按类型默认角色，与引入前逐字段一致。
    regions: list[MaterialRegion] = Field(default_factory=list, max_length=20)
