"""有效立面的唯一合并入口。

共享 facades 作用于全部体量，volume.facades 只覆盖指定面。
体量值是完整 FacadeDecision 时整体覆盖；plan 中的字典形式按字段合并。
"""
from __future__ import annotations

from typing import Any


def _volume_facades(volume: Any) -> dict[str, Any]:
    if volume is None:
        return {}
    if isinstance(volume, dict):
        return volume.get("facades") or {}
    return getattr(volume, "facades", {}) or {}


def effective_facade(shared_facades: dict[str, Any], volume: Any, face: str) -> Any:
    """返回某一面的有效立面；体量未覆盖时回落到共享立面。"""
    shared = (shared_facades or {}).get(face)
    local = _volume_facades(volume).get(face)
    if local is None or local == {}:
        return shared
    if isinstance(shared, dict) and isinstance(local, dict):
        return {**shared, **local}
    return local


def effective_facades(shared_facades: dict[str, Any], volume: Any) -> dict[str, Any]:
    """返回该体量全部面的有效立面，保留共享立面中未被覆盖的面。"""
    result = dict(shared_facades or {})
    for face in _volume_facades(volume):
        result[face] = effective_facade(shared_facades, volume, face)
    return result
