"""生成交付边界回归；按用户要求本轮不执行。"""
from copy import deepcopy
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app.services.agent_delivery import (
    GenerationRejectedError,
    prepare_blueprint_delivery,
    retain_generation_blueprint,
)


class GenerationDelivery(unittest.TestCase):
    def test_empty_placeholder_is_not_a_generation_artifact(self):
        empty={"meta":{"name":"未命名建筑"},"geometry":{"elements":[],"components":[]}}
        state={"status":"failed","current_blueprint":empty,"final_blueprint":deepcopy(empty)}
        self.assertIsNone(retain_generation_blueprint(state,deepcopy(empty)))
        with patch("app.services.agent_delivery.save_blueprint_file_as") as save:
            with self.assertRaises(GenerationRejectedError):
                prepare_blueprint_delivery(empty,"session",[],status="failed")
        save.assert_not_called()

    def test_failed_generation_keeps_existing_entities_and_failed_fragments(self):
        wall={"id":"wall","type":"wall","from":[0,0,0],"to":[4,3,0],"thickness":0.2}
        component={"id":"window","type":"window","parentWall":"wall","from":[1,1,0],"width":1,"height":1}
        state={"status":"failed","component_fragments":{"body":[wall]},
               "component_diagnostics":{"opening":{"failed_implementations":{"window":{
                   "geometry":{"components":[component]},"materials":{"glass":{"opacity":0.2}}
               }}}}}
        before=deepcopy(state)
        result=retain_generation_blueprint(state)
        self.assertEqual([wall],result["geometry"]["elements"])
        self.assertEqual([component],result["geometry"]["components"])
        self.assertEqual(before,state)
        with patch("app.services.agent_delivery.save_blueprint_file_as") as save:
            delivery=prepare_blueprint_delivery(result,"session",[],status="failed")
        save.assert_called_once()
        self.assertFalse(delivery.validation_passed)
        self.assertEqual((1,1),(delivery.elements_count,delivery.components_count))


if __name__ == "__main__":
    unittest.main()
