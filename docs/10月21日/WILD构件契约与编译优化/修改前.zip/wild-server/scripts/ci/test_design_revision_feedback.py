"""设计输出与修订反馈的回归定义；用户要求暂停测试，本轮不执行。"""
import json
from pathlib import Path
from types import SimpleNamespace
import sys
import unittest
from unittest.mock import AsyncMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app.agent.generation.architecture.design_workflow import _repair_paths, draft_design
from app.agent.generation.architecture.workflow import _validation_reason
from app.design.coordinates import DesignCoordinateConflict, resolve_stair_geometry
from app.utils.json_extractor import extract_json_object


def response(content):
    return SimpleNamespace(content=content, token_usage=None, call_id="fixture", finish_reason="stop")


class DesignFeedback(unittest.TestCase):
    def test_malformed_outer_object_cannot_become_a_nested_design(self):
        malformed='{"massing":{"floors":2},"placement":{"position":[0,4.2+1.2,0]}}'
        with self.assertRaisesRegex(ValueError, "JSON 格式错误.*4.2"):
            extract_json_object(malformed, required_key="massing", outer_only=True, raise_on_error=True)
        with self.assertRaisesRegex(ValueError, "JSON 格式错误"):
            extract_json_object('{"operations":[{"value":{"x":1}},]}', required_key="operations",
                                outer_only=True, raise_on_error=True)

    def test_all_conflict_paths_survive_long_feedback(self):
        message="/floor_layouts/0/rooms/0：" + "坐标说明"*100 + "；/floor_layouts/1/rooms/3：另一处墙房冲突"
        reason=_validation_reason(ValueError(message))
        self.assertIn("/floor_layouts/1/rooms/3", reason)
        self.assertEqual(["/floor_layouts/0", "/floor_layouts/1"],
                         _repair_paths(reason, {}, {"floor_layouts"}))

    def test_stair_error_identifies_position_vector(self):
        marker={"id":"stair", "design_path":"/decisions/components/3",
                "floor_connections":[{"from_y":0,"to_y":3.4,"to_floor":2}],
                "design":{"placement":{"position":[5,2,5]},"size":{"width":4.1,"depth":2.6},
                          "form":{"shape":"U","flights":2,"span_direction":"+x",
                                  "flight_width":1.2,"landing_depth":1.2}}}
        with self.assertRaises(ValueError) as captured:
            resolve_stair_geometry(marker)
        reason=str(captured.exception)
        self.assertIn("/components/3/placement/position", reason)
        self.assertIn("中心 Y 应为 1.7", reason)
        self.assertEqual(["/components/3"], _repair_paths(reason, {}, {"components"}))

    def test_host_feedback_exposes_effective_walls_and_enclosure_repair(self):
        exc=DesignCoordinateConflict([{"path":"/decisions/components/0/host", "reason":"宿主不存在"}],
            context={"host_rule":"open=true 无墙；需要封闭时修订 /facades 或 /volumes",
                     "wall_hosts":[{"id":"wall_main_front_L1","open":True}]})
        reason=_validation_reason(exc)
        self.assertIn("wall_main_front_L1",reason)
        self.assertIn('"open": true',reason)
        paths=_repair_paths(reason,{"facades":{},"volumes":[]},{"components","facades","volumes"})
        self.assertTrue({"/components/0","/facades","/volumes"} <= set(paths))


class RevisionLoop(unittest.IsolatedAsyncioTestCase):
    async def test_syntax_repair_keeps_original_design_text(self):
        bad='{"massing":{"floors":2},"components":[{"id":"stable","placement":{"position":[0,4.2+1.2,0]}}]}'
        good={"massing":{"floors":2},"components":[{"id":"stable","placement":{"position":[0,5.4,0]}}]}
        invoke=AsyncMock(side_effect=[response(bad),response(json.dumps(good))])
        with patch("app.agent.generation.architecture.design_workflow.create_llm"), \
             patch("app.agent.generation.architecture.design_workflow.invoke_llm",invoke):
            result,diag=await draft_design(base_prompt="完整设计 JSON",user_request="别墅",thinking_mode=False)
        self.assertEqual(good,result)
        self.assertEqual(2,diag["model_calls"])
        self.assertIn(bad,invoke.call_args_list[1].args[1][0]["content"])
        self.assertIn("JSON 格式错误",diag["rejected_attempts"][0]["issue"])

    async def test_new_error_replaces_previous_component_scope(self):
        design={"massing":{"floors":2},"volumes":[],
                "components":[{"id":f"part_{i}","placement":{"position":[0,0,0]}} for i in range(5)]}
        replies=[response(json.dumps(design)),
                 response(json.dumps({"operations":[{"op":"add","path":"/components/4/material_bindings","value":{"material":"stone"}}]})),
                 response(json.dumps({"operations":[{"op":"replace","path":"/components/3/placement/position/1","value":1.75}]}))]
        checked=0

        def validate(candidate):
            nonlocal checked
            checked+=1
            if checked==1: raise ValueError("/components/4/material_bindings：材料字段不合法")
            if checked==2: raise ValueError("/components/3/placement/position：中心 Y 应为 1.75")

        invoke=AsyncMock(side_effect=replies)
        with patch("app.agent.generation.architecture.design_workflow.create_llm") as create, \
             patch("app.agent.generation.architecture.design_workflow.invoke_llm",invoke):
            result,diag=await draft_design(base_prompt="完整设计 JSON",user_request="别墅",thinking_mode=True,validate=validate)
        self.assertTrue(diag["settled"])
        self.assertEqual(1.75,result["components"][3]["placement"]["position"][1])
        prompt=invoke.call_args_list[2].args[1][0]["content"]
        self.assertIn('允许修改的范围：["/components/3"]',prompt)
        schema=json.loads(prompt.split("\n相关字段 Schema：",1)[1].split("\n图纸校验错误：",1)[0])
        self.assertEqual({"components"},set(schema["properties"]))
        form=schema["$defs"]["ComponentInstance"]["allOf"][0]["then"]["properties"]["form"]
        self.assertIn("span_direction",form["required"])
        self.assertEqual(["+x","-x","+z","-z"],form["properties"]["span_direction"]["enum"])
        self.assertEqual([True,True,True],[call.kwargs["enable_thinking"] for call in create.call_args_list])

    async def test_unlocated_new_error_does_not_reuse_old_scope(self):
        design={"massing":{"floors":2},"volumes":[],"components":[{"id":"part"}]}
        replies=[response(json.dumps(design)),response('{"operations":[{"op":"add","path":"/components/0/description","value":"修订"}]}')]
        checked=0

        def validate(candidate):
            nonlocal checked
            checked+=1
            raise ValueError("/components/0/description：需要修订" if checked==1 else "新错误没有字段路径")

        invoke=AsyncMock(side_effect=replies)
        with patch("app.agent.generation.architecture.design_workflow.create_llm"), \
             patch("app.agent.generation.architecture.design_workflow.invoke_llm",invoke):
            result,diag=await draft_design(base_prompt="完整设计 JSON",user_request="别墅",validate=validate)
        self.assertEqual({},result)
        self.assertTrue(diag["repair_scope_missing"])
        self.assertEqual(2,invoke.await_count)
        self.assertEqual("part",diag["last_candidate"]["components"][0]["id"])


if __name__ == "__main__":
    unittest.main()
