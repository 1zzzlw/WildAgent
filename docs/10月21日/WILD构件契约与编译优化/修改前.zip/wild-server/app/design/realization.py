"""将参数齐全的设计直接落实为 WILD；未覆盖的形态返回 None，沿用模型通道。"""
from copy import deepcopy

from .coordinates import repetition_geometry


def realize_marker(marker, context):
    from app.agent.generation.capability import capability_surface
    from app.agent.knowledge.component_names import resolve_component_name

    design = marker["design"]
    form = design.get("form") or {}
    if not isinstance(form, dict) or design.get("relation"):
        return None
    if any(t["coordinate"] is None for t in context.get("connection_targets", {}).get(marker["id"], [])):
        return None
    family = resolve_component_name(marker["type"])["entity_type"]
    materials = context["existing_blueprint"]["materials"]
    roles = {r["role"]: r["materialId"] for r in
             ((context["drawing"].get("materials") or {}).get("resolved_plan") or {}).get("roles", [])}
    def material(role):
        names = [n for n in ((design.get("material_bindings") or {}).get("material"),
                            marker.get("material_id"), form.get("material")) if n]
        if any(not isinstance(n, str) for n in names) or len(set(names)) > 1:
            return None
        name = next(iter(names), roles.get(role))
        return name if isinstance(name, str) and name in materials else None

    mid = marker["id"]
    elements, components = [], []
    if marker["type"] == "building_body":
        if (design.get("body_components") or (design.get("materials") or {}).get("regions")
                or design.get("structural_grid", {}).get("system") not in {"wall_bearing", "masonry", "solid_wall"}
                or design.get("envelope", {}).get("system") not in {"solid_wall", "wall_bearing", "masonry"}
                or any(m["type"] in {"wall", "floor", "column", "beam"} for m in context["delegated_markers"])):
            return None
        wall_material, floor_material = roles.get("facade_primary"), roles.get("floor")
        if wall_material not in materials or floor_material not in materials:
            return None
        thickness = context["construction"]["slab_thickness"]
        for level in context["levels"]:
            for index, (x0,z0,x1,z1) in enumerate(level["floor_rectangles"]):
                elements.append({"id": f"{mid}_L{level['index']}_{index}", "type": "floor",
                    "from": [x0,level["slab_bottom_y"],z0], "to": [x1,level["slab_bottom_y"],z1],
                    "thickness": thickness, "material": floor_material})
        for wall in context["diagram_hosts"]:
            if wall["type"] == "wall" and not wall.get("open"):
                elements.append({**{k: deepcopy(wall[k]) for k in ("id","type","from","to","thickness")},
                                 "material": wall_material})
    elif design.get("repetition"):
        if set(form)-{"material"} or not material("accent"):
            return None
        target = repetition_geometry(design)
        elements = [{"id": f"{mid}_{i}", "type": "primitive", "shape": "box", "position": p,
                     "dimensions": target["member_size"], "material": material("accent")}
                    for i,p in enumerate(target["positions"])]
    elif family == "stair" and mid in context["stair_route_targets"]:
        if (set(form)-{"shape","flights","span_direction","flight_width","landing_depth","rises",
                       "riser_height","tread_depth","max_riser_height","landing_thickness","material"}
                or not material("structure")):
            return None
        route = context["stair_route_targets"][mid]
        for name in ("first_flight", "second_flight"):
            flight = route[name]
            elements.append({"id": f"{mid}_{name}", "type": "stair", "material": material("structure"),
                             **{k:v for k,v in flight.items() if k in
                                {"from","to","width","stepCount","stepHeight","stepDepth"}}})
        x0,z0,x1,z1 = route["landing"]["bounds"]
        thickness = form.get("landing_thickness", context["construction"]["slab_thickness"])
        y = route["landing"]["top_y"]-thickness
        elements.append({"id": mid+"_landing", "type": "floor", "from": [x0,y,z0], "to": [x1,y,z1],
                         "thickness": thickness, "material": material("structure")})
    elif family == "roof" and design.get("volume"):
        fields = capability_surface()["roof"]["schema"].get("properties", {})
        kind = design.get("roof_type") or design.get("type")
        size = design.get("size") or {}
        if (kind not in fields.get("roofType", {}).get("enum", []) or set(form)-set(fields)
                or (design.get("placement") or {}).get("position") or design.get("connections")
                or set(form) & {"id","type","position","span","depth","ridgeAxis","roofType"}):
            return None
        height = size.get("height", form.get("height", design.get("height")))
        thickness = form.get("thickness", design.get("thickness"))
        if height is None and kind == "flat":
            height = 0
        if height is None or thickness is None or not material("roof"):
            return None
        if "height" in form and abs(form["height"]-height) > 0.001:
            raise ValueError(f"{mid}：屋面 height 存在相互矛盾的显式值")
        volume = design["volume"]
        overhang = design.get("overhang", 0)
        elements.append({**form, "id": mid, "type": "roof", "roofType": kind,
            "span": size.get("width", volume["width"]+2*overhang),
            "depth": size.get("depth", volume["depth"]+2*overhang),
            "position": deepcopy(marker["entity"]["position"]), "height": height, "thickness": thickness,
            "ridgeAxis": design.get("ridge_axis", "x"), "material": material("roof")})
    elif family in {"door", "window"}:
        fields = capability_surface()[family]["schema"].get("properties", {})
        size = design.get("size") or {}
        if (marker["type"] != family or not form or set(form)-set(fields)
                or set(form) & {"id","type","parentWall","from","position","width","height"}
                or not {"width","height"} <= size.keys() or set(size)-{"width","height"}):
            return None
        target = context["opening_hosts"].get(mid) or marker.get("entity", {})
        if not {"parentWall","from"} <= target.keys():
            return None
        components.append({**form, **size, "type": family, "id": mid,
                           **{k: deepcopy(target[k]) for k in ("parentWall","from")}})
    else:
        return None
    return {"id": mid, "geometry": {"elements": elements, "components": components},
            "explanation": "由批准设计参数确定性生成"}
