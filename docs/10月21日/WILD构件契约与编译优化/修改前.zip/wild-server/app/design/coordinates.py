"""体量起点坐标与总体尺寸控制；不把世界原点当场地边界。"""
import json
from math import hypot, isfinite


class DesignCoordinateConflict(ValueError):
    def __init__(self, conflicts: list[dict], *, context: dict | None = None):
        self.conflicts = conflicts
        self.context = context or {}
        super().__init__(json.dumps({"code": "design_coordinate_conflict", "conflicts": conflicts,
                                    **({"context": self.context} if self.context else {})}, ensure_ascii=False))


def volume_conflicts(volumes: list[dict], massing: dict) -> list[dict]:
    """massing 宽深是总体包络控制上限；差值比较对整体平移不变。"""
    if not volumes:
        return []
    conflicts = []
    for axis, extent in (("x", "width"), ("z", "depth")):
        low = min(v[axis] for v in volumes)
        high = max(v[axis] + v[extent] for v in volumes)
        if high - low > massing[extent] + 0.001:
            conflicts.append({"path": "/decisions/volumes", "value": volumes,
                "conflict_path": "/decisions/massing/" + extent,
                "conflict_value": massing[extent], "actual_extent": high - low,
                "reason": "体量并集包围盒超出总体尺寸控制；必须显式修订，不能裁剪体量"})
    for index, v in enumerate(volumes):
        if v["end_floor"] > massing["modeled_floors"]:
            conflicts.append({"path": f"/decisions/volumes/{index}/end_floor", "value": v["end_floor"],
                "conflict_path": "/decisions/massing/modeled_floors",
                "conflict_value": massing["modeled_floors"], "reason": "体量楼层超出建模层数"})
    return conflicts



def representative_floor_indices(massing):
    count, floors = massing.modeled_floors, massing.floors
    if massing.representation_mode == "schematic" and count > 1:
        return [1 + round(i*(floors-1)/(count-1)) for i in range(count)]
    return list(range(1, count+1))


def floor_elevations(design):
    """同一图纸的楼面世界标高；显式 level 优先，未声明时沿用层高。"""
    height, count = design["massing"]["floor_height"], design["massing"]["floors"]
    explicit = {}
    layouts = design.get("floor_layouts") or []
    if not isinstance(layouts, list):
        raise ValueError("/floor_layouts：逐层布局必须是对象数组")
    for index, layout in enumerate(layouts):
        if not isinstance(layout, dict):
            raise ValueError(f"/floor_layouts/{index}：每层布局必须是对象")
        for key in ("rooms", "walls"):
            if not isinstance(layout.get(key, []), list) or any(not isinstance(item, dict) for item in layout.get(key, [])):
                raise ValueError(f"/floor_layouts/{index}/{key}：必须是对象数组")
        if "floor" not in layout or layout.get("level") is None:
            continue
        floor, level = layout["floor"], layout["level"]
        if isinstance(floor, bool) or not isinstance(floor, int) or not 1 <= floor <= count:
            raise ValueError(f"/floor_layouts/{index}/floor：楼层必须是 1～{count} 的整数")
        if isinstance(level, bool) or not isinstance(level, (int, float)) or not isfinite(level):
            raise ValueError(f"/floor_layouts/{index}/level：楼面世界标高必须是有限数字")
        if floor in explicit and explicit[floor] != level:
            raise ValueError(f"/floor_layouts/{index}/level：同一楼层声明了不同标高")
        explicit[floor] = level
    base = explicit.get(1, 0)
    levels = {i: explicit.get(i, base+(i-1)*height) for i in range(1, count+1)}
    levels[count+1] = levels[count]+height
    if any(levels[i+1] <= levels[i] for i in range(1, count)):
        raise ValueError("/floor_layouts：上层楼面标高必须高于下层；显式修订，不能覆盖已声明标高")
    return levels


def floor_connection_targets(design, component):
    """明确楼层引用的唯一标高来源；未声明连接时不猜测。"""
    levels = floor_elevations(design)
    count = design["massing"]["floors"]
    targets, issues = [], []
    for index, connection in enumerate(component.get("floor_connections") or []):
        lower, upper = connection["from_floor"], connection["to_floor"]
        destination = count + 1 if upper == "roof" else upper
        if lower > count or destination > count + (upper == "roof") or destination <= lower:
            issues.append({"code": "floor_connection_reference", "path": f"/floor_connections/{index}",
                           "expected": f"1～{count} 层的递增连接或显式 roof", "actual": connection,
                           "reason": "连接楼层不存在或上层不高于下层"})
            continue
        targets.append({**connection, "from_y": levels[lower], "to_y": levels[destination],
                        "rise": levels[destination] - levels[lower]})
    return targets, issues


def room_rectangle(room):
    """同一处解释新旧房间边界；返回世界 X/Z 的 min/max。"""
    b = room["bounds"]
    if "x" in b:
        return [b["x"], b["z"], b["x"] + b["width"], b["z"] + b["depth"]]
    return [b["x_start"], b["z_start"], b["x_end"], b["z_end"]]


def construction_dimensions(design):
    return {"slab_thickness": 0.2, "wall_thickness": 0.24, **(design.get("construction") or {})}


def repetition_geometry(component):
    repeat = component.get("repetition")
    if not repeat:
        return None
    center = (component.get("placement") or {}).get("position")
    if not center:
        raise ValueError(f"/components/{component.get('id')}/placement/position：重复构件需要整组世界中心")
    axis = "xyz".index(repeat["axis"])
    extent = list(repeat["member_size"])
    extent[axis] += (repeat["count"]-1)*repeat["spacing"]
    for i, field in enumerate(("width", "height", "depth")):
        value = (component.get("size") or {}).get(field)
        if value is not None and abs(value-extent[i]) > 0.001:
            raise ValueError(f"/components/{component.get('id')}/size/{field}：重复组实际包络为 {extent[i]:g}，设计为 {value:g}")
    positions = []
    for i in range(repeat["count"]):
        p = list(center)
        p[axis] += (i-(repeat["count"]-1)/2)*repeat["spacing"]
        positions.append(p)
    return {"positions": positions, "member_size": repeat["member_size"], "extent": extent}


def subtract_rectangles(rectangles, cuts):
    """矩形差集，保持庭院、挑空和梯井；仅处理世界 X/Z。"""
    result = list(rectangles)
    for cx0, cz0, cx1, cz1 in cuts:
        remaining = []
        for x0, z0, x1, z1 in result:
            a, b, c, d = max(x0, cx0), max(z0, cz0), min(x1, cx1), min(z1, cz1)
            if c <= a or d <= b:
                remaining.append([x0, z0, x1, z1])
            else:
                remaining.extend(r for r in ([x0,z0,a,z1], [c,z0,x1,z1], [a,z0,c,b], [a,d,c,z1])
                                 if r[2]-r[0] > 0.001 and r[3]-r[1] > 0.001)
        result = remaining
    return result


def design_geometry_context(design):
    """由同一图纸推导标高和空间边界，供构件实现与设计落实检查共用。"""
    from .contracts import MassingDecision
    from app.agent.knowledge.component_names import resolve_component_name

    indices = representative_floor_indices(MassingDecision.model_validate(design["massing"]))
    elevations = floor_elevations(design)
    construction = construction_dimensions(design)
    if any(construction["slab_thickness"] >= elevations[i+1]-elevations[i] for i in range(1, design["massing"]["floors"]+1)):
        raise ValueError("/construction/slab_thickness：板厚必须小于对应层间高差")
    volumes = {
        v["id"]: {
            "bounds": [v["x"], v["z"], v["x"] + v["width"], v["z"] + v["depth"]],
            "center_xz": [v["x"] + v["width"] / 2, v["z"] + v["depth"] / 2],
            "base_y": elevations[indices[v["start_floor"] - 1]],
            "roof_support_y": elevations[indices[v["end_floor"] - 1] + 1],
        }
        for v in design.get("volumes") or []
    }
    levels = [
        {"index": index, "base_y": elevations[index], "top_y": elevations[index + 1],
         "height": elevations[index + 1] - elevations[index],
         "slab_bottom_y": elevations[index] - construction["slab_thickness"],
         "volume_ids": [v["id"] for v in design.get("volumes") or []
                        if v["start_floor"] <= slot <= v["end_floor"]], "voids": []}
        for slot, index in enumerate(indices, 1)
    ]
    by_floor = {level["index"]: level for level in levels}
    stair_routes, stair_errors = {}, []
    # 主体任务不再持有 components；委派的楼梯仍决定主体必须保留的梯井。
    components = design.get("components") or design.get("delegated_components") or []
    for component_index, component in enumerate(components):
        if resolve_component_name(component.get("type", ""))["entity_type"] != "stair":
            if (component.get("placement") or {}).get("plan_position") is not None:
                stair_errors.append(f"/components/{component_index}/placement/plan_position：此字段仅用于楼梯")
            continue
        targets, connection_issues = floor_connection_targets(design, component)
        if connection_issues:
            stair_errors.extend(f"/components/{component_index}{issue['path']}：{issue['reason']}"
                                for issue in connection_issues)
            continue
        marker = {"id": component.get("id", "stair"), "design": component, "floor_connections": targets,
                  "design_path": f"/{'components' if 'components' in design else 'delegated_components'}/{component_index}"}
        try:
            route = resolve_stair_geometry(marker)
        except ValueError as exc:
            stair_errors.append(str(exc))
            continue
        if route:
            stair_routes[marker["id"]] = route
            void = route["void"]
            if void["floor"] in by_floor:
                by_floor[void["floor"]]["voids"].append({"bounds": void["bounds"], "derived": True,
                    "design_path": f"/components/{marker['id']}/floor_connections"})
    for layout_index, layout in enumerate(design.get("floor_layouts") or []):
        for room_index, room in enumerate(layout.get("rooms") or []):
            path = f"/floor_layouts/{layout_index}/rooms/{room_index}"
            if "void" in room and type(room["void"]) is not bool:
                raise ValueError(f"{path}/void：必须是 boolean，true 表示此层挑空")
            if room.get("void") is not True:
                continue
            bounds = room_rectangle(room)
            floor = layout.get("floor")
            if type(floor) is not int or floor not in elevations or floor > design["massing"]["floors"]:
                raise ValueError(f"{path}：挑空必须引用有效楼层 floor")
            if floor in by_floor:
                by_floor[floor]["voids"].append({
                    "design_path": path,
                    "bounds": bounds,
                })
    if stair_errors:
        raise ValueError("；".join(stair_errors))
    paths = [{**path, "base_y": elevations[path["floor"]],
              "top_y": elevations[path["floor"]] + path["height"]}
             for path in (design.get("circulation") or {}).get("paths", [])]
    rooms = [{**room, "floor": layout["floor"], "rect": room_rectangle(room)}
             for layout in design.get("floor_layouts") or [] for room in layout.get("rooms") or []]
    for level in levels:
        regions = []
        for vid in level["volume_ids"]:
            regions.extend(subtract_rectangles([volumes[vid]["bounds"]], regions))
        level["floor_rectangles"] = subtract_rectangles(
            regions,
            [void["bounds"] for void in level["voids"]])
    repetitions = {c["id"]: repetition_geometry(c) for c in components if c.get("repetition")}
    return {"levels": levels, "volumes": volumes, "construction": construction,
            "rooms": rooms, "paths": paths, "stair_routes": stair_routes, "repetitions": repetitions}


def stair_span_conflicts(design):
    """只核对显式数值能否落在已声明的楼面之间，不推断楼梯造型。"""
    from app.agent.knowledge.component_names import resolve_component_name

    levels = floor_elevations(design)
    highest_floor = levels[design["massing"]["floors"]]
    available_rise = highest_floor - levels[1]
    issues = []
    for index, component in enumerate(design.get("components") or []):
        if resolve_component_name(component.get("type", ""))["entity_type"] != "stair":
            continue
        form = component.get("form") if isinstance(component.get("form"), dict) else {}
        targets, _ = floor_connection_targets(design, component)
        if targets:
            available_rise = max(t["to_y"] for t in targets) - min(t["from_y"] for t in targets)
        elif form.get("roof_access") is True or design["massing"]["floors"] < 2:
            continue
        else:
            available_rise = highest_floor - levels[1]
        size = component.get("size") if isinstance(component.get("size"), dict) else {}
        height = size.get("height")
        if isinstance(height, (int, float)) and not isinstance(height, bool) and height > available_rise + 0.25:
            issues.append(f"/components/{index}/size/height：楼梯高 {height:g}m 超过首层至顶层楼面高差 "
                          f"{available_rise:g}m；核对连接楼层，屋面通行须显式写 form.roof_access")
        if all(isinstance(form.get(key), (int, float)) and not isinstance(form[key], bool)
               for key in ("flights", "rises", "riser_height")):
            total_rise = form["flights"] * form["rises"] * form["riser_height"]
            if total_rise > available_rise + 0.25:
                issues.append(f"/components/{index}/form：梯段数×每跑级数×踏步高={total_rise:g}m，"
                              f"超过首层至顶层楼面高差 {available_rise:g}m；修订楼梯连接或踏步参数")
            elif isinstance(height, (int, float)) and not isinstance(height, bool) and abs(total_rise-height) > 0.25:
                issues.append(f"/components/{index}/form：踏步总高差 {total_rise:g}m 与楼梯 size.height "
                              f"{height:g}m 不一致；修订踏步或楼梯高度")
    return issues


def design_relation_checks(design, markers, frames):
    """核对墙体表达、设计引用与明确楼层连接，不代替设计取舍。"""
    from app.agent.knowledge.component_names import resolve_component_name

    ids = {v["id"] for v in design["volumes"]} | {m["id"] for m in markers} | set(frames)
    errors, reviews, stairs = [], [], []
    facades = [frame for frame in frames.values() if frame.get("facing")]
    for wall in frames.values():
        if not wall.get("design_path", "").startswith("/decisions/floor_layouts/"):
            continue
        a, b = wall["from"], wall["to"]
        length = hypot(b[0]-a[0], b[2]-a[2])
        ux, uz = (b[0]-a[0])/length, (b[2]-a[2])/length
        for facade in facades:
            p, q = facade["from"], facade["to"]
            if min(max(a[1], b[1]), max(p[1], q[1]))-max(min(a[1], b[1]), min(p[1], q[1])) <= 0.001:
                continue
            if max(abs(-(point[0]-a[0])*uz+(point[2]-a[2])*ux) for point in (p, q)) > 0.001:
                continue
            along = [(point[0]-a[0])*ux+(point[2]-a[2])*uz for point in (p, q)]
            overlap = min(length, max(along))-max(0, min(along))
            if overlap <= 0.001:
                continue
            conflict = ("该面有效 facades 为 open，却在平面墙清单中重新封墙"
                        if facade.get("open") else "同一围护墙同时由体量立面和平面墙清单重复声明")
            errors.append({"code": "floor_wall_facade_conflict", "path": wall["design_path"],
                           "expected": "floor_layouts.walls 只声明独立内墙，围护统一由有效 facades 表达",
                           "actual": {"wall_id": wall["id"], "facade_id": facade["id"], "overlap": overlap},
                           "reason": f"平面墙 {wall['id']} 与围护宿主 {facade['id']} 重叠 {overlap:g}m；{conflict}"})
    for marker in markers:
        if marker["type"] == "building_body":
            continue
        component, path = marker["design"], marker["design_path"]
        for field, reference in (("host", marker.get("host")),
                                 ("relation/target", (component.get("relation") or {}).get("target"))):
            if reference and reference not in ids:
                errors.append({"code": "design_reference_missing", "path": f"{path}/{field}",
                               "marker_id": marker["id"], "expected": "图纸已声明的宿主或构件 ID",
                               "actual": reference, "reason": "引用目标未在本次图纸声明"})
        for i, connection in enumerate(component.get("connections") or []):
            if connection["target"] not in ids or connection["target"] == marker["id"]:
                errors.append({"code": "design_connection_reference", "path": f"{path}/connections/{i}/target",
                               "marker_id": marker["id"], "expected": "另一个已声明的图纸目标",
                               "actual": connection["target"], "reason": "连接目标缺失或自引用"})
        family = resolve_component_name(marker["type"])["entity_type"]
        if family in {"door", "window"} and marker.get("host") not in frames:
            errors.append({"code": "design_opening_host_missing", "path": f"{path}/host",
                           "marker_id": marker["id"], "expected": "可解析的图纸墙宿主",
                           "actual": marker.get("host"),
                           "reason": f"门窗 {marker['id']} 的宿主 {marker.get('host')!r} 无法解析为当前墙面"})
        if family != "stair":
            continue
        targets, problems = floor_connection_targets(design, component)
        marker["floor_connections"] = targets
        errors.extend({**problem, "path": path + problem["path"], "marker_id": marker["id"]}
                      for problem in problems)
        stairs.append((marker, targets))
        if not targets:
            reviews.append({"marker_id": marker["id"], "path": path + "/floor_connections",
                            "reason": "楼梯连接楼层未结构化，须核对实际到达楼面；不据文字猜测连接"})
    if stairs and all(targets for _, targets in stairs) and design["massing"].get("representation_mode", "full") == "full":
        reached = {1}
        while True:
            expanded = reached | {t["to_floor"] for _, targets in stairs for t in targets if t["from_floor"] in reached}
            if expanded == reached:
                break
            reached = expanded
        missing = sorted(set(range(1, design["massing"]["floors"] + 1)) - reached)
        if missing:
            issue = {"code": "stair_floor_unreachable", "path": "/decisions/components",
                     "marker_id": "circulation", "marker_ids": [m["id"] for m, _ in stairs],
                     "expected": "各声明楼层可从首层到达", "actual": {"unreachable_floors": missing},
                     "reason": "明确楼梯连接漏连楼层"}
            (errors if design.get("circulation", {}).get("vertical_strategy") == "stair" else reviews).append(issue)
    return errors, reviews


def floor_layout_conflicts(design):
    """Reject a partition that cuts across a declared rectangular room."""
    issues = []
    for floor_index, layout in enumerate(design.get("floor_layouts") or []):
        for wall_index, wall in enumerate(layout.get("walls") or []):
            a, b = wall.get("from"), wall.get("to")
            if not (isinstance(a, list) and isinstance(b, list) and len(a) == len(b) == 2
                    and all(type(n) in (int, float) and isfinite(n) for n in a+b)):
                continue  # Field validation reports malformed walls separately.
            if any(item.get("host") == wall.get("id") for item in design.get("components") or []):
                continue  # A designed opening or attached detail needs human review.
            for room_index, room in enumerate(layout.get("rooms") or []):
                box = room.get("bounds") or {}
                if not isinstance(box, dict):
                    continue
                if not all(type(box.get(key)) in (int, float) and isfinite(box[key])
                           for key in ("x", "z", "width", "depth")):
                    continue
                x0, z0 = box["x"], box["z"]
                x1, z1 = x0+box["width"], z0+box["depth"]
                vertical = (abs(a[0]-b[0]) <= 0.001 and x0+0.001 < a[0] < x1-0.001
                            and min(a[1], b[1]) <= z0+0.001 and max(a[1], b[1]) >= z1-0.001)
                horizontal = (abs(a[1]-b[1]) <= 0.001 and z0+0.001 < a[1] < z1-0.001
                              and min(a[0], b[0]) <= x0+0.001 and max(a[0], b[0]) >= x1-0.001)
                if vertical or horizontal:
                    issues.append(f"/floor_layouts/{floor_index}/rooms/{room_index}："
                                  f"房间 X=[{x0:g},{x1:g}]、Z=[{z0:g},{z1:g}] 被 "
                                  f"/floor_layouts/{floor_index}/walls/{wall_index} "
                                  f"{wall.get('id', wall_index)} ({a}→{b}) 贯穿")
    return issues


def rectangle_uncovered_area(bounds, regions):
    """矩形减去矩形并集的面积；重复、重叠覆盖不能抵消其他位置的空缺。"""
    x0, z0, x1, z1 = bounds
    xs = sorted({x0, x1, *(max(x0, min(x1, x)) for r in regions for x in (r[0], r[2]))})
    covered = 0
    for left, right in zip(xs, xs[1:]):
        intervals = sorted((max(z0, r[1]), min(z1, r[3])) for r in regions
                           if r[0] <= left and r[2] >= right and r[1] < z1 and r[3] > z0)
        end, length = z0, 0
        for low, high in intervals:
            length += max(0, high-max(end, low))
            end = max(end, high)
        covered += (right-left)*length
    return max(0, (x1-x0)*(z1-z0)-covered)


def opening_coordinate_errors(markers):
    """核对门窗越界及同一墙面洞口重叠，不改写设计坐标。"""
    from app.agent.knowledge.component_names import resolve_component_name
    errors, openings = [], []
    for marker in markers:
        wall = marker.get("diagram_host")
        design, spec = marker["design"], marker["entity"]
        if (wall and wall.get("open")
                and resolve_component_name(marker["type"])["entity_type"] in {"door", "window"}):
            errors.append(f"{marker.get('design_path', '/decisions/components')}/host：{marker['id']} 引用了 {wall['id']}，"
                          "但该体量此面此层的有效 facades 是 open（无墙）；"
                          "封闭空间需在对应 volume.facades 覆盖此面的布局，或显式修订门窗宿主；"
                          "不能只在文字中声明围护，未覆盖的面仍继承共享 facades")
            continue
        if (not wall or not design.get("placement") or not spec.get("from")
                or resolve_component_name(marker["type"])["entity_type"] not in {"door", "window"}):
            continue
        a, b = wall["from"], wall["to"]
        length = hypot(b[0]-a[0], b[2]-a[2])
        along, y, _ = spec["from"]
        size = design.get("size") or {}
        width, height = size.get("width", 0), size.get("height", 0)
        world = bool(design["placement"].get("position"))
        problems = []
        if along < -0.001 or along+width > length+0.001:
            message = f"沿墙范围 [{along:g}, {along+width:g}]m，宿主允许 [0, {length:g}]m，窗宽={width:g}m；"
            if width > length:
                message += ("当前宽度没有可用沿墙位置" if world else "当前宽度没有可用 offset") + "，须显式修订宽度或宿主"
            elif world:
                message += (f"position 沿宿主 from→to 的中心距离={along+width/2:g}m，"
                            f"保留宽度时中心距离的可用范围 [{width/2:g}, {length-width/2:g}]")
            else:
                message += f"offset={along:g} 是沿墙局部距离，保留宽度时 offset 的可用范围 [0, {length-width:g}]"
            problems.append(message)
        if y < a[1]-0.001 or y+height > b[1]+0.001:
            message = f"竖向范围 [{y:g}, {y+height:g}]m，宿主允许 [{a[1]:g}, {b[1]:g}]m，墙高={b[1]-a[1]:g}m；"
            if world:
                message += f"position[1] 是世界中心 Y，窗高={height:g}m；"
                if height <= b[1]-a[1]:
                    message += f"保留窗高时 position[1] 的可用范围 [{a[1]+height/2:g}, {b[1]-height/2:g}]"
                else:
                    message += "当前窗高没有可用中心位置，须显式修订窗高或宿主"
            else:
                message += f"sill_height={y-a[1]:g}m 是相对本层墙底的高度，窗高={height:g}m；"
                if height <= b[1]-a[1]:
                    message += f"保留窗高时 sill_height 的可用范围 [0, {b[1]-a[1]-height:g}]"
                else:
                    message += "当前窗高没有可用 sill_height，须显式修订窗高或宿主"
            message += "；"
            if a[1] <= y < b[1]:
                message += f"保留窗底时 height 的可用范围 (0, {b[1]-y:g}]"
            else:
                message += "窗底已超出可安装范围，需修订位置或宿主，不能只改窗高"
            problems.append(message)
        if problems:
            errors.append(f"{marker['design_path']}/placement：{marker['id']} 的门窗范围超出宿主 {wall['id']}；"
                          + "；".join(problems) + "；只修对应方向的位置或明确调整尺寸/宿主，保留未受影响的设计")
        if width <= 0 or height <= 0 or length <= 0.001 or wall.get("curve"):
            continue
        ux, uz = (b[0]-a[0])/length, (b[2]-a[2])/length
        start = (a[0]+ux*along, a[2]+uz*along)
        for other, origin, direction, other_width, bottom, other_height in openings:
            if abs(ux*direction[1]-uz*direction[0]) > 0.000001:
                continue
            dx, dz = origin[0]-start[0], origin[1]-start[1]
            if abs(-dx*uz+dz*ux) > 0.001:
                continue
            shift = dx*ux+dz*uz
            end = shift+other_width*(ux*direction[0]+uz*direction[1])
            overlap = min(width, max(shift, end))-max(0, min(shift, end))
            if overlap <= 0.001 or min(y+height, bottom+other_height)-max(y, bottom) <= 0.001:
                continue
            errors.append(f"{marker['design_path']}/placement：{marker['id']} 与 "
                          f"{other['design_path']} 的 {other['id']} 在同一物理墙面上的洞口重叠；"
                          f"沿墙重叠 {overlap:g}m，当前洞口范围 [{along:g}, {along+width:g}]m、"
                          f"Y=[{y:g}, {y+height:g}]m。显式修订位置、尺寸或组合分格，"
                          "不能同时声明覆盖彼此的完整门窗，也不能让执行节点自行移动已批准洞口")
        openings.append((marker, start, (ux, uz), width, y, height))
    return errors


def exterior_facade_intervals(volume, face, floor, volumes):
    """自动立面使用的外露墙段；同向共面区域只分配给一个体量。"""
    axis = "x" if face in {"front", "back"} else "z"
    extent = "width" if axis == "x" else "depth"
    normal, normal_extent = ("z", "depth") if axis == "x" else ("x", "width")
    positive = face in {"right", "back"}
    plane = getattr(volume, normal) + (getattr(volume, normal_extent) if positive else 0)
    origin, length = getattr(volume, axis), getattr(volume, extent)
    segments = [(0.0, length)]
    for other in volumes:
        if other.id == volume.id or not other.start_floor <= floor <= other.end_floor:
            continue
        low, high = getattr(other, normal), getattr(other, normal)+getattr(other, normal_extent)
        inside = low <= plane+0.001 and high > plane+0.001 if positive else low < plane-0.001 and high >= plane-0.001
        shared = plane == (high if positive else low)
        owner = (-getattr(other, extent), other.id) < (-length, volume.id)
        if not inside and not (shared and owner):
            continue
        start = max(0.0, getattr(other, axis)-origin)
        end = min(length, getattr(other, axis)+getattr(other, extent)-origin)
        if face in {"back", "left"}:
            start, end = length-end, length-start
        if end <= start:
            continue
        segments = [(a, b) for left, right in segments for a, b in
                    ((left, min(right, start)), (max(left, end), right)) if b-a > 0.001]
    return segments


def component_dimension_conflicts(design):
    """显式方向和相对标高不能与构件自身的世界尺寸、中心矛盾。"""
    from app.agent.knowledge.component_names import resolve_component_name

    errors = []
    volumes = {v["id"]: v for v in design.get("volumes") or []}
    for index, component in enumerate(design.get("components") or []):
        family = resolve_component_name(component.get("type", ""))["entity_type"]
        size = component.get("size") or {}
        form = component.get("form") if isinstance(component.get("form"), dict) else {}
        path = f"/components/{index}"
        direction = str(form.get("span_direction") or "").strip().lower()
        if family == "beam" and direction in {"x", "z"} and all(k in size for k in ("width", "depth")):
            span, cross = ("width", "depth") if direction == "x" else ("depth", "width")
            if size[span] < size[cross]-0.001:
                errors.append(f"{path}/size：span_direction={direction}，但 {span}={size[span]:g} "
                              f"小于 {cross}={size[cross]:g}；size.width/height/depth 是整体世界 X/Y/Z 尺度，"
                              "方向不会旋转这套尺寸。请修订方向或对应尺寸，不能让实现节点同时满足相反约束")
        position = (component.get("placement") or {}).get("position")
        rise = form.get("ridge_height_from_wall_top")
        volume = volumes.get(component.get("host"))
        if (family != "roof" or not volume or not position or "height" not in size
                or type(rise) not in (int, float) or not isfinite(rise)):
            continue
        top = floor_elevations(design)[volume["end_floor"]+1]
        expected = top+rise-size["height"]/2
        if abs(position[1]-expected) > 0.001:
            errors.append(f"{path}/placement/position：屋面整体中心Y={position[1]:g}，但宿主墙顶={top:g}、"
                          f"form.ridge_height_from_wall_top={rise:g}、size.height={size['height']:g} "
                          f"推导中心Y={expected:g}（墙顶+屋脊高差-屋面高度/2）；"
                          "请显式修订位置或相对高差，不能把屋脊标高当成整体中心")
    return errors


def roof_span_conflicts(markers):
    """显式整片屋面的设计包围框必须覆盖其负责体量及出檐。"""
    from app.agent.knowledge.component_names import resolve_component_name
    errors = []
    for marker in markers:
        design = marker.get("design") or {}
        volume = design.get("volume")
        position = (design.get("placement") or {}).get("position")
        size = design.get("size") or {}
        if (resolve_component_name(marker["type"])["entity_type"] != "roof"
                or not volume or not position):
            continue
        overhang = design.get("overhang", 0)
        path = marker.get("design_path", "/decisions/components").removeprefix("/decisions")
        for key, axis, origin in (("width", 0, "x"), ("depth", 2, "z")):
            if key not in size:
                continue
            lower = volume[origin]-overhang
            upper = volume[origin]+volume[key]+overhang
            required = 2*max(position[axis]-lower, upper-position[axis])
            if size[key] < required-0.001:
                errors.append(f"{path}/size/{key}：整片屋面需覆盖体量和出檐，"
                              f"世界 {'XZ'[axis//2]} 范围 [{lower:g}, {upper:g}]，"
                              f"当前中心 {position[axis]:g}，{key} 至少为 {required:g}，实际 {size[key]:g}；"
                              "修订 /components 的覆盖尺寸或 /volumes、/roof 中相互矛盾的设计数值，不能带着矛盾进入实现")
    return errors


def resolve_stair_geometry(marker):
    """由明确的折返方向、占地与楼面计算路线；缺省踏步参数不阻断定位。"""
    import re

    design = marker.get("design") or {}
    path = (marker.get("design_path") or "/components").removeprefix("/decisions")
    form, size = design.get("form") or {}, design.get("size") or {}
    plan_position = (design.get("placement") or {}).get("plan_position")
    connections = marker.get("floor_connections") or []
    if plan_position is not None:
        from pydantic import ValidationError
        from .contracts import PlanStairForm

        try:
            form = PlanStairForm.model_validate(form).model_dump(mode="json", exclude_none=True)
        except ValidationError as exc:
            raise ValueError("；".join(
                f"{path}/form/{'/'.join(str(p) for p in error['loc'])}：{error['msg']}"
                for error in exc.errors()
            )) from exc
        missing = [f"{path}/size/{key}：需要有限正数的世界占地尺寸"
                   for key in ("width", "depth")
                   if type(size.get(key)) not in (int, float) or not isfinite(size[key]) or size[key] <= 0]
        if len(connections) != 1:
            missing.append(f"{path}/floor_connections：plan_position 需要且仅支持一组有效楼层连接，实际 {len(connections)} 组")
        if missing:
            raise ValueError("；".join(missing))
    if (not isinstance(form, dict) or form.get("flights") != 2
            or not re.search(r"(?<![A-Za-z])U(?![A-Za-z])|回形|回型|折返|平行双跑",
                             str(form.get("shape") or "") + str(form.get("description") or ""), re.I)):
        return None
    direction = str(form.get("span_direction") or "").strip().lower()
    if direction and direction not in {"+x", "-x", "+z", "-z"}:
        return None
    if not direction:
        match = re.search(r"第一跑[^。；]*?沿\s*([+-])\s*([XZ])", str(form.get("description") or ""), re.I)
        direction = match[1] + match[2].lower() if match else ""
    position = (design.get("placement") or {}).get("position")
    if plan_position is not None and len(connections) == 1:
        computed = [plan_position[0], (connections[0]["from_y"]+connections[0]["to_y"])/2, plan_position[1]]
        if position is not None and any(abs(a-b) > 0.001 for a,b in zip(position, computed)):
            raise ValueError(f"{path}/placement/position：显式中心与 plan_position、楼层连接推导的 {computed} 冲突")
        position = computed
    values = [size.get("width"), size.get("depth"), form.get("flight_width"), form.get("landing_depth")]
    if (not direction or not isinstance(position, list) or len(position) != 3
            or len(connections) != 1
            or not all(type(v) in (int, float) and isfinite(v) and v > 0 for v in values)
            or not all(type(v) in (int, float) and isfinite(v) for v in position)):
        return None
    axis = 0 if direction[1] == "x" else 2
    cross_axis = 2 if axis == 0 else 0
    sign = 1 if direction[0] == "+" else -1
    length, cross = size["width" if axis == 0 else "depth"], size["depth" if axis == 0 else "width"]
    lower, upper = connections[0]["from_y"], connections[0]["to_y"]
    middle = (lower + upper)/2
    if abs(position[1]-middle) > 0.001:
        raise ValueError(f"{path}/placement/position：中心 Y 应为 {middle:g}，实际 {position[1]:g}")
    issues = []
    if "height" in size and abs(size["height"]-(upper-lower)) > 0.001:
        issues.append(f"{path}/size/height：连接高差应为 {upper-lower:g}，实际 {size['height']:g}")
    rises, tread, riser = form.get("rises"), form.get("tread_depth"), form.get("riser_height")
    if rises is not None and (type(rises) is not int or rises < 1):
        raise ValueError(f"{path}/form/rises：{marker['id']} 必须为每跑正整数级数")
    maximum = form.get("max_riser_height")
    if maximum is not None:
        from math import ceil
        if type(maximum) not in (int,float) or not isfinite(maximum) or maximum <= 0:
            raise ValueError(f"{path}/form/max_riser_height：{marker['id']} 必须是有限正数")
        if rises is None and riser is None:
            rises = ceil((middle-lower)/maximum)
    if riser is not None:
        if type(riser) not in (int, float) or not isfinite(riser) or riser <= 0:
            raise ValueError(f"{path}/form/riser_height：{marker['id']} 必须是有限正数")
        if rises is None:
            count = (middle-lower)/riser
            if abs(count-round(count)) > 0.000001 or count < 1:
                raise ValueError(f"{path}/form/riser_height：{marker['id']} 无法用整数级连接楼面")
            rises = round(count)
        elif abs(rises*riser-(middle-lower)) > 0.001:
            issues.append(f"{path}/form/riser_height：每跑级数×级高应为 {middle-lower:g}，实际 {rises*riser:g}")
    if rises and maximum is not None and (middle-lower)/rises > maximum+0.001:
        issues.append(f"{path}/form/max_riser_height：实际级高超过 {maximum:g}")
    if tread is not None and (type(tread) not in (int, float) or not isfinite(tread) or tread <= 0 or rises is None):
        raise ValueError(f"{path}/form/tread_depth：{marker['id']} 需有限正数及可确定的每跑级数")
    run = rises*tread if tread is not None else length-form["landing_depth"]
    if run <= 0 or run + form["landing_depth"] > length + 0.001 or 2*form["flight_width"] > cross + 0.001:
        issues.append(f"{path}/size：行进方向需 {run+form['landing_depth']:g}，可用 {length:g}；"
                      f"横向需 {2*form['flight_width']:g}，可用 {cross:g}")
    if issues:
        raise ValueError("；".join(issues))
    near = position[axis] - sign*length/2
    turn = near + sign*run
    far = turn + sign*form["landing_depth"]
    cross_offset = (cross-form["flight_width"])/2
    first_cross, second_cross = position[cross_axis]-cross_offset, position[cross_axis]+cross_offset

    def point(cross_value, y, along):
        result = list(position)
        result[axis], result[cross_axis], result[1] = round(along, 6), round(cross_value, 6), round(y, 6)
        return result

    first_from, first_to = point(first_cross, lower, near), point(first_cross, middle, turn)
    second_from, second_to = point(second_cross, middle, turn), point(second_cross, upper, near)
    bounds = [position[0]-size["width"]/2, position[2]-size["depth"]/2,
              position[0]+size["width"]/2, position[2]+size["depth"]/2]
    bounds[0 if axis == 0 else 1] = min(turn, far)
    bounds[2 if axis == 0 else 3] = max(turn, far)
    flight = {"width": form["flight_width"], "rise": round(middle-lower, 6), "run": round(run, 6)}
    if rises is not None:
        flight.update(stepCount=rises, stepHeight=(middle-lower)/rises, stepDepth=run/rises)
    return {"position": list(position), "first_flight": {**flight, "from": first_from, "to": first_to},
            "second_flight": {**flight, "from": second_from, "to": second_to},
            "landing": {"bounds": [round(v, 6) for v in bounds], "top_y": round(middle, 6)},
            "direction_axis": axis, "direction_sign": sign,
            "void": {"floor": connections[0]["to_floor"], "base_y": upper,
                     "bounds": [min(first_from[0], second_from[0])-form["flight_width"]/2,
                                min(near, far) if axis == 2 else position[2]-size["depth"]/2,
                                max(first_from[0], second_from[0])+form["flight_width"]/2,
                                max(near, far) if axis == 2 else position[2]+size["depth"]/2] if axis == 2 else
                               [min(near, far), position[2]-size["depth"]/2,
                                max(near, far), position[2]+size["depth"]/2]}}
