---
entity_name: architecture_design_expression
topic: parameters
status: supported
authority: maintainer
primary_terms:
  - 建筑设计表达
  - 设计意图
  - 体量立面屋面
synonyms: []
---

# 建筑图纸与构件实现

依据 app/design/contracts.py、coordinates.py、realization.py、markers.py 与 plan/implementation.py。DesignDocument 保存设计选择，WILD Schema 约束最终实体；程序计算结果不是第二份设计。

## 设计输入与计算结果

模型决定体量布局、层数、层高、功能空间、围护开敞、构件形式、截面间距与材料。模型输入 Schema 从 ArchitectureDecisions 投影，不输出 complexity、配额和 resolved_plan 等程序状态。

volumes 的 x/z 是世界平面起点，width/depth 是体量尺寸。massing.width/depth 缺省时计算体量并集包络；显式值为独立总体尺寸上限，包络超限报冲突。modeled_floors 缺省等于 floors；非完整表达仍须明确声明。无室内楼层的台基、杆件等使用 components。

floor_layouts.level 为楼面顶标高；不填时按首层基准和 floor_height 计算。construction 声明板厚、外墙厚，内墙保留各自 thickness。程序统一计算墙顶、板底、体量并集减挑空后的楼板分片。房间 bounds 使用 x/z/width/depth；void=true 为该层挑空，普通房间不自动开洞。

## 围护与宿主

front/back/left/right 对应最小Z、最大Z、最小X、最大X。共享 facades 作用于所有体量，volume.facades 逐面覆盖；两层 pattern 长度一致时 bays 可以省略，由程序计数。empty 为实墙无开口，open 为无墙；概念和房间标签不改变围护状态。

floor_layouts.walls 只声明独立内墙，端点 from/to 为世界 X/Z；体量围护使用 facades。同一共用界面保留一次物理墙；一侧 open 不撤销另一侧明确选择的围护，两侧 open 则保持开敞。内部连通门用显式实例表达。

components.host 是图纸引用 ID，独立构件可省略或写 null/空字符串。门窗引用 wall_<体量id>_<face>_L<楼层>、独立内墙，或体量配合 placement.face/floor；最终 parentWall 使用真实墙ID。opening_hosts 提供设计引用与真实宿主的安装换算，不能补建重复墙。

沿墙定位使用 offset（洞口起点）、sill_height（相对楼面窗台高）、normal_offset（法向偏移）；世界 position:[x,y,z] 表示设计构件中心。整面围护墙若在 components 声明，归主体一次实现；独立或局部墙单独实现。自动立面标记提供 centerAlong，真实门窗仍须形成切墙洞口，primitive 玻璃不切墙。

## 楼梯的设计参数

floor_connections 使用 from_floor/to_floor 楼层整数，上屋面用 to_floor="roof"。普通顶层墙顶不自动成为下一楼面。楼梯形式和整组占地属于设计选择。

U形双跑采用 form.shape="U"、flights=2、span_direction（+x/-x/+z/-z）、flight_width 与 landing_depth；size.width/depth 为世界X/Z占地。placement.plan_position:[x,z] 表示平面中心，程序从楼层连接计算中心Y和总高，无需重复填写 size.height 或三维中心。旧 placement.position 仍可使用；两种定位同时填写须一致。

每跑级数 rises、最大级高 max_riser_height、级高 riser_height 是可选约束。未指定踏步时沿用引擎计算；已确定级数时程序算实际级高，未给 tread_depth 时由占地减平台计算行程。显式级数、级高、进深和占地必须相容，不通过四舍五入或覆盖显式值消除冲突。

stair_route_targets 包含两跑、平台、完整梯井与出口方向；主体和楼梯共用此结果。landing_thickness 未单独选择时采用本次 construction.slab_thickness。此计算只覆盖完整定位、单个楼层连接的U形双跑；其他形式继续通过模型实现。未覆盖的 plan_position 不能静默忽略。

## 重复构件与边界连接

等距直线矩形零件使用 repetition.count/axis/spacing/member_size 及 placement.position；程序计算单件中心与整组包络。size 可省略，显式尺寸仍须一致；带额外曲面或自定义轮廓时沿用模型通道。

connections 描述同轴边界关系，target 引用声明的构件或墙，own_face/target_face 使用 left/right、bottom/top、front/back，offset 为两边界坐标差。connection_targets 从已实现实体推导坐标。它证明有限形态的边界坐标关系，不证明接触面积或结构承载；未知几何保留 needs_review。

主要水平净空由 circulation.paths 表达楼层、世界X/Z折线和净宽高；最终复核实际墙洞、家具及柱位。此检查不代表完整导航、路面支承或门扇扫掠证明。

## 屋面和材料

roof.type 表达屋型，roof.volumes 按 volume 分配差异，ridge_axis 为世界x/z方向，overhang 为出檐。height/thickness 可明确选择屋面高度与厚度，程序从宿主体量计算覆盖与支承位置。components 显式安排整片屋面时 host 指向体量；size.width/depth 为最终覆盖，placement.position 为设计整体中心。原生 WILD roof 的 position[1] 使用支承标高；两者不能混用。新屋型可组合实现，不自动换成其他坡型。

materials.definitions 按稳定ID保存已选材料参数，material_bindings 按真实 WILD material/frameMaterial/glassMaterial/leafMaterial 等字段绑定。未分配精确材质时可使用 material_role。角色描述不靠木、石等关键词分类作硬拦截；实际命名绑定和引用仍由契约与候选验收核对，局部不能重定义已采用材料。

## 实现和验收

plan 按图纸标记与依赖安排任务。execute 优先使用已有参数计算：受支持的承重墙矩形主体、完整U形双跑、等距矩形条板、参数齐全的原生门窗与屋面可直接生成，再经过原片段验收。已选择额外轮廓、独立主体结构、未知原生字段或材料未确定时继续模型通道，不删除设计细节来强行命中程序实现。

程序实现不通过时保留错误与已通过片段，不调用模型重新计算同一确定性结果；主体失败停止附属生成。模型通道仍按需查询知识、尝试实现并局部修订。参考资料只提供事实；本次任务与批准设计决定实现范围。

最终装配继续核对完整实体、设计版本与指纹，报告程序或模型来源、落实状态、失败原因和尝试。几何通过、关系待复核和视觉评价分别记录；未知组合不能以构件数量或零错误冒充设计完成。
