"""从环境变量和 ``.env`` 文件加载后端配置。

嵌套配置使用双下划线分隔，例如 ``CHAT__API_KEY`` 会写入
``Settings.chat.api_key``。模块末尾创建一次全局 ``config``，其他模块只读取它，
从而保证一次进程中的配置视图一致。
"""

from typing import Literal

from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from app.utils.runtime_env import runtime_env_path

ModelProvider = Literal["auto", "openai", "dashscope", "deepseek", "moonshot", "mimo", "custom"]


class ModelConfig(BaseModel):
    """一项 OpenAI-compatible 模型服务的连接参数。"""

    provider: ModelProvider = "auto"
    # 模型名会原样传给兼容服务，例如 qwen-plus 或某个 embedding 模型名。
    name: str = "qwen-plus"
    # 密钥默认留空，实际值应通过环境变量提供，避免写入代码仓库。
    api_key: str = ""
    # 自建或第三方兼容服务填写 base_url；空值表示使用客户端默认地址。
    base_url: str = ""
    # Agent 的统一思考控制值。支持 Token 预算的模型使用精确上限；只支持
    # 推理档位的模型映射为 low/high/max；0 表示使用供应商默认值。
    thinking_budget: int = Field(default=4096, ge=0, le=262144)
    # 模型响应等待时限（秒）；流式接收有效输出后重新计时，非流式限制总等待。
    # 0 表示不设显式超时。
    timeout: float = 300.0
    # 网络类错误（含超时）的自动重试次数。连接不稳的上游（如走代理的
    # embedding 服务）需要有限重试；0 表示不重试。
    max_retries: int = 2


class EmbeddingModelConfig(ModelConfig):
    """Embedding 服务连接参数。

    批量向量化请求比对话请求短，默认单次超时 60s、手动重试 1 次：
    既能容忍代理/冷连接的首请求慢启动，又不会在服务不可用时让索引同步
    长时间空转。仍可用 ``EMBEDDING__TIMEOUT`` / ``EMBEDDING__MAX_RETRIES``
    覆盖。注意重试在 SDK 层被禁用（见 loader），这里的 max_retries 只控制
    带心跳日志的手动重试次数。
    """

    timeout: float = 60.0
    max_retries: int = 1


class RetrievalGateConfig(BaseModel):
    """向量召回门控；observe 只记结论，enforce 才影响运行时行为。"""

    mode: str = "observe"
    # Chroma distance 越小越相关；必须用当前 embedding 的正负样本校准后配置。
    max_distance: float | None = None
    min_hits: int = 1
    refusal_message: str = "知识库中暂无足够可靠的相关信息。"


class RAGTraceConfig(BaseModel):
    """RAG 请求追踪文件设置。"""

    enabled: bool = True
    root_dir: str = "storage/sessions/rag_traces"
    query_preview_chars: int = 300
    answer_preview_chars: int = 10000


class RAGSecurityConfig(BaseModel):
    """服务端身份头、PII 与基础内容安全设置。"""

    # 只有反向代理同时提供正确共享密钥时，身份头才会被视为可信。
    trusted_header_secret: str = ""
    pii_redaction_enabled: bool = True
    content_safety_enabled: bool = True


class RAGConfig(BaseModel):
    """Chroma 知识库的分片、召回和持久化参数。"""

    # 关闭后不创建向量索引，AgentService 会退回基础规范文件加载器。
    enabled: bool = True
    # 相对路径会由 AgentService 解析到 wild-server 根目录下。
    persist_dir: str = "storage/chroma"
    collection_name: str = "wild_knowledge_base"
    # chunk_overlap 必须小于 chunk_size；Loader 内还会对异常值做边界收敛。
    chunk_size: int = 900
    chunk_overlap: int = 150
    # 单查询最终保留的唯一分片数；Loader 会多召回一些再按内容哈希去重。
    top_k: int = 6
    # 是否在去重后按"知识权威性 + 与查询检索词重叠"做纯规则重排。
    # 纯确定性、零 LLM 调用，只调整片段先后顺序，不改变召回集合。
    rerank_enabled: bool = True
    # 基础规范与 RAG 片段拼接后的最大字符数，防止 System Prompt 无限增长。
    max_context_chars: int = 18000
    # 没配置远程 embedding 时允许使用本地 hash 向量，仅适合开发 smoke test。
    allow_hash_fallback: bool = True
    # AgentService 创建 RAG Loader 后是否自动在后台线程执行索引同步。
    # 同步永远不阻塞服务启动：索引就绪前查询自动降级为基础规范上下文。
    auto_sync: bool = True
    retrieval_gate: RetrievalGateConfig = Field(default_factory=RetrievalGateConfig)
    trace: RAGTraceConfig = Field(default_factory=RAGTraceConfig)
    security: RAGSecurityConfig = Field(default_factory=RAGSecurityConfig)


class WebResearchConfig(BaseModel):
    """受控网络研究配置。

    网络研究是 Plan 模式的扩展：本地知识覆盖不足时，经覆盖闸门批准后调用外部
    搜索服务补充本次请求临时上下文。搜索结果是"临时资料"，不直接写入正式
    知识库；候选内容进入 staging 隔离区，经审查与人工批准后由 Loader 增量同步。

    默认关闭（enabled=False）：不配置 api_key 时整体不可用，Plan 模式回退为
    纯本地 RAG，行为与之前完全一致。
    """

    enabled: bool = False
    # 外部搜索服务配置。填入 API key 即可启用；搜索客户端按 provider 选择实现。
    provider: str = "tavily"          # 当前支持 tavily；可扩展 serp/bing
    api_key: str = ""
    base_url: str = "https://api.tavily.com/search"
    # 单次研究最多查询数、最多抓取网页数、单页最大字符数（防上下文爆炸）。
    max_queries: int = 3
    max_pages: int = 4
    max_content_chars: int = 4000
    timeout_ms: int = 15000
    # 覆盖比阈值：低于该值触发联网（与 research_evidence_gate 默认一致）。
    coverage_threshold: float = 0.8
    # 是否只对"本应联网但未联网"的请求记录日志（阶段1 观察模式）。
    observe_only: bool = True


class AssetConfig(BaseModel):
    """PBR 资产本地入库与公开地址配置。"""

    backend: str = "local"
    root_dir: str = "storage/assets"
    public_base_url: str = "/api/assets"
    max_file_bytes: int = 20 * 1024 * 1024
    max_total_bytes: int = 80 * 1024 * 1024


class Settings(BaseSettings):
    """整个后端进程使用的顶层配置对象。"""

    # Pydantic Settings 会先读环境变量，再读取固定的运行时配置文件；默认位于
    # wild-server/.env，容器可用 WILD_RUNTIME_ENV_FILE 指向宿主机挂载文件。
    model_config = SettingsConfigDict(
        env_file=str(runtime_env_path()),
        env_file_encoding="utf-8",
        # 例如 RAG__TOP_K=8 会映射到 rag.top_k。
        env_nested_delimiter="__",
        # 忽略暂未被代码消费的环境变量，便于前后端共用同一份环境文件。
        extra="ignore",
    )

    # default_factory 确保每个 Settings 实例拥有独立的嵌套配置对象。
    chat: ModelConfig = Field(default_factory=ModelConfig)
    embedding: EmbeddingModelConfig = Field(default_factory=EmbeddingModelConfig)
    rerank: ModelConfig = Field(default_factory=ModelConfig)
    rag: RAGConfig = Field(default_factory=RAGConfig)
    web_research: WebResearchConfig = Field(default_factory=WebResearchConfig)
    assets: AssetConfig = Field(default_factory=AssetConfig)


# 导入 config.py 时完成一次解析；业务模块不应在运行中修改这个对象。
config = Settings()
