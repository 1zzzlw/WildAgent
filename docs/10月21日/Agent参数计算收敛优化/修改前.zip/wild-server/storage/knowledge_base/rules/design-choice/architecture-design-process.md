---
entity_name: architecture_design_process
topic: parameters
status: supported
authority: maintainer
primary_terms: [建筑设计步骤与关系复核]
synonyms: []
---

# 建筑设计步骤与关系复核

## 设计步骤与字段落地

适用：architecture 起草与修订。提炼自《WILD蓝图书写流程》“建筑样式设计”及类型设计文档，按当前 DesignDocument 整理。方法不固定建筑类型、层数、尺寸、风格或配色；用户要求和选定粒度决定范围。

1. 需求与形制：明确用途、用户硬要求和本次设计特征；design_intent 只记录实际采用的目标、必要假设、空间与材料策略、已选系统。
2. 体量与标高：先定层数、层高和各体量轮廓，写 massing、volumes。总体包络由本次体量布局核对；退让、悬挑、庭院等要有实际空间安排，不能只写概念。
3. 功能与交通：确定入口、使用空间及层间连通，写 circulation；需要室内分区时用 floor_layouts 表达房间和独立内墙。楼梯在 components 声明位置、整组占地、形式和 floor_connections；精确踏步参数由实现阶段计算，已有明确要求才在图纸填写。
4. 围护与开口：按空间用途确定各体量有墙或开敞的面，再安排门窗类型、尺寸和位置。facades 表达围护与概略开口，差异写 volume.facades；特殊门窗在 components 给出明确实例和宿主。
5. 屋面与附属：roof 按体量分配屋型、坡向和出檐；选定的门廊、露台、防护及其他实体在 components 落位，明确与主体的承接。
6. 材料与表达：落实材料和配色；design_intent.material_strategy 与构件 description/form 保持一致。构件内部零件与最终 WILD 几何留给后续实现。

设计粒度通过本次选择的空间联系、立面虚实、开口分格、截面间距与材料分区表达。需要室内使用表达时，设计入口、分区、门洞与必要家具的关系；没有选择的系统不强加。构件数量不是精细程度的替代指标。

图纸确定 construction、显式楼面顶标高、楼梯连接和占地；程序计算板底、必要铺板分片、双跑平台与梯井。重复矩形条板可保存 repetition 参数；相接边界可保存 connections；具体颜色已确定时保存 materials.definitions 与构件 material_bindings。数据入口和推导方法见 architecture-design-expression，不在此重复另一套字段。

## 交付前的关系复核

适用：architecture 起草后与局部修订后。依据类型文档的设计层自检方法，结合当前 contracts.py、coordinates.py、compilation.py 核对已有图纸；这是设计复核指引，不表示程序已实现全部空间、结构或专业规范检查。

- 意图与数据：已选结构、交通和形制特征应能在 volumes、facades、roof、floor_layouts 或 components 找到对应安排；仅写“庭院、通高、幕墙”等名称不算落实。按粒度保留必要内容，不用继续简化替代修复。
- 体量与承接：核对总体包络、楼层范围、上下层和附体的支承。体量包络相交不等于实体碰撞；共用界面的围护与连通方式仍要明确，避免重复墙或无意封堵。
- 围护与开口：每个立面 pattern 长度等于 bays；实墙无开口用 empty，开敞用 open。门窗引用有墙的面或独立内墙，洞口在宿主范围内，同墙开口不重叠；内墙端头避开已安排的洞口。
- 通行与楼梯：先安排入口、使用空间与层间到达；分隔处需要通行时声明门洞。需要保留净空的主要水平通路可写 circulation.paths 的 floor、世界 X/Z 折线 points、width/height，净宽高由本次设计选择。路径避开墙垛、家具，穿墙处有相容门洞；楼梯、平台和出口共用同一标高。
- 屋面与附属：屋面归属清楚；roof 与 components 不重复安排同一整片屋面。已选附属构件的宿主、位置、尺寸及相接标高相互一致，材料描述不冲突。
- 修订联动：生成后核对实际实体，再判断入口是否被占用、家具是否遮挡所选开口、楼梯和露台是否到达。修改体量、层高或宿主时复核依附件；仅修受影响关系，保留其他设计决定。数值可由程序计算，说明文字不能代替实际产物。
