"""空间图纸与交接回归；本轮仅编写，按用户要求不执行。"""
import hashlib
import json
import math
from copy import deepcopy
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from pydantic import ValidationError
from app.design.coordinates import design_geometry_context, repetition_geometry
from app.design.resolver import architecture_plan_from_document, build_design_document, _stable_hash
from app.design.relations import review_connections
from app.design.spatial_review import review_spatial_use
from app.agent.validation.diagnostics import blueprint_fingerprint
from app.agent.vision.workflow import load_review_source


def plan():
    return {"massing": {"shape":"rectangular", "width":10, "depth":10, "floors":2,
                        "modeled_floors":2, "floor_height":3.4},
            "volumes":[{"id":"main", "x":0, "z":0, "width":10, "depth":10, "start_floor":1, "end_floor":2}],
            "structural_grid":{"system":"wall_bearing", "x_bays":2, "z_bays":2},
            "facades":{face:{"bays":1,"ground_pattern":["empty"],"upper_pattern":["empty"]}
                       for face in ("front","back","left","right")},
            "roof":{"type":"flat"}, "circulation":{"vertical_strategy":"stair"}}


def document(raw=None):
    return build_design_document(raw or plan(),session_id="spatial_fixture",source_request="空间图纸回归",
                                 building_type="building",style_intent=[])


def blueprint(elements=(), components=()):
    return {"geometry":{"elements":list(elements),"components":list(components)},"materials":{}}


def box(name, position, dimensions, **kwargs):
    return {"id":name,"type":"primitive","shape":"box","position":position,"dimensions":dimensions,**kwargs}


def path_design(points=None, width=1, height=2):
    raw=plan()
    raw["circulation"]["paths"]=[{"id":"entry_route","floor":1,"points":points or [[0,5],[10,5]],
                                    "width":width,"height":height}]
    return document(raw).decisions.model_dump(mode="json")


class SpatialDesignContracts(unittest.TestCase):
    def test_layout_survives_draft_and_plan_roundtrip(self):
        raw=plan()
        raw["construction"]={"slab_thickness":0.24,"wall_thickness":0.3}
        raw["floor_layouts"]=[{"floor":1,"level":0.36,"rooms":[{"id":"room","bounds":{"x":0,"z":0,"width":5,"depth":5},"void":False}],
                               "walls":[{"id":"partition","from":[5,0],"to":[5,5],"thickness":0.15}]}]
        raw["circulation"]["paths"]=[{"id":"route","floor":1,"points":[[1,1],[4,1]],"width":1,"height":2}]
        doc=document(raw)
        result=architecture_plan_from_document(doc)
        self.assertEqual(raw["floor_layouts"],result["floor_layouts"])
        self.assertEqual(raw["construction"],result["construction"])
        self.assertEqual(raw["circulation"]["paths"],result["circulation"]["paths"])
        self.assertIn("from",result["floor_layouts"][0]["walls"][0])
        geometry=design_geometry_context(doc.decisions.model_dump(mode="json"))
        self.assertAlmostEqual(0.12,geometry["levels"][0]["slab_bottom_y"])

    def test_legacy_bounds_and_false_are_preserved(self):
        raw=plan()
        bounds={"x_start":0,"x_end":5,"z_start":0,"z_end":4}
        raw["floor_layouts"]=[{"floor":1,"rooms":[{"bounds":bounds,"void":False}]}]
        room=document(raw).model_dump(mode="json")["decisions"]["floor_layouts"][0]["rooms"][0]
        self.assertEqual(bounds,room["bounds"])
        self.assertIs(room["void"],False)

    def test_invalid_paths(self):
        for change in ("duplicate","zero_width","repeated_point","unknown_floor","infinite"):
            with self.subTest(change=change):
                raw=plan()
                p={"id":"route","floor":1,"points":[[1,1],[4,1]],"width":1,"height":2}
                if change=="zero_width": p["width"]=0
                if change=="repeated_point": p["points"]=[[1,1],[1,1]]
                if change=="unknown_floor": p["floor"]=3
                if change=="infinite": p["points"][1][0]=float("inf")
                raw["circulation"]["paths"]=[p,p] if change=="duplicate" else [p]
                with self.assertRaises((ValidationError,ValueError)): document(raw)

    def test_complete_stair_void_for_four_directions(self):
        for direction in ("+x","-x","+z","-z"):
            with self.subTest(direction=direction):
                raw=plan()
                width,depth=(4.1,2.6) if direction.endswith("x") else (2.6,4.1)
                component={"id":"stair","type":"stair","placement":{"position":[5,1.7,5]},
                           "size":{"width":width,"depth":depth},"floor_connections":[{"from_floor":1,"to_floor":2}],
                           "form":{"shape":"U","flights":2,"span_direction":direction,"flight_width":1.2,
                                   "landing_depth":1.2,"rises":10,"tread_depth":0.29,"riser_height":0.17}}
                raw["components"]=[component]
                g=design_geometry_context(document(raw).decisions.model_dump(mode="json"))
                void=g["levels"][1]["voids"][0]["bounds"]
                self.assertAlmostEqual(10.66,(void[2]-void[0])*(void[3]-void[1]))
                self.assertAlmostEqual(89.34,sum((c-a)*(d-b) for a,b,c,d in g["levels"][1]["floor_rectangles"]))
                self.assertAlmostEqual(1.7,g["stair_routes"]["stair"]["landing"]["top_y"])
                # 主体拆分后只有 delegated_components，验收必须沿用相同的梯井。
                from app.design.compilation import project_drawing
                from app.design.markers import body_floor_errors
                body=project_drawing(document(raw)).component_markers[0]["design"]
                body_geometry=design_geometry_context(body)
                self.assertEqual(g["levels"],body_geometry["levels"])
                floors=[{"id":f"floor_{level['index']}_{i}","type":"floor",
                         "from":[a,level["slab_bottom_y"],b],"to":[c,level["slab_bottom_y"],d],"thickness":0.2}
                        for level in g["levels"] for i,(a,b,c,d) in enumerate(level["floor_rectangles"])]
                self.assertFalse(body_floor_errors(floors,body))
                for field in ("center","height","riser"):
                    with self.subTest(conflict=field):
                        bad=deepcopy(raw)
                        c=bad["components"][0]
                        if field=="center": c["placement"]["position"][1]+=0.1
                        if field=="height": c["size"]["height"]=3.5
                        if field=="riser": c["form"]["riser_height"]=0.171
                        with self.assertRaises(ValueError):
                            design_geometry_context(document(bad).decisions.model_dump(mode="json"))

    def test_repetition_uses_group_center_and_validates_envelope(self):
        for axis in ("x","y","z"):
            with self.subTest(axis=axis):
                row={"id":"screen","placement":{"position":[5,5,5]},
                     "repetition":{"count":3,"axis":axis,"spacing":0.5,"member_size":[0.1,0.1,0.1]}}
                result=repetition_geometry(row)
                index="xyz".index(axis)
                self.assertEqual([4.5,5,5.5],[p[index] for p in result["positions"]])
                bad=deepcopy(row);bad["size"]={"width":9}
                with self.assertRaises(ValueError): repetition_geometry(bad)

    def test_named_material_binding_rejects_missing_definition(self):
        raw=plan()
        raw["components"]=[{"id":"screen","type":"assembly","material_bindings":{"material":"timber"}}]
        with self.assertRaises(ValueError): document(raw)
        raw["materials"]={"definitions":{"timber":{"baseColor":[0.4,0.2,0.1],"roughness":0.7}}}
        doc=document(raw)
        self.assertIn("timber",architecture_plan_from_document(doc)["materials"]["definitions"])

    def test_connection_checks_real_top_and_bottom(self):
        base=blueprint([box("beam_part",[0,3.2,0],[4,0.4,0.2])])
        marker={"id":"post","design":{"connections":[{"target":"beam","own_face":"top","target_face":"bottom","offset":0}]},
                "connection_entity_ids":{"beam":["beam_part"]}}
        good=review_connections(base,[box("post_part",[0,1.5,0],[0.2,3,0.2])],marker)
        self.assertEqual([],good["errors"])
        bad=review_connections(base,[box("post_part",[0,1.4,0],[0.2,2.8,0.2])],marker)
        self.assertTrue(bad["errors"])

    def test_normalization_keeps_spatial_decisions(self):
        from app.agent.generation.architecture.planning import normalize_architecture_plan
        raw=architecture_plan_from_document(document())
        raw["floor_layouts"]=[{"floor":1,"level":0.36}]
        raw["construction"]={"slab_thickness":0.24,"wall_thickness":0.3}
        raw["circulation"]["paths"]=[{"id":"route","floor":1,"points":[[1,1],[4,1]],"width":1,"height":2}]
        raw["materials"]["definitions"]={"timber":{"baseColor":[0.4,0.2,0.1],"roughness":0.7}}
        result=normalize_architecture_plan(raw,"空间图纸回归")
        for key in ("floor_layouts","construction","circulation","materials"):
            self.assertEqual(raw[key],result[key],key)

    def test_terrace_door_bottom_matches_actual_floor_top(self):
        wall={"id":"wall","type":"wall","from":[0,3.4,0],"to":[5,6.8,0],"thickness":0.24}
        floor={"id":"terrace","type":"floor","from":[0,3.18,-2],"to":[5,3.18,0],"thickness":0.22}
        door={"id":"door","type":"door","parentWall":"wall","from":[1,3.4,0],"width":1,"height":2.2}
        marker={"id":"door","design":{"connections":[{"target":"terrace","own_face":"bottom","target_face":"top","offset":0}]}}
        self.assertFalse(review_connections(blueprint([wall,floor]),[door],marker)["errors"])
        door["from"][1]=3.5
        self.assertTrue(review_connections(blueprint([wall,floor]),[door],marker)["errors"])

    def test_missing_floor_and_void_coverage_cannot_pass(self):
        from app.design.markers import body_floor_errors
        raw=plan()
        raw["floor_layouts"]=[{"floor":2,"rooms":[{"id":"void","void":True,"bounds":{"x":4,"z":4,"width":2,"depth":2}}]}]
        design=document(raw).decisions.model_dump(mode="json")
        lower={"id":"lower","type":"floor","from":[0,-0.2,0],"to":[10,-0.2,10],"thickness":0.2}
        upper={"id":"upper","type":"floor","from":[0,3.2,0],"to":[10,3.2,10],"thickness":0.2}
        self.assertTrue(any("必要楼面缺失" in e for e in body_floor_errors([lower],design)))
        self.assertTrue(any("挑空" in e for e in body_floor_errors([lower,upper],design)))

    def test_binding_uses_approved_definition_and_fills_native_field(self):
        from app.agent.plan.implementation import _bind_materials
        material={"baseColor":[0.4,0.2,0.1],"roughness":0.7,"metallic":0,"albedo":1,"lightingCondition":"D65_noon"}
        base=blueprint();base["materials"]={"timber":material}
        marker={"id":"screen","type":"assembly","design":{"material_bindings":{"material":"timber"}}}
        row={"geometry":{"elements":[box("slat",[0,1,0],[0.1,2,0.1])],"components":[]}}
        adopted,_=_bind_materials(base,row,marker)
        self.assertEqual("timber",adopted["geometry"]["elements"][0]["material"])
        row["materials"]={"timber":{**material,"baseColor":[1,0,0]}}
        with self.assertRaises(ValueError): _bind_materials(base,row,marker)


class SpatialUse(unittest.TestCase):
    def test_thin_column_between_previous_sampling_points(self):
        column={"type":"column","id":"thin_post","base":[5.037,0,5.1],"height":3,
                "bottomRadius":0.025,"topRadius":0.025,"style":"modern"}
        result=review_spatial_use(blueprint([column]),path_design())
        self.assertEqual(["thin_post"],result["paths"][0]["blocking_entity_ids"])

    def test_real_door_passage_and_insufficient_clear_width(self):
        wall={"type":"wall","id":"partition","from":[0,0,5],"to":[10,3,5],"thickness":0.2}
        door={"type":"door","id":"door","parentWall":"partition","from":[4.4,0,0],"width":1.2,"height":2.5,"frameWidth":0.05}
        design=path_design([[5,1],[5,9]],width=1)
        self.assertFalse(review_spatial_use(blueprint([wall],[door]),design)["errors"])
        door["width"]=0.9
        self.assertTrue(review_spatial_use(blueprint([wall],[door]),design)["errors"])

    def test_headroom_and_y_rotated_furniture(self):
        roof=box("overhead",[5,2.3,5],[2,0.2,2])
        self.assertFalse(review_spatial_use(blueprint([roof]),path_design())["errors"])
        furniture={"id":"cabinet","type":"furniture","position":[5,0,5],"rotation":[0,math.pi/4,0],
                   "dimensions":{"width":1,"depth":0.5,"height":2}}
        self.assertTrue(review_spatial_use(blueprint([furniture]),path_design())["errors"])

    def test_omitted_frame_width_uses_renderer_default(self):
        wall={"type":"wall","id":"partition","from":[0,0,5],"to":[10,3,5],"thickness":0.2}
        door={"type":"door","id":"door","parentWall":"partition","from":[4.45,0,0],"width":1.1,"height":2.5}
        design=path_design([[5,1],[5,9]],width=1)
        self.assertTrue(review_spatial_use(blueprint([wall],[door]),design)["errors"])
        door["frameWidth"]=0
        self.assertFalse(review_spatial_use(blueprint([wall],[door]),design)["errors"])

    def test_instances_translate_geometry_and_unsupported_placements_need_review(self):
        bp=blueprint()
        bp["geometry"]["templates"]={"post":box("template",[0,1,0],[0.1,2,0.1])}
        bp["geometry"]["instances"]=[{"id":"post_at_route","ref":"post","position":[5,0,5]}]
        self.assertEqual(["post_at_route"],review_spatial_use(bp,path_design())["paths"][0]["blocking_entity_ids"])
        bp["geometry"]["instances"]=[]
        bp["geometry"]["placements"]=[{"id":"tiles","template":"post"}]
        self.assertEqual("needs_review",review_spatial_use(bp,path_design())["paths"][0]["status"])

    def test_unknown_far_shape_does_not_mark_every_route(self):
        far={"id":"far_sphere","type":"primitive","shape":"sphere","position":[100,1,100],"radius":1}
        near={**far,"id":"near_sphere","position":[5,1,5]}
        self.assertEqual("satisfied",review_spatial_use(blueprint([far]),path_design())["paths"][0]["status"])
        self.assertEqual("needs_review",review_spatial_use(blueprint([near]),path_design())["paths"][0]["status"])

    def test_input_is_not_mutated(self):
        bp=blueprint([box("obstacle",[5,1,5],[1,2,1])]);design=path_design()
        before=deepcopy((bp,design))
        review_spatial_use(bp,design)
        self.assertEqual(before,(bp,design))


class ActualVisualInput(unittest.TestCase):
    def test_actual_bytes_preserved_and_stale_snapshot_rejected(self):
        doc=document()
        bp=blueprint([box("part",[1,1,1],[1,1,1])])
        raw=(json.dumps(bp,indent=2)+"\r\n").encode()
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder)/"actual.wild";p.write_bytes(raw)
            snapshot=Path(folder)/"snapshot.json"
            snapshot.write_text(json.dumps({"blueprint_fingerprint":blueprint_fingerprint(bp),"design_hash":_stable_hash(doc)}),encoding="utf-8")
            adopted,_,binding=load_review_source(doc,p,snapshot)
            self.assertEqual(raw,adopted)
            self.assertEqual(hashlib.sha256(raw).hexdigest(),binding["input_sha256"])
            self.assertEqual("matched_snapshot",binding["design_binding"])
            snapshot.write_text(json.dumps({"blueprint_fingerprint":"stale","design_hash":_stable_hash(doc)}),encoding="utf-8")
            with self.assertRaises(ValueError): load_review_source(doc,p,snapshot)


if __name__=="__main__":
    unittest.main()
