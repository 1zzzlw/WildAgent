"""所选水平通路的有限净空检查；连续几何相交，不用离散点抽样。"""
from copy import deepcopy
from math import cos, hypot, sin

from .coordinates import design_geometry_context, subtract_rectangles
from .relations import TOLERANCE, entity_box, entity_index


def _corners(box):
    x, _, z = box["center"]
    w, _, d = box["half"]
    c, s = cos(box["yaw"]), sin(box["yaw"])
    return [(x+c*a+s*b, z-s*a+c*b) for a,b in ((-w,-d), (w,-d), (w,d), (-w,d))]


def _overlap(first, second):
    """凸矩形分离轴判据；仅接触边界不算侵入。"""
    for polygon in (first, second):
        for a, b in zip(polygon, polygon[1:]+polygon[:1]):
            dx, dz = b[0]-a[0], b[1]-a[1]
            length = hypot(dx,dz)
            axis = (-dz/length,dx/length)
            p = [x*axis[0]+z*axis[1] for x,z in first]
            q = [x*axis[0]+z*axis[1] for x,z in second]
            if min(max(p),max(q))-max(min(p),min(q)) <= TOLERANCE:
                return False
    return True


def _route_box(a, b, path):
    from math import atan2
    return {"center": [(a[0]+b[0])/2, path["base_y"]+path["height"]/2, (a[1]+b[1])/2],
            "half": [hypot(b[0]-a[0],b[1]-a[1])/2,path["height"]/2,path["width"]/2],
            "yaw": atan2(-(b[1]-a[1]),b[0]-a[0])}


def _intersects(route, obstacle):
    if min(route["center"][1]+route["half"][1], obstacle["center"][1]+obstacle["half"][1])-max(
            route["center"][1]-route["half"][1], obstacle["center"][1]-obstacle["half"][1]) <= TOLERANCE:
        return False
    if obstacle.get("circle"):
        dx, dz = obstacle["center"][0]-route["center"][0], obstacle["center"][2]-route["center"][2]
        c, s = cos(route["yaw"]), sin(route["yaw"])
        u, v = c*dx-s*dz, s*dx+c*dz
        distance = hypot(max(abs(u)-route["half"][0],0), max(abs(v)-route["half"][2],0))
        return distance < obstacle["half"][0]-TOLERANCE
    return _overlap(_corners(route), _corners(obstacle))


def _wall_solids(wall, openings):
    box = entity_box(wall)
    if not box:
        return None
    length, height = box["half"][0]*2, box["half"][1]*2
    bottom = box["center"][1]-height/2
    cuts = []
    for opening in openings:
        if opening.get("parentWall") != wall["id"] or opening.get("type") not in {"door","opening"}:
            continue
        along,y,_ = opening["from"]
        frame = opening.get("frameWidth",0.08) if opening["type"]=="door" else 0
        cuts.append([along+frame,y,along+opening["width"]-frame,y+opening["height"]-frame])
    rectangles = subtract_rectangles([[0,bottom,length,bottom+height]], cuts)
    a,b = wall["from"],wall["to"]
    ux,uz = (b[0]-a[0])/length,(b[2]-a[2])/length
    return [{"center": [a[0]+ux*(lo+hi)/2,(low+high)/2,a[2]+uz*(lo+hi)/2],
             "half": [(hi-lo)/2,(high-low)/2,wall["thickness"]/2],"yaw":box["yaw"]}
            for lo,low,hi,high in rectangles]


def _review_envelope(entity):
    """仅用于缩小未知形态的待复核范围，不用包围盒签发碰撞错误。"""
    if entity.get("curve") or any((entity.get("rotation") or [0,0,0])[i] for i in (0,2)):
        return None
    if entity.get("type") == "column":
        return None  # 柱头、鼓肚和倾斜可能超出名义半径；简单圆柱已由 entity_box 处理。
    points = entity.get("path")
    if isinstance(points,list) and points and all(isinstance(p,list) and len(p)==3 for p in points):
        radius=max(entity.get("postRadius",0),entity.get("railRadius",0))
        low=[min(p[i] for p in points)-radius for i in range(3)]
        high=[max(p[i] for p in points)+radius for i in range(3)]
        high[1]+=entity.get("height",0)
        return {"center":[(a+b)/2 for a,b in zip(low,high)],"half":[max((b-a)/2,TOLERANCE) for a,b in zip(low,high)],"yaw":0}
    p = entity.get("position") or entity.get("base")
    if not isinstance(p,list) or len(p)!=3:
        a,b = entity.get("from"),entity.get("to")
        if not a or not b:
            return None
        p=[(v+w)/2 for v,w in zip(a,b)]
        size=[abs(a[i]-b[i])+entity.get("width",0) for i in range(3)]
    elif entity.get("type")=="roof":
        size=[entity.get("span",0),entity.get("height",0)+entity.get("thickness",0),entity.get("depth",0)]
        p=[p[0],p[1]+size[1]/2,p[2]]
    else:
        size=entity.get("dimensions")
        if isinstance(size,dict):
            size=[size.get(k,0) for k in ("width","height","depth")]
        if not isinstance(size,list):
            radius=max(entity.get("radius",0),entity.get("radiusTop",0),entity.get("radiusBottom",0),
                       entity.get("topRadius",0),entity.get("bottomRadius",0))
            size=[2*radius,entity.get("height",2*radius),2*radius]
            if entity.get("base"):
                p=[p[0],p[1]+size[1]/2,p[2]]
    scale=entity.get("scale",[1,1,1])
    if not any(size):
        return None
    return {"center":p,"half":[max(abs(v*s)/2,TOLERANCE) for v,s in zip(size,scale)],
            "yaw":(entity.get("rotation") or [0,0,0])[1]}


def review_spatial_use(blueprint, design):
    """返回逐路线证据；不移动家具、不修改路线，不证明完整导航或门扇扫掠。"""
    geometry=design_geometry_context(design)
    entities=list(entity_index(blueprint).values())
    # 平移实例可精确展开；其他变换保持待复核，不假装消失。
    templates=blueprint.get("geometry",{}).get("templates",{})
    for instance in blueprint.get("geometry",{}).get("instances",[]):
        entity=deepcopy(templates.get(instance.get("ref"),{}))
        if not entity or instance.get("rotation",[0,0,0])!=[0,0,0] or instance.get("scale",[1,1,1])!=[1,1,1]:
            entities.append({"type":"unresolved_instance","id":instance.get("id","?"),"position":instance.get("position")})
            continue
        entity["id"]=instance["id"]
        offset=instance.get("position",[0,0,0])
        # 门窗 from 是沿宿主的局部坐标，实例平移叠加在宿主解析后的几何上。
        if entity.get("type") in {"door","window","opening"}:
            entities.append({"type":"unresolved_instance","id":instance["id"]})
            continue
        for field in ("from","to","position","base"):
            if field in entity:
                entity[field]=[v+w for v,w in zip(entity[field],offset)]
        if "path" in entity:
            entity["path"]=[[v+w for v,w in zip(point,offset)] for point in entity["path"]]
        entities.append(entity)
    entities.extend({"type":"unresolved_placement","id":placement["id"]}
                    for placement in blueprint.get("geometry",{}).get("placements",[]))
    openings=[e for e in entities if e.get("type") in {"door","opening"}]
    rows=[]
    for path in geometry["paths"]:
        segments=[_route_box(a,b,path) for a,b in zip(path["points"],path["points"][1:])]
        blockers,unknown=set(),set()
        for e in entities:
            if e.get("type") in {"door","opening","window","light"}:
                continue
            boxes=_wall_solids(e,openings) if e.get("type")=="wall" else None
            if boxes is None:
                box=entity_box(e)
                boxes=[box] if box else None
            if boxes is not None:
                if any(_intersects(segment,box) for segment in segments for box in boxes):
                    blockers.add(e["id"])
            else:
                envelope=_review_envelope(e)
                if envelope is None or any(_intersects(segment,envelope) for segment in segments):
                    unknown.add(e["id"])
        rows.append({"id":path["id"],"floor":path["floor"],"width":path["width"],"height":path["height"],
                     "status":"open" if blockers else "needs_review" if unknown else "satisfied",
                     "blocking_entity_ids":sorted(blockers),"unverified_entity_ids":sorted(unknown)})
    return {"paths":rows,"scope":"declared horizontal segment prisms and nominal furniture occupancy; no full navigation, support or door-swing proof",
            "errors":[f"通路 {r['id']} 净空被 {', '.join(r['blocking_entity_ids'])} 侵入，保持图纸净宽高并修订相关构件"
                      for r in rows if r["blocking_entity_ids"]]}
