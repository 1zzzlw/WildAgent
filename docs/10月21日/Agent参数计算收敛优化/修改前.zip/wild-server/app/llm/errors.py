"""把模型供应商异常转换为稳定、可展示的错误协议。

模型服务故障（额度、鉴权、限流、超时等）不是 Blueprint 几何错误，
不能进入 callback 的建筑修复循环。本模块只做错误分类，不依赖具体供应商 SDK。
"""

from __future__ import annotations

import asyncio
import re
from typing import Any


def classify_model_error(exc: Exception) -> dict[str, Any]:
    """
    返回可写入节点诊断的模型错误信息。
    """
    raw_message = str(exc)
    lowered = f"{type(exc).__name__}: {raw_message}".lower()

    if _is_timeout_exception(exc):
        return {
            "category": "transport_error",
            "status_code": None,
            "retryable": True,
            "terminal_current_run": True,
            "user_message": "等待模型响应超时，本次生成已停止，请稍后重新生成。",
            "raw_error": raw_message[:500] or type(exc).__name__,
        }

    status_code = _extract_status_code(exc, lowered)

    if _contains_any(
        lowered,
        (
            "free quota exhausted",
            "quota exhausted",
            "insufficient_quota",
            "allocationquota",
            "billing quota",
            "余额不足",
            "额度耗尽",
            "免费额度",
        ),
    ):
        category = "quota_exhausted"
        retryable = False
        user_message = "模型服务额度已耗尽，请充值、关闭仅使用免费额度限制，或更换可用模型后重新生成。"
    elif status_code == 401 or _contains_any(
        lowered,
        ("invalid api key", "authentication failed", "unauthorized", "鉴权失败"),
    ):
        category = "authentication"
        retryable = False
        user_message = "模型服务鉴权失败，请检查 API Key 和模型服务配置。"
    elif status_code == 403 or _contains_any(
        lowered, ("permission denied", "forbidden")
    ):
        category = "access_denied"
        retryable = False
        user_message = "模型服务拒绝访问，请检查模型权限、账号额度和服务配置。"
    elif status_code == 404 or _contains_any(
        lowered,
        (
            "model_not_found",
            "model not found",
            "notfounderror",
            "does not exist",
            "模型不存在",
        ),
    ):
        category = "model_not_found"
        retryable = False
        user_message = "未找到配置的模型，请检查模型名称、服务地址和供应商是否匹配。"
    elif status_code == 429 or _contains_any(
        lowered, ("rate limit", "too many requests", "限流")
    ):
        category = "rate_limited"
        retryable = True
        user_message = "模型服务请求过于频繁，本次生成已停止，请稍后重新生成。"
    elif status_code == 400:
        category = "invalid_request"
        retryable = False
        user_message = "模型服务拒绝了请求，请检查模型名称、参数和上下文长度配置。"
    elif (status_code is not None and status_code >= 500) or _contains_any(
        lowered,
        ("service unavailable", "bad gateway", "gateway timeout"),
    ):
        category = "provider_unavailable"
        retryable = True
        user_message = "模型服务暂时不可用，本次生成已停止，请稍后重新生成。"
    elif _contains_any(
        lowered,
        (
            "timeout",
            "timed out",
            "connection error",
            "apiconnectionerror",
            "connecterror",
            "连接超时",
        ),
    ):
        category = "transport_error"
        retryable = True
        user_message = "连接模型服务失败，本次生成已停止，请检查网络后重新生成。"
    else:
        category = "model_error"
        retryable = False
        user_message = "模型服务调用失败，本次生成已停止，请检查服务配置和后台日志。"
        return {
            "category": category,
            "status_code": status_code,
            "retryable": retryable,
            "terminal_current_run": True,
            "user_message": user_message,
            #  兜底必须带原文与异常类型：分类器文案库永远追不上供应商网关的
            # 各种非标准报错，没有原文这条诊断就是死胡同（2026-09-29 排查教训）。
            "raw_error": f"{type(exc).__name__}: {raw_message}"[:500],
        }

    return {
        "category": category,
        "status_code": status_code,
        "retryable": retryable,
        "terminal_current_run": True,
        "user_message": user_message,
    }


def collect_component_model_errors(
    component_diagnostics: object,
) -> list[dict[str, Any]]:
    """从并行组件诊断中收集模型故障，供 merge 统一终止当前运行。"""
    if not isinstance(component_diagnostics, dict):
        return []

    failures: list[dict[str, Any]] = []
    for diag_key, diag in component_diagnostics.items():
        # 诊断键在 component_diagnostics 里是 ``{type}_gen``（生成阶段）
        if not str(diag_key).endswith("_gen") or not isinstance(diag, dict):
            continue
        model_error = diag.get("model_error")
        if not isinstance(model_error, dict) or not model_error.get(
            "terminal_current_run"
        ):
            continue
        component_type = str(diag_key)[:-4]
        failures.append(
            {
                **model_error,
                "component_type": component_type,
                "label": diag.get("label", component_type),
            }
        )
    return failures


def _extract_status_code(exc: Exception, lowered_message: str) -> int | None:
    for candidate in (
        getattr(exc, "status_code", None),
        getattr(getattr(exc, "response", None), "status_code", None),
    ):
        if isinstance(candidate, int):
            return candidate

    match = re.search(
        r"(?:error code|status(?: code)?)\s*[:=]?\s*(\d{3})", lowered_message
    )
    return int(match.group(1)) if match else None


def _contains_any(text: str, needles: tuple[str, ...]) -> bool:
    return any(needle in text for needle in needles)


def _is_timeout_exception(exc: Exception) -> bool:
    """按异常类型判定超时，连接失败由分类器另行识别。

    - ``asyncio.TimeoutError``：统一调用层超时，可能没有错误消息；
    - ``openai.APITimeoutError`` 及底层 ``httpx.TimeoutException``：
      SDK 抛出，文案不一定含 "timed out"。

    供应商 SDK 用惰性导入：本模块声明"不依赖具体供应商 SDK"，缺包时退回文案匹配。
    """
    if isinstance(exc, (asyncio.TimeoutError, TimeoutError)):
        return True
    try:
        from openai import APITimeoutError

        if isinstance(exc, APITimeoutError):
            return True
    except ImportError:  # pragma: no cover - openai 未安装时退回文案匹配
        pass
    try:
        import httpx

        if isinstance(exc, httpx.TimeoutException):
            return True
    except ImportError:  # pragma: no cover
        pass
    return False


def model_failure_result(exc: Exception) -> dict[str, Any]:
    """把 LLM 服务故障转成可写入 LangGraph state 的阻断结果。"""
    info = classify_model_error(exc)
    return {
        "terminal_model_error": dict(info),
        "error": str(info.get("user_message") or exc),
        "status": "failed",
    }
