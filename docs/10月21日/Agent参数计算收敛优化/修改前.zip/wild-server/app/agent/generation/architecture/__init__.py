"""总体建筑方案、确定性骨架与立面约束的公开 API。"""

from .facade import (
    conform_balconies_to_slots,
    conform_entrance_accessories,
    conform_openings_to_slots,
    conform_railings_to_slots,
    conform_roofs_to_slots,
    resolve_facade_layout,
)
from .planning import (
    normalize_architecture_plan,
)
from .profile import (
    is_architecture_request,
    resolve_complexity_profile,
)
from .skeleton import build_deterministic_skeleton, evaluate_skeleton_complexity
from .target_kind import TargetKind, detect_target_kind

__all__ = [
    "build_deterministic_skeleton",
    "conform_balconies_to_slots",
    "conform_entrance_accessories",
    "conform_openings_to_slots",
    "conform_railings_to_slots",
    "conform_roofs_to_slots",
    "detect_target_kind",
    "evaluate_skeleton_complexity",
    "is_architecture_request",
    "normalize_architecture_plan",
    "resolve_complexity_profile",
    "resolve_facade_layout",
    "TargetKind",
]
