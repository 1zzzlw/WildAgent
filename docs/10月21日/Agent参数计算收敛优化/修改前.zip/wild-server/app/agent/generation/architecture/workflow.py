"""建筑节点形成设计图纸；实现与 WILD 校验由 plan 负责。"""

from __future__ import annotations

import time as _time
import asyncio
import json

from pydantic import ValidationError

from app.agent.generation.architecture import resolve_complexity_profile
from app.agent.generation.architecture.design_workflow import draft_design
from app.agent.state import GenerationState
from app.agent.prompts import build_architecture_plan_prompt
from app.agent.runtime import get_reasoning_callback


class DesignContractError(RuntimeError):
    """设计方案不满足 DesignDocument 业务不变量时抛出的可读业务错误。"""


def _coordinate_reasons(conflicts: list[dict], context: dict | None = None) -> list[str]:
    messages = []
    for conflict in conflicts:
        path = conflict.get("conflict_path", conflict["path"]).removeprefix(
            "/decisions"
        )
        if "actual_extent" in conflict:
            messages.append(
                f"{path}：全部体量的包络为 {conflict['actual_extent']:g} 米，"
                f"当前总体尺寸为 {conflict['conflict_value']:g} 米。"
                "若该尺寸是用户硬要求，应修订体量布局；否则显式修订总体尺寸，保留未受影响的设计。"
            )
        else:
            messages.append(f"{path}：{conflict['reason']}")
    if context:
        messages.append("当前关系上下文：" + json.dumps(context, ensure_ascii=False))
    return messages


def _validation_reason(exc: Exception) -> str:
    """保留字段路径与全部契约错误，供模型定向修订。"""

    if isinstance(exc, KeyError):
        return f"/{exc.args[0]}：缺少必填字段"
    if getattr(exc, "conflicts", None):
        return "；".join(_coordinate_reasons(exc.conflicts, getattr(exc, "context", None)))
    errors = getattr(exc, "errors", None)
    if callable(errors):
        messages = []
        for item in errors():
            conflicts = getattr((item.get("ctx") or {}).get("error"), "conflicts", None)
            if conflicts:
                messages.extend(_coordinate_reasons(conflicts, getattr((item.get("ctx") or {}).get("error"), "context", None)))
                continue
            message = str(item.get("msg") or "").removeprefix("Value error, ").strip()
            if item.get("type") == "missing":
                message = "缺少必填字段"
            if message:
                parts = list(item.get("loc", ()))
                if (
                    len(parts) >= 4
                    and parts[0] == "components"
                    and parts[2] == "size"
                    and parts[-1] == "[key]"
                ):
                    parts.pop()
                path = "/" + "/".join(
                    str(part).replace("~", "~0").replace("/", "~1") for part in parts
                )
                if path.startswith("/roof/volumes/"):
                    message += '；数组项应写对象，例如 {"volume": "体量ID", "type": "自拟屋型"}，引用字段名为 volume'
                if path.startswith("/components/") and "/size/" in path:
                    from app.design.contracts import ComponentPlacement

                    field = str(parts[-1])
                    if field in ComponentPlacement.model_fields:
                        message = f"{field} 是位置参数，应保留原值写在 placement.{field}；sill_height、offset、normal_offset 可以为 0"
                    else:
                        message = f"尺寸必须是有限正数，实际 {item.get('input')!r}"
                if path.startswith("/components/") and path.endswith("/placement/face"):
                    message = (
                        f"face 仅表示 front/back/left/right 四个竖向立面，实际 {item.get('input')!r}；"
                        "台基、屋顶、檐底等非立面定位用 placement.position=[x,y,z] 写世界中心坐标，朝向说明写在 form/description"
                    )
                if path.startswith("/components/") and any(
                    path.endswith("/placement/" + field)
                    for field in ("offset", "sill_height", "normal_offset")
                ):
                    field = str(parts[-1])
                    message = (
                        f"{field} 必须是单个有限数字，实际 {item.get('input')!r}；"
                        "offset 是沿墙距离，不是三维向量或 x/y/z 对象。"
                        "世界坐标写 placement.position=[x,y,z]；已有 position 时，未使用的沿墙参数直接省略，不能填 null"
                    )
                if path.startswith("/components/") and path.endswith("/host"):
                    message = (
                        f"host 应为宿主 ID 字符串或 null，实际 {item.get('input')!r}；"
                        "无宿主可省略或写 null/空字符串；位置写 placement，不能把对象、数组或数值填入 host"
                    )
                messages.append(f"{path}：{message}")
        if messages:
            return "；".join(dict.fromkeys(messages))
    return " ".join(str(exc).split())


def _material_role_conflicts(components):
    import re

    families = {
        "wood": r"木|\b(?:wood|timber)\b",
        "stone": r"石|\b(?:stone|marble|granite)\b",
        "metal": r"金属|钢|铝|\b(?:metal|steel|aluminum|aluminium)\b",
        "concrete": r"混凝土|\bconcrete\b",
        "brick": r"砖|\bbrick\b",
        "glass": r"玻璃|\bglass\b",
        "fabric": r"织物|布料|\b(?:fabric|cloth)\b",
    }
    groups = {}
    for item in components:
        role, form = item.get("material_role"), item.get("form")
        material = form.get("material") if isinstance(form, dict) else None
        if (
            isinstance(role, str)
            and role
            and isinstance(material, str)
            and material.strip()
        ):
            matches = [
                name
                for name, pattern in families.items()
                if re.search(pattern, material, re.I)
            ]
            # 只拦截能明确区分的材料类别；同类描述、未知或复合材料不靠字符串差异判为冲突。
            if len(matches) == 1:
                groups.setdefault(role, {}).setdefault(matches[0], set()).add(
                    material.strip()
                )
    errors = []
    for role, materials in groups.items():
        if len(materials) > 1:
            errors.append(
                f"/components：material_role={role!r} 同时引用明确不同的材料类别 {sorted(materials)}，"
                f"材料描述 {sorted(name for names in materials.values() for name in names)}；"
                "同一角色只绑定一种实际材质。若这些名称指同一材质，请统一 form.material 名称；"
                "若材料不同，分别选择已有匹配角色或省略不合适的 material_role，由构件实现独立材质。"
                "不能仅在文字中保留木、石而仍共用一个角色"
            )
    return errors


def build_design_document_or_error(
    plan: dict,
    *,
    session_id: str,
    source_request: str,
    building_type: str,
    style_intent: list[str],
    previous: object,
    revision_feedback: str = "",
):
    """
    构造设计契约；不满足业务不变量时抛 `DesignContractError`。

    未捕获的 Pydantic 异常会直接终止整轮生成，用户只看到一条 ValidationError。
    这里把它转成受控业务错误，让节点能给出明确原因并走正常失败分支。
    """

    from app.design.resolver import build_design_document
    from app.design.contracts import MassingDecision, VolumeDecision
    from app.design.coordinates import volume_conflicts

    try:
        return build_design_document(
            plan,
            session_id=session_id,
            source_request=source_request,
            building_type=building_type,
            style_intent=style_intent,
            previous=previous,
            revision_feedback=revision_feedback,
        )
    except (ValidationError, ValueError, KeyError) as exc:
        reasons = [_validation_reason(exc)]
        if isinstance(plan.get("massing"), dict) and isinstance(
            plan.get("volumes"), list
        ):
            try:
                massing = MassingDecision.model_validate(plan["massing"])
                volumes = [
                    VolumeDecision.model_validate(item) for item in plan["volumes"]
                ]
            except ValidationError:
                pass
            else:
                conflicts = volume_conflicts(
                    [v.model_dump(mode="json") for v in volumes],
                    massing.model_dump(mode="json"),
                )
                reasons.extend(
                    reason
                    for reason in _coordinate_reasons(conflicts)
                    if reason not in reasons[0]
                )
        raise DesignContractError("；".join(reasons)) from exc


async def architecture_planner(state: GenerationState) -> dict:
    """一次完整设计，契约失败时局部修订；不通过则保留原因，不降级成默认建筑。"""
    from app.design.resolver import resolve_design
    from app.design.resolver import architecture_plan_from_document
    from app.llm.errors import model_failure_result
    from app.agent.generation.material.plan import material_mentions

    started = _time.time()
    message = state["user_message"]
    feedback = str(state.get("design_feedback") or "").strip()
    previous = state.get("design_document")
    # 解析上轮设计图纸，或从 state 里取 architecture_plan 作为上轮设计方案。
    if isinstance(previous, dict):
        from app.design.contracts import DesignDocument

        previous_plan = architecture_plan_from_document(
            DesignDocument.model_validate(previous)
        )
    else:
        previous_plan = state.get("architecture_plan")

    # 使用 State 中已确定的设计粒度生成复杂度配置。
    complexity = resolve_complexity_profile(state["detail_level"])
    profile_id = (previous_plan or {}).get("profile") or state["intent_profile"]

    callback = get_reasoning_callback()
    if callback:
        await callback("architecture:progress", "正在形成完整建筑图纸与构件标记……\n")

    from app.services.agent_service import agent_service
    from app.spec.loader import SpecQuery

    detail_rule_entity = f"architecture_detail_{complexity['level']}"
    detail_query = SpecQuery(
        f"建筑设计粒度 {complexity['level']} 交付范围 允许省略 完成条件 {complexity['reason']}",
        {"entity_name": detail_rule_entity},
    )
    process_query = SpecQuery(
        "建筑设计步骤与关系复核 需求形制 体量标高 功能交通 围护开口 屋面附属 材料搭配 字段落地",
        {"entity_name": "architecture_design_process"},
    )
    rag_started = _time.time()
    spec_result = await asyncio.to_thread(
        agent_service.spec_loader.load_many_result,
        [
            detail_query,
            process_query,
            SpecQuery(
                f"{message} {feedback} 建筑设计表达 体量围护 开敞 门窗宿主 平面布局",
                {"entity_name": "architecture_design_expression"},
            ),
            SpecQuery(
                f"{message} {feedback} 室内房间 内墙 内门 通行路径 独立柱位 平面图纸",
                {"entity_name": "architecture_design_expression"},
            ),
            SpecQuery(
                f"{message} {profile_id} {feedback} 建筑形制 形态表达 空间组织 构件组合",
                {"doc_type": "component", "topic": "composition"},
            ),
        ],
        per_query=2,
        include_base=False,
    )
    spec_text = spec_result.text
    detail_rule_hits = [
        hit.id for hit in spec_result.hits
        if hit.metadata.get("entity_name") == detail_rule_entity
    ]
    design_process_hits = [
        hit.id for hit in spec_result.hits
        if hit.metadata.get("entity_name") == "architecture_design_process"
    ]
    rag_ms = int((_time.time() - rag_started) * 1000)
    prompt = build_architecture_plan_prompt(
        spec_text,
        profile_id,
        complexity,
        current_plan=previous_plan,
        revision_feedback=feedback,
        style_preference=state.get("style_preference"),
    )
    accepted = {}

    # 在 draft_design 内部做了契约验证，失败时抛 DesignContractError；这里捕获它并返回可读错误。
    def validate(raw):
        massing = raw.get("massing") if isinstance(raw.get("massing"), dict) else {}
        missing = [
            f"/massing/{key}"
            for key in ("shape", "width", "depth", "floors")
            if massing.get(key) is None
        ]
        if not isinstance(raw.get("volumes"), list) or not raw["volumes"]:
            missing.append("/volumes")
        else:
            missing.extend(
                f"/volumes/{index}/{key}"
                for index, volume in enumerate(raw["volumes"])
                for key in (
                    "id",
                    "x",
                    "z",
                    "width",
                    "depth",
                    "start_floor",
                    "end_floor",
                )
                if not isinstance(volume, dict) or volume.get(key) is None
            )
        facades = raw.get("facades") if isinstance(raw.get("facades"), dict) else {}
        missing.extend(
            f"/facades/{face}/{key}"
            for face in ("front", "back", "left", "right")
            for key in ("bays", "ground_pattern", "upper_pattern")
            if not isinstance(facades.get(face), dict) or facades[face].get(key) is None
        )
        if not isinstance(raw.get("roof"), dict) or not raw["roof"].get("type"):
            missing.append("/roof/type")
        if missing:
            raise ValueError(
                "图纸缺少关键设计字段：" + "、".join(missing) + "；请按本次建筑设计补全"
            )
        components = raw.get("components") or []
        if not isinstance(components, list) or any(
            not isinstance(item, dict) for item in components
        ):
            raise ValueError("components 必须是构件对象数组")
        if any(not item.get("id") for item in raw.get("components") or []):
            raise ValueError("每个显式构件标记必须有稳定 id；不能只写构件类型与宿主")
        from app.agent.knowledge.component_names import resolve_component_name

        volume_ids = {
            v.get("id") for v in raw.get("volumes", []) if isinstance(v, dict)
        }
        for index, item in enumerate(components):
            placement = item.get("placement") or {}
            if (
                resolve_component_name(item.get("type", ""))["entity_type"]
                in {"door", "window"}
                and isinstance(item.get("host"), str)
                and item.get("host") in volume_ids
                and isinstance(placement, dict)
                and not placement.get("position")
                and (not placement.get("face") or not placement.get("floor"))
            ):
                raise ValueError(
                    f"/components/{index}/placement：体量内门窗的沿墙定位需要 face 和 floor，"
                    "或写出世界 position；不能仅凭 offset 猜测墙面和楼层"
                )
        material_errors = _material_role_conflicts(components)
        plan = {
            "profile": profile_id,
            **raw,
            "complexity": {
                **complexity,
                **(raw.get("complexity") or {}),
                "level": complexity["level"],
                "reason": complexity["reason"],
            },
        }
        try:
            document = build_design_document_or_error(
                plan,
                session_id=str(
                    state.get("session_id") or state.get("request_id") or "unknown"
                ),
                source_request=message,
                building_type=profile_id,
                style_intent=list(state.get("style_preference") or []),
                previous=previous,
                revision_feedback=feedback,
            )
        except DesignContractError as exc:
            raise ValueError("；".join([*material_errors, str(exc)])) from exc
        from app.design.coordinates import (
            stair_span_conflicts,
            roof_span_conflicts,
            component_dimension_conflicts,
        )
        from app.design.markers import component_markers

        data = document.decisions.model_dump(mode="json")
        coordinate_errors = (
            material_errors
            + component_dimension_conflicts(data)
            + stair_span_conflicts(data)
            + roof_span_conflicts(component_markers(document))
        )
        try:
            resolved = resolve_design(document)
        except ValueError as exc:
            coordinate_errors.append(_validation_reason(exc))
        if coordinate_errors:
            raise ValueError("；".join(coordinate_errors))
        accepted.update(document=document, resolved=resolved)

    repair_rag_ms = repair_rag_chars = 0

    async def load_repair_rules(issue):
        nonlocal repair_rag_ms, repair_rag_chars
        started = _time.time()
        rules = await asyncio.to_thread(
            agent_service.spec_loader.load_many,
            [
                detail_query,
                process_query,
                SpecQuery(
                    "建筑图纸字段与关系修订 " + issue,
                    {"entity_name": "architecture_design_expression"},
                ),
            ],
            per_query=2,
            include_base=False,
        )
        repair_rag_ms += int((_time.time() - started) * 1000)
        repair_rag_chars += len(rules)
        return rules

    accounting = {"model_calls": 0}
    try:
        raw, diag = await draft_design(
            base_prompt=prompt,
            user_request=message + ("\n本轮修改意见：" + feedback if feedback else ""),
            thinking_mode=state.get("thinking_mode") is not False,
            on_reasoning_delta=callback,
            current_plan=previous_plan if feedback else None,
            validate=validate,
            load_repair_rules=load_repair_rules,
            call_accounting=accounting,
        )
    except DesignContractError as exc:
        return {"status": "failed", "error": str(exc)}
    except Exception as exc:
        return {
            **model_failure_result(exc),
            "architecture_diag": {
                "model_calls": accounting["model_calls"],
                "last_issue": str(exc),
                "total_ms": int((_time.time() - started) * 1000),
                "settled": False,
            },
        }
    diag.update(
        rag_chars=len(spec_text),
        rag_ms=rag_ms,
        repair_rag_ms=repair_rag_ms,
        repair_rag_chars=repair_rag_chars,
        detail_level=complexity["level"],
        detail_rule_entity=detail_rule_entity,
        detail_rule_hits=detail_rule_hits,
        design_process_hits=design_process_hits,
        total_ms=int((_time.time() - started) * 1000),
        profile=profile_id,
        raw_plan=raw,
    )
    if not raw:
        return {
            "status": "failed",
            "error": "建筑图纸未通过检查：" + diag["last_issue"],
            "architecture_diag": diag,
        }
    document = accepted["document"]
    prior_strategy = (
        (previous or {}).get("decisions", {}).get("design_intent") or {}
    ).get("material_strategy")
    strategy = (
        document.decisions.design_intent.material_strategy
        if document.decisions.design_intent
        else ""
    )
    return {
        "architecture_plan": architecture_plan_from_document(document),
        "design_document": document.model_dump(mode="json"),
        "resolved_design": accepted["resolved"].model_dump(mode="json"),
        "design_review_status": "pending",
        "design_feedback": "",
        "design_material_refresh": not previous
        or prior_strategy != strategy
        or bool(material_mentions(feedback)),
        "architecture_diag": diag,
        "component_fragments": {
            k: [] for k in (state.get("component_fragments") or {})
        },
        "component_diagnostics": {
            k: {} for k in (state.get("component_diagnostics") or {})
        },
        "merged_blueprint": {},
        "final_blueprint": {},
        "validation_snapshot": {},
        "repair_audit": {},
        "compile_report": {},
        "error": None,
    }
