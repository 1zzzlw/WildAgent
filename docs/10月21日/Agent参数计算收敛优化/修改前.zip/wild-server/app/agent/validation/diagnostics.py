"""稳定的诊断与校验快照 Schema。

- ``blueprint_fingerprint``：Blueprint 内容指纹，供校验结果按内容复用。
- ``ValidationSnapshot``：一次权威校验的结果快照（含设计约束、结构化问题、耗时与来源）。
- ``NodeDiagnostic``：节点级诊断的目标 Schema，保留 ``extra`` 承载节点特有字段以兼容前端。

快照同时记录产物、设计版本、设计清单与校验器版本。最终门禁仍独立运行完整验收，
不以合并或 callback 的旧结论替代当前内容检查。
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from typing import Any

# 空间图纸与通路验收升级后，不复用旧判据的快照。
VALIDATOR_VERSION = "1.1"


def blueprint_fingerprint(blueprint: dict | None) -> str:
    """Blueprint 内容指纹（稳定、键序无关）。"""
    if blueprint is None:
        return "none"
    payload = json.dumps(
        blueprint, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def step_result_to_dict(result: Any) -> dict:
    """把 ``PipelineStepResult``（或同构 dict）序列化为可存盘的 dict。"""
    get = (
        result.get
        if isinstance(result, dict)
        else lambda key, default=None: getattr(result, key, default)
    )
    row = {
        "step": get("step"),
        "name": get("name", "unknown"),
        "output": get("output", ""),
        "has_error": bool(get("has_error", False)),
        "has_warning": bool(get("has_warning", False)),
    }
    if get("issues"):
        row["issues"] = get("issues")
    return row


@dataclass
class NodeDiagnostic:
    """节点级诊断的稳定字段；``extra`` 承载节点特有字段，保证前端兼容。"""

    node: str = ""
    label: str = ""
    stage: str = "done"  # done | error | skipped
    rag_chars: int = 0
    rag_ms: int = 0
    rag_hits: list = field(default_factory=list)
    llm_chars: int = 0
    llm_ms: int = 0
    reasoning_chars: int = 0
    token_usage: dict | None = None
    total_ms: int = 0
    error: str | None = None
    extra: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        """输出与既有 ``*_diag`` 字典同构的扁平字典，避免破坏前端消费。"""
        data = {key: value for key, value in asdict(self).items() if key != "extra"}
        data.update(self.extra)
        return data


@dataclass
class ValidationSnapshot:
    """一次完整验收的快照；证据绑定产物和设计上下文。"""

    blueprint_fingerprint: str = ""
    validator_version: str = VALIDATOR_VERSION
    design_hash: str = ""
    design_revision: int | None = None
    design_brief_fingerprint: str = ""
    status: str = "complete"  # complete | partial | failed
    results: list = field(default_factory=list)  # PipelineStepResult
    design_errors: list = field(default_factory=list)
    issues: list = field(default_factory=list)  # 结构化 ValidationIssue
    #:  P4 设计履约报告：**与几何校验分开记录**，不进 ``results``。
    #: 几何门禁决定"能不能保存"，履约报告决定"用户要的东西兑现了没有"——
    #: 两者混在一起会让"合法但不完整"变成"不许保存"。
    fulfillment: dict | None = None
    spatial_review: dict | None = None
    error_count: int = 0
    warning_count: int = 0
    elapsed_ms: int = 0
    source: str = ""  # merge | final_validate | callback

    def matches(
        self,
        blueprint: dict | None,
        *,
        design_hash: str = "",
        design_revision: int | None = None,
        design_brief: dict | None = None,
    ) -> bool:
        """全部上下文一致才匹配；带设计的旧快照不能按单一产物指纹复用。"""
        return (
            self.blueprint_fingerprint == blueprint_fingerprint(blueprint)
            and self.validator_version == VALIDATOR_VERSION
            and self.design_hash == design_hash
            and self.design_revision == design_revision
            and self.design_brief_fingerprint
            in ("", blueprint_fingerprint(design_brief))
        )
