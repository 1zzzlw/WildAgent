"""离线视觉审核入口：只输出版本化证据与草稿，不覆盖会话或已批准设计。"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import subprocess

from app.design.contracts import DesignDocument
from app.design.resolver import _stable_hash
from app.agent.validation.diagnostics import blueprint_fingerprint
from .evaluation import human_review_template, proxy_evaluate, validated_review


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def load_review_source(document, blueprint_path, snapshot_path=None):
    raw = blueprint_path.read_bytes()
    blueprint = json.loads(raw.decode("utf-8-sig"))
    binding = {"design_hash": _stable_hash(document), "blueprint_fingerprint": blueprint_fingerprint(blueprint),
               "input_sha256": hashlib.sha256(raw).hexdigest(), "source_file": str(blueprint_path.resolve()),
               "design_binding": "not_supplied"}
    if snapshot_path:
        snapshot = json.loads(snapshot_path.read_text(encoding="utf-8-sig"))
        if (snapshot.get("blueprint_fingerprint") != binding["blueprint_fingerprint"]
                or snapshot.get("design_hash") != binding["design_hash"]):
            raise ValueError("验收快照与当前图纸或实际 WILD 不一致")
        binding["design_binding"] = "matched_snapshot"
    return raw, blueprint, binding


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("document", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--blueprint", type=Path, required=True, help="本次实际装配交付的 WILD；不从图纸重新生成替代文件")
    parser.add_argument("--snapshot", type=Path, help="可选：本次 validation_snapshot JSON，用于核对设计与产物绑定")
    parser.add_argument("--review", type=Path, help="填写过的 human_review.json；保存绑定截图的设计修订请求")
    parser.add_argument("--chromium", help="Chromium 可执行文件；也可设置 CHROMIUM_PATH")
    args = parser.parse_args()
    document = DesignDocument.model_validate(json.loads(args.document.read_text(encoding="utf-8-sig")))
    if document.decisions.kind != "architecture":
        parser.error("当前视觉修订仅支持建筑设计")
    # 一个命令一次运行，绝不覆盖上一轮截图、意见与候选。
    args.output.mkdir(parents=True, exist_ok=True)
    import tempfile
    run_dir = Path(tempfile.mkdtemp(prefix="review-", dir=args.output.resolve()))
    script = Path(__file__).resolve().parents[4] / "wild-web/scripts/render-baseline.mjs"
    raw_blueprint, final_blueprint, binding = load_review_source(document, args.blueprint, args.snapshot)
    write_json(run_dir / "document.json", document.model_dump(mode="json"))
    write_json(run_dir / "source.json", binding)
    renders: dict[str, dict] = {}

    def render(blueprint: dict) -> dict:
        content = raw_blueprint if blueprint is final_blueprint else json.dumps(blueprint, ensure_ascii=False, indent=2).encode("utf-8")
        digest = hashlib.sha256(content).hexdigest()
        if digest in renders:
            return renders[digest]
        target = run_dir / digest[:16]
        target.mkdir()
        blueprint_path = target / "blueprint.json"
        blueprint_path.write_bytes(content)
        command = ["node", str(script), str(blueprint_path), str(target)]
        if args.chromium:
            command.append(args.chromium)
        result = subprocess.run(command, cwd=script.parent.parent, capture_output=True,
                                text=True, encoding="utf-8", errors="replace", timeout=90)
        (target / "render.log").write_text(result.stdout + result.stderr, encoding="utf-8")
        if result.returncode:
            raise RuntimeError(f"真实渲染失败，见 {target / 'render.log'}")
        manifest = json.loads((target / "render_manifest.json").read_text(encoding="utf-8"))
        if manifest.get("inputSha256") != digest:
            raise ValueError("渲染证据与传入 WILD 字节指纹不一致")
        renders[digest] = manifest
        write_json(target / "human_review.json", human_review_template(manifest, {
            "sourceRequest": document.requirements.source_request,
            "designId": document.design_id, "blueprintFile": str(blueprint_path),
        }))
        return manifest

    manifest = render(final_blueprint)
    write_json(run_dir / "proxy.json", proxy_evaluate(final_blueprint, document.model_dump(mode="json")))
    if args.review:
        from .revision import build_vision_evidence, recorded_only
        supplied = json.loads(args.review.read_text(encoding="utf-8-sig"))
        baseline = validated_review(supplied, manifest)
        if not baseline.get("complete"):
            raise ValueError("人工评价未完成或与当前蓝图/渲染版本不匹配；请填写本轮生成的模板")

        write_json(run_dir / "review.json", baseline)
        write_json(run_dir / "revision_request.json", {**binding, "status": "design_revision_requested",
            "evidence": build_vision_evidence(baseline), "recorded_only": recorded_only(baseline),
            "next_step": "通过现有设计修订与审核入口修改图纸，再执行受影响标记、装配和验收；新产物重新渲染。"})
    print(str(run_dir))


if __name__ == "__main__":
    main()
