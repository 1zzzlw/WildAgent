"""建筑计划从图纸标记展开，尝试实现构件后统一装配和校验。"""

from __future__ import annotations

import asyncio
import inspect
import time
from typing import Any

from loguru import logger

from app.agent.plan.contracts import PlanDocument, PlanItem
from app.agent.plan.expand import expand_plan
from app.agent.plan.handlers import HANDLERS
from app.agent.plan.reconcile import ensure_artifact_consistency, reconcile
from app.agent.plan.replan import (
    MAX_NO_PROGRESS_ROUNDS,
    plan_needs_replan,
    prepare_finalization,
    request_replan,
    replan,
)
from app.agent.plan.store import (
    mark_running,
    poll_runnable,
    record_result,
    refresh_statuses,
    terminal_stats,
)
from app.agent.plan.strategy import request_plan_strategy
from app.agent.runtime import get_reasoning_callback, bind_reasoning_callback, reset_reasoning_callback

#: 哪些 op 的处理器会真的调模型（用于 §5.4 的模型调用预算统计）。
_MODEL_OPS: frozenset[str] = frozenset({"generate", "repair"})
_MAX_PARALLEL_ITEMS = 3


def _model_tool_rounds(trace: Any) -> int:
    """只数**模型自己发起**的工具轮次。

    预取检索与确定性校验也会进审计轨迹（它们带 ``mode`` 字段），但那些不产生模型
    调用；把它们也算进预算会让"检索充足"的请求提前触发预算终止。
    """

    return len(
        [entry for entry in trace or [] if isinstance(entry, dict) and not entry.get("mode")]
    )


def _plan_of(state: dict[str, Any]) -> PlanDocument:
    return PlanDocument.model_validate(state.get("plan") or {})


def _events_for(plan: PlanDocument) -> list[dict[str, Any]]:
    return [
        {
            "item_id": item.id,
            "label": item.label,
            "op": item.op,
            "kind": item.kind,
            "status": item.status,
            "evidence": item.run.evidence,
            "elapsed_ms": item.run.elapsed_ms,
        }
        for item in plan.items
    ]


def _runnable_batch(plan: PlanDocument) -> list[PlanItem]:
    """返回本轮可安全并发的生成条目；否则只返回声明顺序中的第一条。"""

    first = poll_runnable(plan)
    if first is None:
        return []
    group = str(first.params.get("parallel_group") or "")
    if (
        first.op != "generate"
        or first.params.get("execution_mode") != "parallel"
        or not group
    ):
        return [first]
    selected = [
        item
        for item in plan.items
        if item.status == "ready"
        and item.run.state != "succeeded"
        and item.op == "generate"
        and item.params.get("execution_mode") == "parallel"
        and item.params.get("parallel_group") == group
    ]
    return selected[:_MAX_PARALLEL_ITEMS] or [first]


def _merge_parallel_updates(results: list[dict[str, Any]]) -> dict[str, Any]:
    """合并互不依赖生成批次的局部 state 更新。"""

    merged: dict[str, Any] = {}
    for updates in results:
        for key, value in updates.items():
            if key in {"component_fragments", "component_diagnostics"}:
                current = merged.setdefault(key, {})
                if isinstance(current, dict) and isinstance(value, dict):
                    current.update(value)
            elif key not in merged:
                merged[key] = value
    return merged


async def _execute_one(state: dict[str, Any], item: PlanItem):
    handler = HANDLERS.get(item.op)
    handler_started = time.perf_counter()
    callback = get_reasoning_callback()
    async def item_callback(node, delta):
        channel = ":progress" if node.endswith(":progress") else ""
        await callback(f"plan:{item.id}{channel}", delta)
    token = bind_reasoning_callback(item_callback if callback else None)
    try:
        if callback:
            await item_callback("execute:progress", f"正在执行{item.label}……\n")
        if handler is None:
            outcome = ({}, "failed", [], f"op {item.op!r} 没有执行器（见 §2.3 闭集）", [])
        else:
            outcome = handler(state, item)
            if inspect.isawaitable(outcome):
                outcome = await outcome
        updates, run_state, artifacts, evidence, trace = outcome
    except Exception as exc:
        logger.error(f"[execute] {item.id} 执行异常: {exc}")
        updates, run_state, artifacts, evidence, trace = (
            {}, "failed", [], f"执行异常: {exc}", []
        )
    finally:
        reset_reasoning_callback(token)
    return (
        item,
        updates,
        run_state,
        artifacts,
        evidence,
        trace,
        int((time.perf_counter() - handler_started) * 1000),
    )


async def plan_node(state: dict[str, Any]) -> dict[str, Any]:
    """建筑按批准图纸展开任务；物件保留模型分组策略。"""

    started = time.time()

    # 取当前运行时的 "思考回调"。
    callback = get_reasoning_callback()
    
    if callback:
        # 必须带 `:progress` 后缀走「执行说明」通道。
        await callback("plan:progress", "正在把已批准方案拆成可执行的工作条目……\n")

    document_data = state.get("design_document") or {}
    if document_data.get("decisions", {}).get("kind") == "architecture":
        from app.design.contracts import DesignDocument
        from app.design.compilation import project_drawing, RESOLVER_VERSION
        document = DesignDocument.model_validate(document_data)
        resolved = project_drawing(document)
        reviewed = state.get("resolved_design") or {}
        if reviewed.get("resolver_version") != RESOLVER_VERSION or reviewed.get("design_hash") != resolved.design_hash:
            return {"resolved_design": resolved.model_dump(mode="json"), "design_review_status": "pending",
                    "component_fragments": {k: [] for k in (state.get("component_fragments") or {})},
                    "component_diagnostics": {k: {} for k in (state.get("component_diagnostics") or {})},
                    "merged_blueprint": {}, "final_blueprint": {}, "validation_snapshot": {}}
        design_state = {**state, "resolved_design": resolved.model_dump(mode="json")}
        plan = expand_plan(design_state)
        material_plan = document.decisions.materials.resolved_plan
        scaffold = {"meta": {"version": "1.0", "type": "building", "name": document.decisions.concept or "建筑",
                             "designHash": resolved.design_hash, "designRevision": document.revision},
                    "geometry": {"elements": [], "components": []}, "materials": {}, "assets": {}}
        if material_plan:
            scaffold["materials"] = {r.materialId: dict(r.material) for r in material_plan.roles}
            scaffold["assets"] = dict(material_plan.resolvedAssets)
        for name, definition in document.decisions.materials.definitions.items():
            material = definition.model_dump(mode="json")
            if name in scaffold["materials"] and scaffold["materials"][name] != material:
                raise ValueError(f"设计命名材质 {name} 与角色解析材质重名且定义不同；请显式修订命名")
            scaffold["materials"][name] = material
        return {"plan": plan.model_dump(mode="json"), "plan_events": _events_for(plan),
                "resolved_design": resolved.model_dump(mode="json"), "drawing_hosts": resolved.projection_elements,
                "skeleton_blueprint": scaffold, "design_brief": {}, "merged_blueprint": {}, "current_item_id": None,
                "plan_diag": {"source": "drawing_implementation", "model_calls": 0,
                              "marker_count": len(resolved.component_markers), "total_ms": int((time.time()-started)*1000)}}

    strategy, diag = await request_plan_strategy(state)

    # 如果 diag 里带了 terminal_model_error（说明模型服务调不通，是故障不是输出差），直接终止整轮
    if isinstance(diag.get("terminal_model_error"), dict):
        logger.warning("[plan] 策略模型不可用，终止本轮生成")
        return {
            "plan_diag": {**diag, "total_ms": int((time.time() - started) * 1000)},
            "terminal_model_error": diag["terminal_model_error"],
            "error": diag["terminal_model_error"].get("user_message")
            or diag.get("error")
            or "模型服务不可用",
            "status": "failed",
        }

    # 1. 把策略确定性展开成条目列表（PlanDocument） 2. 给计划累加 1 次模型调用计数
    plan = expand_plan(state, strategy=strategy).add_llm_calls(1)

    # 看这次计划多少条、各终态多少，供日志和播报用
    stats = terminal_stats(plan)

    # 取第一条当前可执行的条目（status=ready 且没成功过）。用来设定 current_item_id 这是 trace 和事件要挂载的 "当前条目"
    first = poll_runnable(plan)
    
    # 策略要的 ≠ 实际派发的：产物里已有的类型会被 ``expand_plan`` 抑制掉。诊断如实记两边，
    # 否则"模型点名了门却没派门"在审计里看不出来。
    dispatched_kinds = sorted({item.kind for item in plan.items if item.op == "generate"})

    logger.info(
        f"[plan] 策略来源 {strategy.source}（要求 {len(strategy.kinds)} 类 → "
        f"派发 {dispatched_kinds}）→ 展开 {stats['total']} 条条目"
        f"（档位 {plan.detail_level}）：{[item.label for item in plan.items[:6]]}"
        + ("..." if stats["total"] > 6 else "")
    )
    
    if callback:
        unsupported = stats["unsupported"]
        # 只播报**真的进了计划**的类型：被抑制的类型播出去等于对用户撒谎。
        planned = [entry for entry in strategy.kinds if entry.kind in set(dispatched_kinds)]
        parallel_groups = {
            entry.parallel_group
            for entry in planned
            if entry.execution_mode == "parallel" and entry.parallel_group
        }
        batch_notes = [
            f"{entry.kind}：{entry.batch_reason}" for entry in planned if entry.batch_reason
        ]
        await callback(
            "plan:progress",
            f"计划已展开：{stats['total']} 条工作条目"
            + (f"，{len(parallel_groups)} 个安全并发组" if parallel_groups else "，其余按依赖串行")
            + (f"，其中 {unsupported} 条因能力缺失标记为不支持" if unsupported else "")
            + "。\n"
            + ("批次依据：" + "；".join(batch_notes) + "。\n" if batch_notes else ""),
        )

    return {
        "plan": plan.model_dump(mode="json"),
        "plan_events": _events_for(plan),
        "plan_diag": {
            **diag,
            "items": stats["total"],
            "dispatched_kinds": dispatched_kinds,
            "terminal_stats": stats,
            "model_calls": 1,
            "total_ms": int((time.time() - started) * 1000),
        },
        "current_item_id": first.id if first is not None else None,
    }


async def execute_node(state: dict[str, Any]) -> dict[str, Any]:
    """执行一条串行任务，或执行一个由 plan 决定的安全并发组。"""

    started = time.time()
    plan = refresh_statuses(_plan_of(state))
    items = _runnable_batch(plan)
    if not items:
        logger.info("[execute] 没有可执行条目，交回 replanner")
        return {
            "current_item_id": None,
            "execute_diag": {"item_id": None, "reason": "无可执行条目"},
        }

    for item in items:
        plan, _running = mark_running(plan, item.id)
    logger.info(
        f"[execute] 本轮 {len(items)} 条："
        + ", ".join(f"{item.id}({item.kind})" for item in items)
    )

    callback = get_reasoning_callback()
    if callback and any(item.op in _MODEL_OPS for item in items):
        if len(items) > 1:
            await callback(
                "execute:progress",
                "正在并发执行批次：" + "、".join(item.label for item in items) + "……\n",
            )
        else:
            await callback("execute:progress", f"正在执行{items[0].label}（{items[0].id}）……\n")

    results = await asyncio.gather(*(_execute_one(state, item) for item in items))
    updates = _merge_parallel_updates([result[1] for result in results])
    tool_trace = dict(state.get("tool_trace") or {})
    item_results = []
    model_calls = 0
    for item, _item_updates, run_state, artifacts, evidence, trace, elapsed_ms in results:
        plan = record_result(
            plan,
            item.id,
            state=run_state,
            artifacts=artifacts,
            evidence=evidence,
            elapsed_ms=elapsed_ms,
            count_attempt=(run_state == "failed"),
        )
        summary = (_item_updates.get("component_diagnostics", {}).get(item.id) or {}).get("implementation_summary")
        if item.params.get("design_markers") and summary:
            plan.item(item.id).params["implementation_summary"] = summary
        calls = (sum(entry.get("model_calls", 0) for entry in trace) if item.params.get("design_markers")
                 else (1 + _model_tool_rounds(trace)) if item.op in _MODEL_OPS else 0)
        model_calls += calls
        tool_trace[item.id] = trace
        item_results.append(
            {
                "item_id": item.id,
                "kind": item.kind,
                "label": item.label,
                "run_state": run_state,
                "elapsed_ms": elapsed_ms,
                "evidence": evidence,
                **({"implementation_summary": summary}
                   if item.params.get("design_markers") else {}),
            }
        )
        logger.info(f"[execute] {item.id} → {run_state}（{elapsed_ms}ms）：{evidence}")
        if callback and item.op in _MODEL_OPS:
            await callback("execute:progress", f"{item.label}：{run_state}（{evidence}）\n")
    plan.add_llm_calls(model_calls)

    first = items[0]
    total_tool_calls = sum(len(result[5]) for result in results)
    run_state = "succeeded" if all(result[2] == "succeeded" for result in results) else "mixed"

    return {
        **updates,
        "plan": plan.model_dump(mode="json"),
        "current_item_id": first.id,
        "tool_trace": tool_trace,
        "execute_diag": {
            "item_id": first.id,
            "item_ids": [item.id for item in items],
            "op": first.op,
            "kind": first.kind,
            "run_state": run_state,
            "elapsed_ms": max(result[6] for result in results),
            "tool_calls": total_tool_calls,
            "model_calls": model_calls,
            "parallel_count": len(items),
            "item_results": item_results,
            "llm_calls_total": plan.llm_calls,
            "total_ms": int((time.time() - started) * 1000),
        },
    }


async def replanner_node(state: dict[str, Any]) -> dict[str, Any]:
    """唯一的循环控制点：先确定性对账，只有异常才调一次模型（§5.1）。"""

    started = time.time()
    plan = _plan_of(state)

    plan, events = reconcile(plan, state)
    # 交付前必须重新对账：配额强制、阳台去重、fix_* 都会删改元素，漂移是静默的。
    plan = ensure_artifact_consistency(plan, state)

    diag: dict[str, Any] = {"reconciled_events": len(events)}

    # ── 异常分支：只有 failed / 永久 blocked 时才调模型，且只能在五个动作里选 ──
    if (not any(i.params.get("design_markers") for i in plan.items)
            and not plan.give_up and plan_needs_replan(plan)):
        callback = get_reasoning_callback()
        problem = next(
            (
                item for item in plan.items
                if not item.is_terminal
                and (
                    item.run.state == "failed"
                    or (
                        item.status == "blocked"
                        and any(plan.item(dep) is None for dep in item.depends_on)
                    )
                )
            ),
            None,
        )
        if callback:
            if problem is not None:
                await callback(
                    "replanner:progress",
                    f"条目 {problem.label or problem.id}（{problem.id}）执行失败 "
                    f"{problem.run.attempts}/{problem.run.max_attempts}："
                    f"{problem.run.evidence or '未提供失败证据'}。正在选择一次有界调整……\n",
                )
            else:
                await callback("replanner:progress", "检测到计划结构异常，正在选择一次有界调整……\n")
        decision, replan_diag = await request_replan(plan, state)
        plan, outcome = replan(plan, state, decision)
        if replan_diag.get("model_called"):
            plan.add_llm_calls(1)
        diag["replan"] = {**replan_diag, "outcome": outcome}
        applied_action = str(outcome.get("action") or decision.action)
        applied_reason = str(outcome.get("reason") or decision.reason)
        logger.info(
            f"[replanner] 决策 {applied_action}（来源 {outcome.get('source') or decision.source}）："
            f"{outcome.get('rejected') or applied_reason}"
        )
        if callback:
            affected = outcome.get("item_ids") or []
            target = "、".join(str(item_id) for item_id in affected) or decision.item_id or "整份计划"
            changes = ", ".join(
                f"{key}={value}" for key, value in decision.params.items()
                if key in {"subtype", "guidance", "reason"}
            )
            detail = (
                outcome.get("rejected")
                or outcome.get("policy_override")
                or applied_reason
                or "未提供原因"
            )
            await callback(
                "replanner:progress",
                f"计划调整：{applied_action}；目标：{target}；依据：{detail}"
                + (f"；变化：{changes}" if changes else "")
                + "。\n",
            )

    signature = plan.progress_signature()
    if signature == plan.last_progress_signature:
        plan.no_progress_rounds += 1
    else:
        plan.no_progress_rounds = 0
    plan.last_progress_signature = signature
    plan.iterations += 1
    plan = refresh_statuses(plan)

    # 到达任一停止条件时，只停止后续模型工作；批次 merge 与收尾 merge 必须继续，
    # 否则 final_validate 没有 merged_blueprint，只会把“有界退出”变成必现异常。
    budget = plan.budget or {}
    finalization_reason = ""
    if plan.give_up:
        finalization_reason = "replanner 已停止继续生成，转入确定性收尾"
    elif plan.iterations >= int(budget.get("iterations", 5)):
        finalization_reason = f"达到计划迭代上限 {plan.iterations}"
    elif plan.no_progress_rounds >= MAX_NO_PROGRESS_ROUNDS and not any(i.params.get("design_markers") for i in plan.items):
        finalization_reason = f"连续 {plan.no_progress_rounds} 轮无业务进展"
    elif plan.llm_budget_exhausted():
        finalization_reason = f"模型调用预算已用尽（{plan.llm_calls} 次）"
    if finalization_reason:
        plan, skipped = prepare_finalization(plan, reason=finalization_reason)
        diag["finalization"] = {
            "reason": finalization_reason,
            "skipped_item_ids": skipped,
            "merge_required": any(
                item.op == "merge" and not item.is_terminal for item in plan.items
            ),
        }

    stats = terminal_stats(plan)
    stats["ended"] = stats["total"] - stats["unfinished"]
    from app.design.markers import implementation_records
    marker_records = implementation_records(state)
    markers = (state.get("resolved_design") or {}).get("component_markers") or []
    implementation_summary = {"implemented": sum(r.get("status") == "implemented" for r in marker_records.values()),
                              "abandoned": sum(r.get("status") == "abandoned" for r in marker_records.values()),
                              "total": len(markers),
                              "design_complete": bool(markers) and all((marker_records.get(m["id"]) or {}).get("status") == "implemented" for m in markers)}
    next_item = poll_runnable(plan)
    logger.info(
        f"[replanner] 第 {plan.iterations}/{budget.get('iterations', '?')} 轮，"
        f"结束 {stats['ended']}/{stats['total']}，全部落实任务 {stats['done']}，待办 {stats['unfinished']}，"
        f"无进展 {plan.no_progress_rounds} 轮，模型调用 {plan.llm_calls}"
        + (f"，下一条 {next_item.id}" if next_item is not None else "，队列已空")
        + ("，已判定 give_up" if plan.give_up else "")
    )

    return {
        "plan": plan.model_dump(mode="json"),
        "plan_events": events,
        "replanner_diag": {
            **diag,
            "iterations": plan.iterations,
            "no_progress_rounds": plan.no_progress_rounds,
            "give_up": plan.give_up,
            "llm_calls_total": plan.llm_calls,
            "llm_budget_exhausted": plan.llm_budget_exhausted(),
            "terminal_stats": stats,
            "implementation_summary": implementation_summary,
            "next_item_id": next_item.id if next_item is not None else None,
            "total_ms": int((time.time() - started) * 1000),
        },
    }


__all__ = ["execute_node", "plan_node", "replanner_node"]
