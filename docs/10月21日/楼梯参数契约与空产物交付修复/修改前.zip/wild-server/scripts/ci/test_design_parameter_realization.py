"""参数计算与确定性实现回归；按用户要求编写，本轮不运行。"""
from copy import deepcopy
from pathlib import Path
import sys
import unittest
from unittest.mock import AsyncMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app.design.contracts import architecture_input_schema
from app.design.compilation import project_drawing
from app.design.coordinates import design_geometry_context
from app.design.realization import realize_marker
from app.design.resolver import build_design_document
from app.agent.plan.implementation import _item_context, implementation_blueprint, run_marker_generate
from app.agent.plan.workflow import plan_node, execute_node, replanner_node
from app.agent.plan.contracts import PlanDocument
from app.agent.plan.store import poll_runnable
from app.agent.design_flow.compile import _assemble_with_relations


def drawing(direction="+z", height=3.6):
    width, depth = (2.4,4) if direction[-1]=="z" else (4,2.4)
    roles = [dict(role=r,materialId=r,material={"baseColor":[0.6,0.6,0.6]})
             for r in ("facade_primary","floor","structure","accent")]
    return {"massing":{"shape":"rectangular","floors":2,"floor_height":height},
        "volumes":[dict(id="main",x=-2,z=1,width=10,depth=9,start_floor=1,end_floor=2)],
        "structural_grid":{"system":"wall_bearing","x_bays":2,"z_bays":2},
        "envelope":{"system":"solid_wall"}, "roof":{"type":"none"},
        "facades":{f:{"ground_pattern":["empty"],"upper_pattern":["empty"]}
                   for f in ("front","back","left","right")},
        "materials":{"resolved_plan":{"roles":roles}},
        "components":[{"id":"stair","type":"stair","placement":{"plan_position":[3,5]},
            "size":{"width":width,"depth":depth},
            "floor_connections":[{"from_floor":1,"to_floor":2}],
            "form":{"shape":"U","flights":2,"span_direction":direction,"flight_width":1.1,
                    "landing_depth":1,"rises":10,"tread_depth":0.3}}]}


def document(raw=None):
    return build_design_document(raw or drawing(),session_id="parameter_fixture",source_request="参数回归")


class ParameterContracts(unittest.TestCase):
    def test_omitted_envelope_and_bays_are_derived_without_mutating_input(self):
        raw=drawing(); before=deepcopy(raw)
        doc=document(raw)
        self.assertEqual(before,raw)
        self.assertEqual((10,9,2),(doc.decisions.massing.width,doc.decisions.massing.depth,doc.decisions.massing.modeled_floors))
        self.assertEqual(1,doc.decisions.facades["front"].bays)
        self.assertTrue(any(c.get("category")=="derived" for t in doc.rule_trace for c in t.changes))

    def test_explicit_envelope_conflict_is_not_overwritten(self):
        raw=drawing(); raw["massing"]["width"]=8
        with self.assertRaises(ValueError): document(raw)
        self.assertEqual(8,raw["massing"]["width"])

    def test_representation_is_computed_only_when_omitted(self):
        raw=drawing()
        raw["massing"].update(floors=4,modeled_floors=2)
        self.assertEqual("schematic",document(raw).decisions.massing.representation_mode)
        raw["massing"]["representation_mode"]="full"
        with self.assertRaises(ValueError): document(raw)

    def test_four_directions_and_level_offsets_share_one_route(self):
        for direction in ("+x","-x","+z","-z"):
            for height,base in ((3.6,0),(3.9,0.4)):
                with self.subTest(direction=direction,height=height,base=base):
                    raw=drawing(direction,height)
                    raw["floor_layouts"]=[{"floor":1,"level":base},{"floor":2,"level":base+height}]
                    doc=document(raw); projected=project_drawing(doc)
                    route=projected.geometry_context["stair_routes"]["stair"]
                    self.assertAlmostEqual(base+height/2,route["position"][1])
                    self.assertAlmostEqual(height/20,route["first_flight"]["stepHeight"])
                    self.assertEqual(route["first_flight"]["to"][1],route["second_flight"]["from"][1])
                    self.assertFalse(any(v[0]<-2 or v[2]>8 for level in projected.geometry_context["levels"]
                                         for v in level["floor_rectangles"]))

    def test_explicit_center_or_riser_conflicts_remain_errors(self):
        for mutation in ("center","riser"):
            with self.subTest(mutation=mutation):
                raw=drawing(); stair=raw["components"][0]
                if mutation=="center": stair["placement"]["position"]=[3,2,5]
                else: stair["form"]["riser_height"]=0.17
                with self.assertRaises(ValueError): project_drawing(document(raw))

    def test_room_and_two_independent_stair_conflicts_are_reported_together(self):
        raw=drawing(height=3.9); stair=raw["components"][0]
        stair["form"].update(rises=11,riser_height=0.177,tread_depth=0.26)
        stair["size"]["depth"]=3
        raw["floor_layouts"]=[{"floor":1,"rooms":[{"bounds":{"x":-2,"z":1,"width":10,"depth":9}}],
                               "walls":[{"id":"partition","from":[0,1],"to":[0,10],"thickness":0.16}]}]
        with self.assertRaises(ValueError) as caught: project_drawing(document(raw))
        message=str(caught.exception)
        for path in ("/floor_layouts/0/rooms/0","/form/riser_height","/components/0/size"):
            self.assertIn(path,message)
        self.assertIn("3.86",message)

    def test_model_schema_omits_program_state_and_keeps_semantic_bounds(self):
        schema=architecture_input_schema()
        self.assertNotIn("complexity",schema["properties"])
        self.assertNotIn("resolved_plan",schema["$defs"]["MaterialIntent"]["properties"])
        self.assertNotIn("width",schema["$defs"]["MassingDecision"]["required"])
        self.assertGreater(schema["$defs"]["MassingDecision"]["properties"]["width"]["exclusiveMinimum"],-1)
        self.assertIn("plan_position",schema["$defs"]["ComponentPlacement"]["properties"])


class ProgramImplementation(unittest.IsolatedAsyncioTestCase):
    async def state(self, raw=None):
        doc=document(raw); projected=project_drawing(doc)
        state={"design_document":doc.model_dump(mode="json"),"resolved_design":projected.model_dump(mode="json"),
               "component_fragments":{},"component_diagnostics":{},"design_review_status":"approved"}
        state.update(await plan_node(state))
        return doc,state

    async def test_supported_tasks_use_real_scheduler_and_no_model_or_retrieval(self):
        raw=drawing()
        raw["components"].append({"id":"slats","type":"assembly","placement":{"position":[1,1.5,2]},
            "repetition":{"count":5,"axis":"x","spacing":0.2,"member_size":[0.05,2,0.1]},
            "material_role":"accent"})
        doc,state=await self.state(raw)
        from config import config
        with patch.object(config.rag,"enabled",False), \
             patch("app.llm.invocation.invoke_llm",new_callable=AsyncMock) as invoke, \
             patch("app.llm.invocation.stream_llm",new_callable=AsyncMock) as stream, \
             patch("app.agent.plan.knowledge_tool.search_knowledge_result",side_effect=AssertionError("unexpected retrieval")):
            while poll_runnable(PlanDocument.model_validate(state["plan"])):
                updates=await execute_node(state)
                for key in ("component_fragments","component_diagnostics"):
                    state[key].update(updates.pop(key,{}))
                state.update(updates)
                self.assertEqual("succeeded",state["execute_diag"]["run_state"])
                state.update(await replanner_node(state))
            blueprint,missing,records=_assemble_with_relations(doc,state)
        invoke.assert_not_awaited(); stream.assert_not_awaited()
        self.assertFalse(missing)
        self.assertEqual({"program"},{r["source"] for r in records.values()})
        self.assertEqual(0,state["plan"]["llm_calls"])
        self.assertTrue(blueprint["geometry"]["elements"])

    async def test_unhandled_detail_preserves_model_route(self):
        _,state=await self.state()
        marker=deepcopy(next(m for m in state["resolved_design"]["component_markers"] if m["id"]=="stair"))
        marker["design"]["form"]["custom_profile"]="selected profile"
        context=_item_context(state,{marker["id"]:marker},implementation_blueprint(state))
        self.assertIsNone(realize_marker(marker,context))

    async def test_native_roof_uses_volume_and_support_geometry(self):
        raw=drawing()
        raw["roof"]={"type":"hip","height":1.2,"thickness":0.16,"overhang":0.4}
        raw["materials"]["resolved_plan"]["roles"].append(
            {"role":"roof","materialId":"roof","material":{"baseColor":[0.2,0.2,0.2]}})
        _,state=await self.state(raw)
        marker=next(m for m in state["resolved_design"]["component_markers"] if m["id"]=="roof_main")
        context=_item_context(state,{marker["id"]:marker},implementation_blueprint(state))
        roof=realize_marker(marker,context)["geometry"]["elements"][0]
        self.assertEqual([3,7.2,5.5],roof["position"])
        self.assertEqual((10.8,9.8,1.2,0.16),(roof["span"],roof["depth"],roof["height"],roof["thickness"]))

    async def test_program_rejection_is_retained_without_model_repair(self):
        _,state=await self.state()
        item=PlanDocument.model_validate(state["plan"]).items[0]
        with patch("app.agent.plan.implementation._accept_group",side_effect=ValueError("fixture rejection")), \
             patch("app.llm.invocation.invoke_llm",new_callable=AsyncMock) as invoke, \
             patch("app.agent.plan.knowledge_tool.search_knowledge_result",side_effect=AssertionError("unexpected retrieval")):
            updates,_,_,_,trace=await run_marker_generate(state,item)
        invoke.assert_not_awaited()
        self.assertEqual("failed",updates["status"])
        self.assertIn("fixture rejection",updates["component_diagnostics"][item.id]["implementations"]["building_body"]["reason"])
        self.assertTrue(any(t.get("error")=="fixture rejection" for t in trace))


if __name__=="__main__":
    unittest.main()
