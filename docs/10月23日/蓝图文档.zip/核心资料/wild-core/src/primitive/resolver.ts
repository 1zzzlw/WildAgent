/**
 * 空间关系解析层
 * 
 * 核心模块。接收展开后的构件列表，自动推导和修正几何坐标，
 * 确保建筑结构在空间上正确连接。
 */

import type { GeometryElement, SpatialIndex, Vec3 } from './types';

export function resolveSpatialRelations(elements: GeometryElement[]): GeometryElement[] {
  const index = buildSpatialIndex(elements);

  resolveWallJoints(elements, index);
  resolveBeamSupports(elements, index);
  resolveRoofBoundary(elements, index);
  resolveFloorRegions(elements, index);
  resolveStairSteps(elements);
  resolveColumnOffsets(elements, index);
  resolveOpenings(elements, index);

  return elements;
}

// ─── 空间索引 ────────────────────────────────
function buildSpatialIndex(elements: GeometryElement[]): SpatialIndex {
  const byId = new Map<string, GeometryElement>();
  const grid = new Map<string, Set<string>>();
  const cellSize = 5.0;

  for (const el of elements) {
    byId.set(el.id, el);
    const cell = getCellForElement(el, cellSize);
    if (!grid.has(cell)) grid.set(cell, new Set());
    grid.get(cell)!.add(el.id);
  }

  return { byId, grid, cellSize };
}

function getCellForElement(el: GeometryElement, cellSize: number): string {
  let x = 0, z = 0;
  switch (el.type) {
    case 'wall': case 'floor': case 'beam': case 'stair':
      x = Math.floor(el.from[0] / cellSize);
      z = Math.floor(el.from[2] / cellSize);
      break;
    case 'column':
      x = Math.floor(el.base[0] / cellSize);
      z = Math.floor(el.base[2] / cellSize);
      break;
    case 'roof': case 'furniture': case 'dense_brick': case 'body': case 'primitive':
      x = Math.floor((el as any).position?.[0] / cellSize) || 0;
      z = Math.floor((el as any).position?.[2] / cellSize) || 0;
      break;
    case 'opening':
      x = Math.floor(el.from[0] / cellSize);
      z = Math.floor(el.from[2] / cellSize);
      break;
    default:
      break;
  }
  return `${x},${z}`;
}

// ─── 墙角连接 ────────────────────────────────
function resolveWallJoints(elements: GeometryElement[], index: SpatialIndex): void {
  const walls = elements.filter(e => e.type === 'wall') as any[];
  for (const wall of walls) {
    delete wall._jointExtensions;
  }
  for (let first = 0; first < walls.length; first++) {
    for (let second = first + 1; second < walls.length; second++) {
      adjustWallJoint(walls[first], walls[second]);
    }
  }
}

type WallEndpoint = 'from' | 'to';

function adjustWallJoint(wall: any, neighbor: any): void {
  if (!haveOverlappingVerticalRanges(wall, neighbor)) return;
  const dFF = distance2D(wall.from, neighbor.from);
  const dFT = distance2D(wall.from, neighbor.to);
  const dTF = distance2D(wall.to, neighbor.from);
  const dTT = distance2D(wall.to, neighbor.to);
  const tolerance = 0.01;

  // 墙角斜接：只合并 XZ，Y 各自保留（fromY 是墙底、toY 是墙顶，不能混用）
  let wallEndpoint: WallEndpoint | undefined;
  let neighborEndpoint: WallEndpoint | undefined;
  if (dFF < tolerance) {
    wallEndpoint = 'from'; neighborEndpoint = 'from';
  } else if (dFT < tolerance) {
    wallEndpoint = 'from'; neighborEndpoint = 'to';
  } else if (dTF < tolerance) {
    wallEndpoint = 'to'; neighborEndpoint = 'from';
  } else if (dTT < tolerance) {
    wallEndpoint = 'to'; neighborEndpoint = 'to';
  }
  if (!wallEndpoint || !neighborEndpoint) return;

  joinXZ(wall[wallEndpoint], neighbor[neighborEndpoint]);
  if (!isNearRightAngle(wall, neighbor)) return;

  extendWallEndpoint(wall, wallEndpoint, Number(neighbor.thickness) / 2);
  extendWallEndpoint(neighbor, neighborEndpoint, Number(wall.thickness) / 2);
}

function haveOverlappingVerticalRanges(wall: any, neighbor: any): boolean {
  const wallBottom = Math.min(wall.from[1], wall.to[1]);
  const wallTop = Math.max(wall.from[1], wall.to[1]);
  const neighborBottom = Math.min(neighbor.from[1], neighbor.to[1]);
  const neighborTop = Math.max(neighbor.from[1], neighbor.to[1]);
  return Math.min(wallTop, neighborTop) - Math.max(wallBottom, neighborBottom) > 0.01;
}

/** 第一阶段只处理直线墙的近似直角端点，避免曲墙和斜角被错误拉长。 */
function isNearRightAngle(wall: any, neighbor: any): boolean {
  if (wall.curve || neighbor.curve) return false;
  const wallDx = wall.to[0] - wall.from[0];
  const wallDz = wall.to[2] - wall.from[2];
  const neighborDx = neighbor.to[0] - neighbor.from[0];
  const neighborDz = neighbor.to[2] - neighbor.from[2];
  const wallLength = Math.hypot(wallDx, wallDz);
  const neighborLength = Math.hypot(neighborDx, neighborDz);
  if (wallLength < 1e-6 || neighborLength < 1e-6) return false;
  const absoluteDot = Math.abs(
    (wallDx * neighborDx + wallDz * neighborDz) / (wallLength * neighborLength),
  );
  return absoluteDot <= Math.sin(5 * Math.PI / 180);
}

function extendWallEndpoint(wall: any, endpoint: WallEndpoint, extension: number): void {
  if (!Number.isFinite(extension) || extension <= 0) return;
  wall._jointExtensions ??= { start: 0, end: 0 };
  const key = endpoint === 'from' ? 'start' : 'end';
  wall._jointExtensions[key] = Math.max(wall._jointExtensions[key], extension);
}

// ─── 梁定位 ────────────────────────────────
function resolveBeamSupports(elements: GeometryElement[], index: SpatialIndex): void {
  const beams = elements.filter(e => e.type === 'beam') as any[];
  const columns = elements.filter(e => e.type === 'column') as any[];

  for (const beam of beams) {
    for (const col of columns) {
      const beamFrom = beam.from;
      const beamTo = beam.to;
      const colTop: Vec3 = [
        col.base[0],
        col.base[1] + col.height,
        col.base[2]
      ];
      const distFrom = distance2D(beamFrom, colTop);
      const distTo = distance2D(beamTo, colTop);
      const tolerance = col.bottomRadius + 0.05;

      if (distFrom < tolerance) {
        beam.from = [colTop[0], colTop[1], colTop[2]];
      }
      if (distTo < tolerance) {
        beam.to = [colTop[0], colTop[1], colTop[2]];
      }
    }
  }
}

// ─── 屋顶适配 ────────────────────────────────
/**
 * 取一组墙里主导的材质名（按**墙长加权**）。
 *
 * 檐口饰面的材质取自宿主墙。这里必须按长度加权，不能数面数：多楼层蓝图里，
 * 贯通全高的核心筒会把同一标高的墙撑成"若干面窄墙"，而外圈只有少数几面整跨长墙。
 * 实测「中式意境别墅」：同标高的 9 面墙里核心筒占 5 面（各 4m）、外圈 4 面（各 8~12m），
 * 按面数计会选中核心筒的 `concrete`，按长度计（外圈 40m vs 核心筒 20m）才选中
 * 外墙面 `wall_finish`。
 */
function dominantMaterialOf(walls: any[]): string | null {
  const lengthByMaterial = new Map<string, number>();
  for (const wall of walls) {
    const material = typeof wall.material === 'string' ? wall.material.trim() : '';
    if (!material) continue;
    const dx = Number(wall.to?.[0]) - Number(wall.from?.[0]);
    const dz = Number(wall.to?.[2]) - Number(wall.from?.[2]);
    const length = Math.hypot(dx, dz);
    lengthByMaterial.set(
      material,
      (lengthByMaterial.get(material) ?? 0) + (Number.isFinite(length) ? length : 0),
    );
  }
  let best: string | null = null;
  let bestLength = -1;
  for (const [material, length] of lengthByMaterial) {
    if (length > bestLength) { best = material; bestLength = length; }
  }
  return best;
}

function resolveRoofBoundary(elements: GeometryElement[], index: SpatialIndex): void {
  const roofs = elements.filter(e => e.type === 'roof') as any[];
  const walls = elements.filter(e => e.type === 'wall') as any[];

  for (const roof of roofs) {
    // Blueprint 已明确给出完整定位时，尺寸与位置就是设计结果。再次按所有楼层
    // 墙体包围盒扩张，会把退台顶层屋顶错误放大成首层总屋面。
    const explicitPosition = Array.isArray(roof.position)
      && roof.position.length === 3
      && roof.position.every(Number.isFinite);
    const hasExplicitBoundary = (
      explicitPosition
      && Number.isFinite(roof.span) && roof.span > 0
      && Number.isFinite(roof.depth) && roof.depth > 0
    );
    if (walls.length < 3) continue;

    // ── 承托墙的判定 ──
    //
    // 旧实现用「单段墙高 ≥ 全局最大墙高 × 50%」筛结构墙。该判据在多楼层蓝图里会
    // 塌缩：外墙是按层切段的（每段只有层高），而贯通全高的楼梯间/电梯井核心筒是
    // 单段长墙，于是外墙被**全部**误杀、只剩核心筒。
    //
    // 实测「中式意境别墅：L形体量高低错落…」蓝图：16 面外墙（各 3.2m）全灭，
    // 只剩 5 面 9.6m 的混凝土核心筒墙 —— 后果是屋面端部只在核心筒那 4m 上做封堵
    // （正立面屋脊下方露出一块混凝土板），檐口饰面也取到了核心筒的混凝土色。
    //
    // 改用墙顶标高做唯一判据：屋顶 `position.y` 就是墙顶标高，只有真的顶到屋面
    // 基底的墙才可能承托它。退台建筑的低层外墙、阳台栏杆天然被排除。
    // 不要再用「建筑外轮廓」当辅助判据 —— L 形/退台建筑的顶层面是总足迹的
    // 真子集（本例顶层 Z[0,8] ⊂ 总足迹 Z[0,13]），会连正常的端墙一起误杀。
    const highestWallTop = Math.max(...walls.map(wall => (
      Math.max(wall.from[1], wall.to[1])
    )));
    const topSupportWalls = walls.filter(wall => (
      Math.abs(Math.max(wall.from[1], wall.to[1]) - highestWallTop) <= 0.05
    ));
    // 承托墙不足 3 面时回退到全部墙，兼容开放式雨棚等不闭合结构。
    const effectiveWalls = topSupportWalls.length >= 3 ? topSupportWalls : walls;

    // 中式曲面屋顶的坡面会在墙顶上方形成三角形空腔。记录最高承托的
    // 横向墙体，交给 roof builder 生成运行时山墙填充；不修改 Blueprint
    // 中心线，也不把低层墙体误当成屋顶端墙。
    if (roof.roofType === 'chinese_curved') {
      // 承托墙 ≠ 山墙。山墙的职责是封堵曲面屋顶两端那个**满宽**的三角开口，
      // 所以只有横跨山墙宽度的墙才算数。贯通全高的楼梯间/电梯井核心筒虽然
      // 也顶到屋面基底（因此会通过上面的承托墙筛选），但它只是 4m 宽的窄墙，
      // 封不住 13.2m 的开口 —— 放进 `_gableEnds` 只会在屋面内侧多出一块
      // 0.5m 外凸、材质还是混凝土的板（正视图中屋脊下方那块灰板）。
      //
      // 基准取"同一屋顶下最宽的横墙"，不带绝对尺寸、也不依赖 `roof.span`
      // 是否已解析，退台/大挑檐蓝图同样成立。
      const crossWalls = effectiveWalls
        .filter(wall => {
          const dx = wall.to[0] - wall.from[0];
          const dz = wall.to[2] - wall.from[2];
          return Math.abs(dx) > Math.abs(dz) && Math.abs(dx) > 0.01;
        })
        .map(wall => ({
          z: (wall.from[2] + wall.to[2]) / 2,
          xMin: Math.min(wall.from[0], wall.to[0]),
          xMax: Math.max(wall.from[0], wall.to[0]),
          thickness: Number(wall.thickness) || 0.24,
          material: wall.material || 'default',
        }))
        .filter(end => Number.isFinite(end.z) && end.xMax - end.xMin > 0.01);
      const gableWidth = crossWalls.reduce((max, end) => Math.max(max, end.xMax - end.xMin), 0);
      const gableEnds = crossWalls.filter(end => (end.xMax - end.xMin) >= gableWidth * 0.5);
      if (gableEnds.length > 0) (roof as any)._gableEnds = gableEnds;
    }

    // 檐口线脚需要一个"饰面材质"，它取自宿主墙而不是屋面：檐口/博风板/山墙饰面
    // 在现实中属于砌体饰面，用墙材质才能在视觉上把屋面与檐口分开（同色檐口等于
    // 没有檐口）。仍以渲染私有字段注入，不写回 Blueprint、不进契约。
    //
    // 这里**不再按 roofType 白名单**（旧写法只给 gable|hip 注入，导致曲面屋顶、
    // 穹顶、平屋顶永远拿不到檐口，而且每加一种屋顶都要回来补一处类型判断）。
    // 是否真的生成线脚由 `roof.ts` 的 `ROOF_CAPABILITIES` 声明，判定职责只留一处。
    {
      const trimMaterial = dominantMaterialOf(effectiveWalls) ?? roof.material;
      (roof as any)._eave = { material: trimMaterial };
    }

    let minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity;
    let maxY = -Infinity;

    for (const wall of effectiveWalls) {
      minX = Math.min(minX, wall.from[0], wall.to[0]);
      maxX = Math.max(maxX, wall.from[0], wall.to[0]);
      minZ = Math.min(minZ, wall.from[2], wall.to[2]);
      maxZ = Math.max(maxZ, wall.from[2], wall.to[2]);
      maxY = Math.max(maxY, wall.from[1], wall.to[1]);
    }

    if (!hasExplicitBoundary) {
      roof.span = Math.max(roof.span, maxX - minX + 1.0);
      roof.depth = Math.max(roof.depth, maxZ - minZ + 1.0);
    }
    const baseY = maxY;
    if (!(roof as any).position) {
      (roof as any).position = [(minX + maxX) / 2, baseY, (minZ + maxZ) / 2];
    }
  }
}

// ─── 地板填充 ────────────────────────────────
function resolveFloorRegions(elements: GeometryElement[], index: SpatialIndex): void {
  const existingFloors = elements.filter(e => e.type === 'floor') as any[];
  if (existingFloors.length > 0) return;

  const walls = elements.filter(e => e.type === 'wall') as any[];
  if (walls.length < 3) return;

  let minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity;
  let baseY = Infinity;
  for (const wall of walls) {
    minX = Math.min(minX, wall.from[0], wall.to[0]);
    maxX = Math.max(maxX, wall.from[0], wall.to[0]);
    minZ = Math.min(minZ, wall.from[2], wall.to[2]);
    maxZ = Math.max(maxZ, wall.from[2], wall.to[2]);
    baseY = Math.min(baseY, wall.from[1], wall.to[1]);
  }

  const newFloor: any = {
    type: 'floor',
    id: `auto_floor_${elements.length}`,
    from: [minX, baseY, minZ],
    to: [maxX, baseY, maxZ],
    thickness: 0.2,
    material: 'default'
  };
  elements.push(newFloor);
}

// ─── 楼梯步数计算 ─────────────────────────────
function resolveStairSteps(elements: GeometryElement[]): void {
  const stairs = elements.filter(e => e.type === 'stair') as any[];
  for (const stair of stairs) {
    if (stair.stepCount && stair.stepCount > 0) continue;

    const totalRise = stair.to[1] - stair.from[1];
    // 欧几里得水平距离（之前是 Manhattan 距离，对角线楼梯会偏大 ~41%）
    const totalDepth = Math.sqrt(
      Math.pow(stair.to[0] - stair.from[0], 2) + Math.pow(stair.to[2] - stair.from[2], 2)
    );

    const targetStepHeight = 0.18;
    const targetStepDepth = 0.30;

    // 总升幅太小：单步即可
    if (totalRise <= 0.25 || totalDepth <= 0.25) {
      stair.stepCount = 1;
      stair.stepHeight = Math.max(0.05, totalRise);
      stair.stepDepth = Math.max(0.05, totalDepth);
      continue;
    }

    // 从步高和步深两个维度分别估算步数，取平均以平衡二者
    const countByRise = Math.max(1, Math.round(totalRise / targetStepHeight));
    const countByDepth = Math.max(1, Math.round(totalDepth / targetStepDepth));
    let bestCount = Math.round((countByRise + countByDepth) / 2);
    if (bestCount < 1) bestCount = 1;

    // stepHeight * count == totalRise, stepDepth * count == totalDepth
    // 不 clamp 单个值——保持这个恒等式，踏步尺寸与间距始终一致
    // 否则 stair builder 中 step box 尺寸与 step spacing 脱节，产生重叠/缝隙
    stair.stepCount = bestCount;
    stair.stepHeight = totalRise / bestCount;
    stair.stepDepth = totalDepth / bestCount;
  }
}

// ─── 柱网偏移 ────────────────────────────────
function resolveColumnOffsets(elements: GeometryElement[], index: SpatialIndex): void {
  const columns = elements.filter(e => e.type === 'column') as any[];
  const walls = elements.filter(e => e.type === 'wall') as any[];

  for (const col of columns) {
    for (const wall of walls) {
      const wx = wall.from[0], wz = wall.from[2];
      const dx = wall.to[0] - wx, dz = wall.to[2] - wz;
      const len = Math.sqrt(dx * dx + dz * dz);
      if (len < 0.001) continue;

      // 单位方向 + 法线（沿墙看向 to 时，右侧为外）
      const dirLen = 1 / len;
      const nx = -dz * dirLen, nz = dx * dirLen; // 法线（右手方向）

      // 柱子 base 到墙中心线的有符号垂直距离
      const perpDist = ((col.base[0] - wx) * nx + (col.base[2] - wz) * nz);

      // 仅当柱子中心在墙体厚度范围内（嵌入墙内）时才对齐到中心线
      // 之前用 wallHalfThick + colR 容差过大，会把门廊柱等有意 offset 的柱子吸入墙内
      const wallHalfThick = wall.thickness / 2;
      if (Math.abs(perpDist) > wallHalfThick + 0.02) continue;

      // 检查柱子 XZ 投影是否在墙体线段范围内
      const alongT = ((col.base[0] - wx) * dx + (col.base[2] - wz) * dz) / (len * len);
      if (alongT < -0.1 || alongT > 1.1) continue;

      // 在墙内：将柱子中心对齐到墙体中心线
      const offset = perpDist; // 正值表示偏外侧，负值表示偏内侧
      col.base[0] -= offset * nx;
      col.base[2] -= offset * nz;
      break; // 一个柱子只需适配一面墙
    }
  }
}

// ─── 开口定位 ───────────────────────────────
/**
 * 根据父墙体，在墙体上标记开孔信息，并计算开口世界坐标。
 *
 * opening.from 格式：[开口左边缘沿墙距离, 开口底部世界Y坐标, 法向偏移]
 *   - from[0]: 从墙起点沿墙方向的距离（米），不是世界X/Z坐标
 *   - from[1]: 开口底部的世界Y坐标（米）
 *   - from[2]: 法向偏移（米），通常为0（在墙面中心线上）
 *
 * 直线墙的沿墙距离计算：distance = dot(opening_world_pos - wall_from, wall_direction)
 */
function resolveOpenings(elements: GeometryElement[], index: SpatialIndex): void {
  // 清除旧版本可能误写回 WILD 的内部状态，保证重复重建是幂等的。
  for (const el of elements) {
    if (el.type === 'wall') delete (el as any)._cutouts;
    if (el.type === 'opening') {
      delete (el as any)._worldPos;
      delete (el as any)._wallRotation;
    }
  }

  for (const el of elements) {
    if (el.type !== 'opening') continue;
    const opening = el as any;
    const wall = index.byId.get(opening.parentWall);
    if (!wall || wall.type !== 'wall') continue;

    const wallFrom = (wall as any).from;
    const wallTo = (wall as any).to;
    const wallCurveValue = (wall as any).curve;
    const wallCurve = Array.isArray(wallCurveValue) && wallCurveValue.length === 1
      ? wallCurveValue[0]
      : wallCurveValue;

    if (wallCurve && wallCurve.type === 'arc') {
      // 弧形墙体：from[0] 是开口左边缘的弧长，切孔和覆盖面使用中心弧长
      const centerAlong = opening.from[0] + opening.width / 2;
      if (!wall._cutouts) wall._cutouts = [];
      if (!opening._skipWallCutout) wall._cutouts.push({
        localX: centerAlong,
        localY: opening.from[1] - wallFrom[1],
        localW: opening.width,
        localH: opening.height,
        style: opening.style,
      });

      // 弧形墙体：从弧参数计算门的准确世界位置
      const center = wallCurve.center;
      const radius = Math.sqrt((wallFrom[0] - center[0]) ** 2 + (wallFrom[2] - center[2]) ** 2);
      const startRad = Math.atan2(wallFrom[2] - center[2], wallFrom[0] - center[0]);
      const angle = startRad + centerAlong / radius;
      const nx = Math.cos(angle), nz = Math.sin(angle); // 径向（法线方向）
      const offset = opening.from[2] || 0;
      const worldX = center[0] + (radius + offset) * nx;
      const worldZ = center[2] + (radius + offset) * nz;
      opening._worldPos = [worldX, opening.from[1], worldZ];
      opening._wallRotation = Math.atan2(nx, nz);
    } else {
      // ─── 直线墙 ─────────────────────────────
      // opening.from[0] = 开口左边缘沿墙距离（局部坐标）
      // opening.from[1] = 开口底部的世界Y坐标
      // opening.from[2] = 法向偏移（通常为0）

      const wallDx = wallTo[0] - wallFrom[0];
      const wallDz = wallTo[2] - wallFrom[2];
      const wallLen = Math.sqrt(wallDx * wallDx + wallDz * wallDz);
      if (wallLen < 0.001) continue;

      // 墙方向单位向量
      const dirX = wallDx / wallLen;
      const dirZ = wallDz / wallLen;
      // 墙法线方向（右手法则：沿墙方向看时右侧为法线正方向）
      const nx = -dirZ, nz = dirX;

      // 1. 在墙体上存储开孔信息（墙体生成器 boxWithHoles 使用局部坐标）
      //    from[0] 已经是沿墙距离，from[1] 是世界Y需要转为相对墙底偏移
      const localX = opening.from[0] + opening.width / 2; // 开口中心沿墙距离
      const localY = opening.from[1] - wallFrom[1]; // 开口底部相对墙底高度

      if (!wall._cutouts) wall._cutouts = [];
      if (!opening._skipWallCutout) wall._cutouts.push({
        localX: localX,
        localY: localY,
        localW: opening.width,
        localH: opening.height,
        style: opening.style,
      });

      // 2. 计算开口实体的世界位置
      //    世界位置 = 墙起点 + 沿墙投影 + 法向偏移
      const worldX = wallFrom[0] + localX * dirX + opening.from[2] * nx;
      const worldZ = wallFrom[2] + localX * dirZ + opening.from[2] * nz;
      //    from[1] 是世界Y坐标（开口底部），直接使用
      opening._worldPos = [worldX, opening.from[1], worldZ];
      opening._wallRotation = Math.atan2(nx, nz);
    }
  }
}

// ─── 辅助函数 ────────────────────────────────
function distance2D(a: Vec3, b: Vec3): number {
  const dx = a[0] - b[0];
  const dz = a[2] - b[2];
  return Math.sqrt(dx * dx + dz * dz);
}

function averageVec3(a: Vec3, b: Vec3): Vec3 {
  return [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2];
}

/** 只平均 XZ 坐标，Y 各自保留（用于墙角连接） */
function joinXZ(a: Vec3, b: Vec3): void {
  const mx = (a[0] + b[0]) / 2;
  const mz = (a[2] + b[2]) / 2;
  a[0] = mx; a[2] = mz;
  b[0] = mx; b[2] = mz;
}
