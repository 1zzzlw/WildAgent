/**
 * 原语引擎入口 — reconstructEntity
 * 
 * 将 .wild 蓝图编译为可渲染的几何体与材质参数。
 * 这是引擎的唯一公开入口。
 */
import type { Blueprint, ReconstructedEntity, AABB, MeshData, MaterialParams, EngineDiagnostic, Vec3 } from './types';
import { expandTemplates, expandPlacements } from './expander';
import { resolveSpatialRelations } from './resolver';
import { generatePlanarUVs } from './geometry/mesh-helper';
import { applyMaterials } from './materials/apply';
import { getElementBuilder } from './registry';
import { normalizeBlueprintInput } from './parser';
export { parseBlueprint, normalizeBlueprintInput } from './parser';
export { resolveSpatialRelations } from './resolver';
export { getEngineCapabilities, registerElementBuilder } from './registry';
export type { Blueprint, ReconstructedEntity, MeshData, EngineDiagnostic, EngineCapability } from './types';

// ─── 世界空间包围盒计算 ─────────────────────────────
/** 对网格的所有顶点应用 TRS 变换，返回世界空间包围盒 */
function computeWorldAABB(meshes: MeshData[]): AABB {

  let minX = Infinity, minY = Infinity, minZ = Infinity;
  let maxX = -Infinity, maxY = -Infinity, maxZ = -Infinity;

  for (const m of meshes) {
    const { position, rotation, scale } = m.transform;
    const [sx, sy, sz] = scale;
    const [px, py, pz] = position;
    // 欧拉角 XYZ 顺序 → 旋转矩阵
    const rx = rotation[0], ry = rotation[1], rz = rotation[2];
    const cx = Math.cos(rx), sx_ = Math.sin(rx);
    const cy = Math.cos(ry), sy_ = Math.sin(ry);
    const cz = Math.cos(rz), sz_ = Math.sin(rz);
    // Ry * Rx * Rz (Three.js 默认 XYZ 顺序)
    const m00 = cy * cz;
    const m01 = -cy * sz_;
    const m02 = sy_;
    const m10 = sx_ * sy_ * cz + cx * sz_;
    const m11 = -sx_ * sy_ * sz_ + cx * cz;
    const m12 = -sx_ * cy;
    const m20 = -cx * sy_ * cz + sx_ * sz_;
    const m21 = cx * sy_ * sz_ + sx_ * cz;
    const m22 = cx * cy;
    const verts = m.geometry;
    for (let i = 0; i < verts.length; i += 3) {
      // 先缩放
      let x = verts[i] * sx;
      let y = verts[i + 1] * sy;
      let z = verts[i + 2] * sz;
      // 再旋转
      const wx = m00 * x + m01 * y + m02 * z + px;
      const wy = m10 * x + m11 * y + m12 * z + py;
      const wz = m20 * x + m21 * y + m22 * z + pz;

      if (wx < minX) minX = wx;
      if (wy < minY) minY = wy;
      if (wz < minZ) minZ = wz;
      if (wx > maxX) maxX = wx;
      if (wy > maxY) maxY = wy;
      if (wz > maxZ) maxZ = wz;
    }

  }
  if (!Number.isFinite(minX)) {
    return { min: [0, 0, 0], max: [0, 0, 0] };
  }
  return { min: [minX, minY, minZ], max: [maxX, maxY, maxZ] };
}

function applyInstanceTransform(mesh: MeshData, element: any): void {
  const instance = element._instanceTransform;
  if (!instance) return;

  const instancePosition = (instance.position || [0, 0, 0]) as Vec3;
  const instanceRotation = (instance.rotation || [0, 0, 0]) as Vec3;
  const instanceScale = (instance.scale || [1, 1, 1]) as Vec3;
  const localPosition: Vec3 = [
    mesh.transform.position[0] * instanceScale[0],
    mesh.transform.position[1] * instanceScale[1],
    mesh.transform.position[2] * instanceScale[2],
  ];
  const rotated = rotateEulerXYZ(localPosition, instanceRotation);

  mesh.transform.position = [
    rotated[0] + instancePosition[0],
    rotated[1] + instancePosition[1],
    rotated[2] + instancePosition[2],
  ];
  mesh.transform.rotation = [
    mesh.transform.rotation[0] + instanceRotation[0],
    mesh.transform.rotation[1] + instanceRotation[1],
    mesh.transform.rotation[2] + instanceRotation[2],
  ];
  mesh.transform.scale = [
    mesh.transform.scale[0] * instanceScale[0],
    mesh.transform.scale[1] * instanceScale[1],
    mesh.transform.scale[2] * instanceScale[2],
  ];
}

function rotateEulerXYZ(point: Vec3, rotation: Vec3): Vec3 {
  const [x, y, z] = point;
  const [rx, ry, rz] = rotation;
  const cx = Math.cos(rx), sx = Math.sin(rx);
  const cy = Math.cos(ry), sy = Math.sin(ry);
  const cz = Math.cos(rz), sz = Math.sin(rz);
  return [
    cy * cz * x - cy * sz * y + sy * z,
    (sx * sy * cz + cx * sz) * x + (-sx * sy * sz + cx * cz) * y - sx * cy * z,
    (-cx * sy * cz + sx * sz) * x + (cx * sy * sz + sx * cz) * y + cx * cy * z,
  ];
}

/** 简单 3D 噪声（用于程序化纹理）*/
function proceduralNoise(x: number, y: number, z: number): number {
  const d = x * 127.1 + y * 311.7 + z * 74.7;
  const frac = Math.abs(Math.sin(d) * 43758.5453);
  return frac - Math.floor(frac);
}

/** 逐顶点烘焙程序化纹理：基于世界坐标噪声，为每个顶点生成颜色变化 */
function bakeProceduralColors(meshes: MeshData[], materialParams: MaterialParams[]): void {
  for (let mi = 0; mi < meshes.length; mi++) {
    const m = meshes[mi];
    const mp = materialParams[mi];
    if (!mp) continue;
    // 已有 surface 系统着色的网格（stone_block），用 baseColor 和 mortarColor 着色
    if (m.vertexColors) {
      const bc = mp.baseColor;
      const mc = m.patternMortarColor ?? [bc[0] * 0.3, bc[1] * 0.28, bc[2] * 0.25];
      const colors = m.vertexColors;
      for (let i = 0; i < colors.length; i += 3) {
        const isStone = colors[i] > 0.5; // binary mask: 1=stone, 0=joint
        if (isStone) {
          colors[i] = bc[0]; colors[i + 1] = bc[1]; colors[i + 2] = bc[2];
        } else {
          colors[i] = mc[0]; colors[i + 1] = mc[1]; colors[i + 2] = mc[2];
        }
      }
      continue;
    }

    // 读取 grain 参数
    const grainFx = mp.effects?.find((e: any) => e.type === 'grain') as any;
    const hasMoss = mp.effects?.some((e: any) => e.type === 'moss');
    if (!grainFx && !hasMoss) continue;
    const grainIntensity = grainFx?.intensity ?? 0;
    const grainScale = grainFx?.scale ?? 0.04;
    const { position, rotation, scale } = m.transform;
    const [sx, sy, sz] = scale;
    const [px, py, pz] = position;
    // 旋转矩阵（同 computeWorldAABB）
    const rx = rotation[0], ry = rotation[1], rz = rotation[2];
    const cx = Math.cos(rx), sx_ = Math.sin(rx);
    const cy = Math.cos(ry), sy_ = Math.sin(ry);
    const cz = Math.cos(rz), sz_ = Math.sin(rz);
    const m00 = cy * cz, m01 = -cy * sz_, m02 = sy_;
    const m10 = sx_ * sy_ * cz + cx * sz_, m11 = -sx_ * sy_ * sz_ + cx * cz, m12 = -sx_ * cy;
    const m20 = -cx * sy_ * cz + sx_ * sz_, m21 = cx * sy_ * sz_ + sx_ * cz, m22 = cx * cy;
    const verts = m.geometry;
    const colors = new Float32Array(verts.length);
    const moss = hasMoss ? mp.effects!.find((e: any) => e.type === 'moss') as any : null;

    // 计算网格的 Y 范围（用于高度渐变）
    let minWy = Infinity, maxWy = -Infinity;

    for (let i = 0; i < verts.length; i += 3) {
      let x = verts[i] * sx, y = verts[i + 1] * sy, z = verts[i + 2] * sz;
      const wy = m10 * x + m11 * y + m12 * z + py;
      if (wy < minWy) minWy = wy;
      if (wy > maxWy) maxWy = wy;
    }
    const yRange = Math.max(maxWy - minWy, 0.01);

    for (let i = 0; i < verts.length; i += 3) {
      let x = verts[i] * sx, y = verts[i + 1] * sy, z = verts[i + 2] * sz;
      const wx = m00 * x + m01 * y + m02 * z + px;
      const wy = m10 * x + m11 * y + m12 * z + py;
      const wz = m20 * x + m21 * y + m22 * z + pz;

      // 双频噪声（使用 grain 参数控制）
      const freq = 1 / Math.max(grainScale, 0.001);
      const n1 = proceduralNoise(wx * freq, wy * freq, wz * freq);
      const n2 = proceduralNoise(wx * freq * 2, wy * freq * 2, wz * freq * 2);
      const noise = (n1 * 0.6 + n2 * 0.4);

      // 高度渐变因子 (0=底 1=顶)
      const yf = (wy - minWy) / yRange;

      const bc = mp.baseColor;

      // 基础噪声调制 → 由 grainIntensity 控制幅度
      const variation = (noise - 0.5) * grainIntensity;
      let r = Math.max(0, Math.min(1, bc[0] + variation));
      let g = Math.max(0, Math.min(1, bc[1] + variation));
      let b = Math.max(0, Math.min(1, bc[2] + variation));

      // 高度渐变：底部暗、顶部亮
      const hf = (yf - 0.5) * 0.15;
      r = Math.max(0, Math.min(1, r + hf));
      g = Math.max(0, Math.min(1, g + hf));
      b = Math.max(0, Math.min(1, b + hf));

      // 苔藓：base_up 模式（底部密集）
      if (moss && moss.pattern === 'base_up') {
        const mossProb = (1 - yf) * moss.coverage * 2.5;
        if (noise < mossProb) {
          const blend = (mossProb - noise) / mossProb;
          r = r * (1 - blend) + moss.mossColor[0] * blend;
          g = g * (1 - blend) + moss.mossColor[1] * blend;
          b = b * (1 - blend) + moss.mossColor[2] * blend;
        }
      } else if (moss && moss.pattern === 'patchy') {
        // 随机斑块
        if (noise > 1 - moss.coverage * 1.2) {
          const blend = Math.min(1, (noise - (1 - moss.coverage * 1.2)) * 5);
          r = r * (1 - blend) + moss.mossColor[0] * blend;
          g = g * (1 - blend) + moss.mossColor[1] * blend;
          b = b * (1 - blend) + moss.mossColor[2] * blend;
        }
      }
      colors[i] = r;
      colors[i + 1] = g;
      colors[i + 2] = b;
    }
    m.vertexColors = colors;
  }
}

// ─── 主入口 ───────────────────────────────────────
export async function reconstructEntity(bp: Blueprint): Promise<ReconstructedEntity> {
  bp = normalizeBlueprintInput(bp) as Blueprint;
  const diagnostics: EngineDiagnostic[] = [];
  // 1. 展开模板
  let elements = expandTemplates(bp, diagnostics);

  // 2. 空间关系解析
  elements = resolveSpatialRelations(elements);

  // 2.5 展开 placement（此时父构件已定位）
  expandPlacements(bp, elements, diagnostics);


  // 收集 physics constraints 的目标构件 ID（用于标记交互）
  const constrainedTargets = new Set<string>();
  if (bp.behaviors?.physics?.constraints) {
    for (const c of bp.behaviors.physics.constraints) {
      constrainedTargets.add(c.target);

    }
  }

  // 3. 同步重建每种构件的几何体 + 绑定 elementId
  const rawEntries: { elId: string; meshes: MeshData[] }[] = [];
  const reportedCapabilityTypes = new Set<string>();

  for (const el of elements) {
    if (el.type === 'opening' && el._cutoutOnly) continue;
    let meshes: MeshData[];
    const registration = getElementBuilder((el as any).type);
    if (!registration) {
      diagnostics.push({
        level: 'error',
        code: 'UNSUPPORTED_ELEMENT_TYPE',
        message: `没有注册构件类型 "${(el as any).type}" 的 builder`,
        elementId: el.id,
        elementType: (el as any).type,
      });
      continue;
    }

    if (registration.status !== 'stable' && !reportedCapabilityTypes.has(registration.type)) {
      diagnostics.push({
        level: registration.status === 'experimental' ? 'warning' : 'info',
        code: 'PARTIAL_CAPABILITY',
        message: `${registration.type}: ${registration.description}`,
        elementType: registration.type,
      });
      reportedCapabilityTypes.add(registration.type);
    }

    try {
      meshes = registration.build(el);
    } catch (buildError) {
      diagnostics.push({
        level: 'error',
        code: 'ELEMENT_BUILD_FAILED',
        message: buildError instanceof Error ? buildError.message : String(buildError),
        elementId: el.id,
        elementType: el.type,
      });
      continue;
    }

    if (meshes.length === 0 || meshes.every(mesh => mesh.geometry.length === 0)) {
      diagnostics.push({
        level: 'warning',
        code: 'EMPTY_GEOMETRY',
        message: `构件 "${el.id}" 没有生成可渲染几何`,
        elementId: el.id,
        elementType: el.type,
      });
    }

    // 为每个网格绑定 elementId 和 interactive 标记
    const interaction = (el as any)._interaction;
    const isDraggable = (el as any)._draggable === true;
    const isInteractive = constrainedTargets.has(el.id) || !!interaction || isDraggable;

    for (const m of meshes) {
      m.elementId = el.id;
      if (isInteractive || m.interaction) m.interactive = true;
      if (interaction && !m.interaction) m.interaction = interaction;
      if (isDraggable) m.draggable = true;
      if (!m.uvs) m.uvs = generatePlanarUVs(m.geometry);
      applyInstanceTransform(m, el);
    }

    rawEntries.push({ elId: el.id, meshes });

  }

  // 保留源元素 ID 和变换；相同几何在 renderer 中实例化批处理，仍可单独选取。
  const meshes = rawEntries.flatMap(e => e.meshes);

  // 4. 材质应用（效果层烘焙：调色类）
  const materialParams = applyMaterials(bp.materials || {}, bp.assets || {}, meshes);
  // 5. 计算世界空间包围盒
  const boundingBox = computeWorldAABB(meshes);
  // 6. 烘焙逐顶点程序化纹理颜色
  bakeProceduralColors(meshes, materialParams);
  return {
    meshes,
    materialParams,
    boundingBox,
    physics: bp.behaviors?.physics,
    scripts: bp.behaviors?.scripts,
    animation: bp.behaviors?.animation,
    diagnostics,
  };

}

