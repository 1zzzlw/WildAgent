import type { WallParams, MeshData, Vec3 } from '../types';
import { boxWithHoles } from './box-with-holes';
import { generateArchitecturalSurfaceAttributes, indexTriList } from './mesh-helper';

const TARGET_TEXEL = 0.4;
const TARGET_VERTEX_BUDGET = 36000;

export function buildWall(params: WallParams): MeshData[] {
  const { from, to, thickness, material } = params;
  const curve = (params as any).curve;
  const cutouts = (params as any)._cutouts;

  if (curve) {
    return buildCurvedWall(from, to, thickness, material || 'default', curve, cutouts);
  }

  const dx = to[0] - from[0];
  const dz = to[2] - from[2];
  const length = Math.sqrt(dx * dx + dz * dz);
  const height = Math.abs(to[1] - from[1]);
  const startExtension = Math.max(0, params._jointExtensions?.start ?? 0);
  const endExtension = Math.max(0, params._jointExtensions?.end ?? 0);
  const renderLength = length + startExtension + endExtension;
  const renderCutouts = cutouts?.map((cutout: any) => ({
    ...cutout,
    localX: cutout.localX + startExtension,
  }));
  
  let geometry: Float32Array, indices: Uint16Array;
  if (renderCutouts?.length) {
    const r = boxWithHoles(renderLength, height, thickness, renderCutouts);
    geometry = r.geometry; indices = r.indices;
  } else {
    // 小墙维持 0.4m 采样，供逐顶点程序化材质使用；通高墙按预算自适应
    // 放大采样步长。旧实现对 80~120m 高墙仍固定 0.4m，单墙会生成
    // 10万到30万顶点并触发渲染保护，即使墙上没有任何洞口。
    const step = resolveSubdivisionStep(renderLength, height, thickness);
    const raw = subdivideBox(renderLength, height, thickness, step);
    const i = indexTriList(raw);
    geometry = i.geometry; indices = i.indices;
  }

  const directionX = length > 1e-9 ? dx / length : 0;
  const directionZ = length > 1e-9 ? dz / length : 0;
  const centerShift = (endExtension - startExtension) / 2;
  const midX = (from[0] + to[0]) / 2 + directionX * centerShift;
  const midZ = (from[2] + to[2]) / 2 + directionZ * centerShift;
  const midY = (from[1] + to[1]) / 2;
  // Three.js 绕 Y 轴旋转时，局部 +X 会映射到 (cosθ, -sinθ)。
  // 因此墙体要沿世界方向 (dx, dz) 放置，旋转角必须取负值。
  // 该约定与 resolver 中 opening 的局部坐标转换保持一致。
  const angle = -Math.atan2(dz, dx);
  const attributes = generateArchitecturalSurfaceAttributes(geometry);

  return [{
    geometry,
    indices: new Uint32Array(indices),
    normals: attributes.normals,
    uvs: attributes.uvs,
    transform: { position: [midX, midY, midZ], rotation: [0, angle, 0], scale: [1, 1, 1] },
    materialRef: material || 'default'
  }];
}

function subdivisionVertexCount(w: number, h: number, d: number, step: number): number {
  const nx = Math.max(1, Math.round(w / step));
  const ny = Math.max(1, Math.round(h / step));
  const nz = Math.max(1, Math.round(d / step));
  return 12 * (nx * ny + nx * nz + ny * nz);
}

function resolveSubdivisionStep(w: number, h: number, d: number): number {
  const surfaceTerms = w * h + w * d + h * d;
  let step = Math.max(
    TARGET_TEXEL,
    Math.sqrt(12 * surfaceTerms / TARGET_VERTEX_BUDGET),
  );
  while (subdivisionVertexCount(w, h, d, step) > TARGET_VERTEX_BUDGET) {
    step *= 1.05;
  }
  return step;
}

function buildCurvedWall(from: Vec3, to: Vec3, thickness: number, material: string, curve: any, cutouts?: any[]): MeshData[] {
  const height = Math.abs(to[1] - from[1]);
  const baseY = Math.min(from[1], to[1]);

  const segs = Array.isArray(curve) ? curve : [curve];
  if (segs.length !== 1 || segs[0].type !== 'arc') {
    const points = evalCurve(from, to, curve);
    const meshes: MeshData[] = [];
    for (let i = 0; i < points.length - 1; i++) {
      const [x1, z1] = points[i], [x2, z2] = points[i + 1];
      const segLen = Math.sqrt((x2 - x1) ** 2 + (z2 - z1) ** 2);
      if (segLen < 0.001) continue;
      const raw = createBoxGeometry(segLen, height, thickness);
      const { geometry, indices } = indexTriList(raw);
      const attributes = generateArchitecturalSurfaceAttributes(geometry);
      meshes.push({
        geometry, indices: new Uint32Array(indices),
        normals: attributes.normals, uvs: attributes.uvs,
        transform: { position: [(x1+x2)/2, baseY+height/2, (z1+z2)/2], rotation: [0, Math.atan2(z2-z1, x2-x1), 0], scale: [1,1,1] },
        materialRef: material,
      });
    }
    return meshes;
  }

  // === 连续圆柱面网格，索引三角形（无顶点重复）===
  const arcSegCount = segs[0].segments || 32;
  const center = segs[0].center;
  const startRad = Math.atan2(from[2] - center[2], from[0] - center[0]);
  const sweepRad = segs[0].sweep * Math.PI / 180;
  const radius = Math.sqrt((from[0] - center[0]) ** 2 + (from[2] - center[2]) ** 2);
  const innerR = radius - thickness / 2;
  const outerR = radius + thickness / 2;

  const cutoutAngles = (cutouts || []).map(c => ({
    a1: startRad + (c.localX - c.localW / 2) / radius,
    a2: startRad + (c.localX + c.localW / 2) / radius,
    y1: c.localY, y2: c.localY + c.localH,
  }));

  // 顶点 + 法线（每角度 4 个：内下/内上/外下/外上）
  const verts: number[] = [], normals: number[] = [], uvs: number[] = [];
  for (let i = 0; i <= arcSegCount; i++) {
    const t = i / arcSegCount, a = startRad + t * sweepRad;
    const ca = Math.cos(a), sa = Math.sin(a);
    const xi = center[0] + innerR * ca, zi = center[2] + innerR * sa;
    const xo = center[0] + outerR * ca, zo = center[2] + outerR * sa;
    verts.push(xi, baseY, zi, xi, baseY + height, zi, xo, baseY, zo, xo, baseY + height, zo);
    normals.push(-ca, 0, -sa, -ca, 0, -sa, ca, 0, sa, ca, 0, sa);
    const arcDistance = Math.abs(t * sweepRad * radius);
    uvs.push(arcDistance, 0, arcDistance, height, arcDistance, 0, arcDistance, height);
  }

  // 纯索引三角形
  const idx: number[] = [];
  function addTri(i0: number, i1: number, i2: number) { idx.push(i0, i1, i2); }
  function addQuad(i0: number, i1: number, i2: number, i3: number) { addTri(i0, i1, i2); addTri(i0, i2, i3); }

  for (let i = 0; i < arcSegCount; i++) {
    const a1 = startRad + (i / arcSegCount) * sweepRad;
    const a2 = startRad + ((i + 1) / arcSegCount) * sweepRad;
    if (cutoutAngles.some(co => a2 > co.a1 && a1 < co.a2 && baseY + height > co.y1 + baseY && baseY < co.y2 + baseY)) continue;
    const b0 = i * 4, b1 = (i + 1) * 4;
    addQuad(b0+2, b0+3, b1+3, b1+2); // 外面
    addQuad(b0+1, b0+0, b1+0, b1+1); // 内面
    addQuad(b0+1, b0+3, b1+3, b1+1); // 顶面
    addQuad(b0+2, b0+0, b1+0, b1+2); // 底面
  }

  if (idx.length === 0) return [];
  return [{
    geometry: new Float32Array(verts), normals: new Float32Array(normals),
    uvs: new Float32Array(uvs),
    indices: new Uint32Array(idx),
    transform: { position: [0, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1] },
    materialRef: material,
  }];
}

export function createBoxGeometry(w: number, h: number, d: number): Float32Array {
  const hw=w/2, hh=h/2, hd=d/2;
  return new Float32Array([
    -hw,-hh,hd, hw,-hh,hd, hw,hh,hd, -hw,-hh,hd, hw,hh,hd, -hw,hh,hd,   // +Z (front)
    hw,-hh,-hd, -hw,-hh,-hd, -hw,hh,-hd, hw,-hh,-hd, -hw,hh,-hd, hw,hh,-hd,  // -Z (back)
    -hw,hh,-hd, -hw,hh,hd, hw,hh,hd, -hw,hh,-hd, hw,hh,hd, hw,hh,-hd,   // +Y (top) — fixed winding
    -hw,-hh,hd, -hw,-hh,-hd, hw,-hh,-hd, -hw,-hh,hd, hw,-hh,-hd, hw,-hh,hd,  // -Y (bottom) — fixed winding
    hw,-hh,hd, hw,-hh,-hd, hw,hh,-hd, hw,-hh,hd, hw,hh,-hd, hw,hh,hd,   // +X (right)
    -hw,-hh,-hd, -hw,-hh,hd, -hw,hh,hd, -hw,-hh,-hd, -hw,hh,hd, -hw,hh,-hd  // -X (left)
  ]);
}

export function subdivideBox(w: number, h: number, d: number, step: number): Float32Array {
  const hw=w/2, hh=h/2, hd=d/2;
  const nx=Math.max(1,Math.round(w/step)), ny=Math.max(1,Math.round(h/step)), nz=Math.max(1,Math.round(d/step));
  const verts: number[]=[];
  function face(cx:number,cy:number,cz:number,ux:number,uy:number,uz:number,vx:number,vy:number,vz:number,nu:number,nv:number){
    for(let j=0;j<nv;j++) for(let i=0;i<nu;i++){
      const fui=i/nu,fuj=(i+1)/nu,fvi=j/nv,fvj=(j+1)/nv;
      const x0=cx+ux*fui+vx*fvi,y0=cy+uy*fui+vy*fvi,z0=cz+uz*fui+vz*fvi;
      const x1=cx+ux*fuj+vx*fvi,y1=cy+uy*fuj+vy*fvi,z1=cz+uz*fuj+vz*fvi;
      const x2=cx+ux*fuj+vx*fvj,y2=cy+uy*fuj+vy*fvj,z2=cz+uz*fuj+vz*fvj;
      const x3=cx+ux*fui+vx*fvj,y3=cy+uy*fui+vy*fvj,z3=cz+uz*fui+vz*fvj;
      verts.push(x0,y0,z0,x1,y1,z1,x2,y2,z2); verts.push(x0,y0,z0,x2,y2,z2,x3,y3,z3);
    }
  }
  // All faces centered at origin with correct outward-facing winding
  face(-hw,-hh,hd, w,0,0, 0,h,0, nx,ny);   // +Z: corner(-hw,-hh,hd), u=+X, v=+Y → normal +Z
  face( hw,-hh,-hd,-w,0,0, 0,h,0, nx,ny);   // -Z: corner(hw,-hh,-hd), u=-X, v=+Y → normal -Z
  face( hw, hh,-hd,-w,0,0, 0,0,d, nx,nz);   // +Y: corner(hw,hh,-hd), u=-X, v=+Z → normal +Y (fixed)
  face(-hw,-hh,-hd, w,0,0, 0,0,d, nx,nz);   // -Y: corner(-hw,-hh,-hd), u=+X, v=+Z → normal -Y (fixed)
  face( hw,-hh, hd, 0,0,-d, 0,h,0, nz,ny);  // +X: corner(hw,-hh,hd), u=-Z, v=+Y → normal +X
  face(-hw,-hh,-hd, 0,0, d, 0,h,0, nz,ny);  // -X: corner(-hw,-hh,-hd), u=+Z, v=+Y → normal -X
  return new Float32Array(verts);
}

export function evalCurve(from: Vec3, to: Vec3, curve: any): [number, number][] {
  const segs = Array.isArray(curve) ? curve : [curve];
  const points: [number, number][] = [];
  for (const seg of segs) {
    const t = seg.type || 'line', sn = seg.segments || 24;
    if (t === 'line') {
      const sx=points.length?points[points.length-1][0]:from[0], sz=points.length?points[points.length-1][1]:from[2];
      for(let i=0;i<=sn;i++) points.push([sx+(to[0]-sx)*i/sn,sz+(to[2]-sz)*i/sn]);
    } else if (t === 'arc') {
      const c=seg.center, sw=seg.sweep*Math.PI/180, r=Math.sqrt((from[0]-c[0])**2+(from[2]-c[2])**2);
      const sa=points.length?Math.atan2(points[points.length-1][1]-c[2],points[points.length-1][0]-c[0]):Math.atan2(from[2]-c[2],from[0]-c[0]);
      for(let i=0;i<=sn;i++){const a=sa+i/sn*sw;points.push([c[0]+r*Math.cos(a),c[2]+r*Math.sin(a)]);}
    } else if (t === 'ellipse') {
      const c=seg.center, rx=seg.radiusX, rz=seg.radiusZ, sa=(seg.startAngle??0)*Math.PI/180, sw=(seg.sweep??360)*Math.PI/180;
      for(let i=0;i<=sn;i++){const a=sa+i/sn*sw;points.push([c[0]+rx*Math.cos(a),c[2]+rz*Math.sin(a)]);}
    } else if (t === 'catenary') {
      const rise=seg.rise, sx=points.length?points[points.length-1][0]:from[0], sz=points.length?points[points.length-1][1]:from[2];
      const len=Math.sqrt((to[0]-sx)**2+(to[2]-sz)**2), dx=(to[0]-sx)/len, dz=(to[2]-sz)/len;
      for(let i=0;i<=sn;i++){const p=i/sn,a=p*len,ar=rise*Math.sin(p*Math.PI);points.push([sx+a*dx+ar*(-dz),sz+a*dz+ar*dx]);}
    } else {
      points.push([points.length?points[points.length-1][0]:from[0],points.length?points[points.length-1][1]:from[2]],[to[0],to[2]]);
    }
  }
  const r=[points[0]];for(let i=1;i<points.length;i++){const dx=points[i][0]-r[r.length-1][0],dz=points[i][1]-r[r.length-1][1];if(dx*dx+dz*dz>0.0001)r.push(points[i]);}
  return r;
}
